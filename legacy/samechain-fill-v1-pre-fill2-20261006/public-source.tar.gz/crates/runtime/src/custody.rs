//! U-owned encrypted restart custody, not a wallet, source authorization or financial fact.
//!
//! Callers supply their own borrowed encryption capability, opaque filename and independent
//! namespace/context binding. No keys or private PCZTs belong in argv, logs or an S packet.
//! Linux descriptor-relative publication is immutable and committed only after directory
//! fsync. Same-UID/root compromise, backup policy and the filesystem's real durability remain
//! outside this boundary; saving never authorizes releasing P or moving funds.

use std::{fmt, path::Path, sync::LazyLock};

use chacha20poly1305::{
    XChaCha20Poly1305, XNonce,
    aead::{AeadInPlace, KeyInit},
};
use orchard::{
    Address, Anchor, Note,
    circuit::{OrchardCircuitVersion, VerifyingKey},
    keys::FullViewingKey,
    note::{NoteVersion, RandomSeed, Rho},
    tree::{MerkleHashOrchard, MerklePath},
    value::NoteValue,
};
use rand_core::{OsRng, RngCore};
use subtle::ConstantTimeEq;
use zcash_primitives::transaction::components::orchard::{ACTION_SIZE, SPEND_AUTH_SIG_SIZE};
use zcash_protocol::consensus::BranchId;
use zeroize::Zeroizing;
use ziquid_proofs::preparation::{
    MAX_PRIVATE_INPUT_BYTES, MAX_TRANSACTION_BYTES, PreparationWitness, verify_preparation,
};
use ziquid_protocol::ValidatedContext;
use ziquid_zcash::{IronwoodTransaction, OwnedInput, PayoutWitness};

const DOMAIN: &[u8] = b"ziquid.u.custody.v3";
// Recognition only: never decrypt, rewrite or discard retained old custody.
const RETAINED_DOMAINS: [&[u8]; 2] = [b"ziquid.u.custody.v1", b"ziquid.u.custody.v2"];
const NONCE_LEN: usize = 24;
const TAG_LEN: usize = 16;
const HEADER_LEN: usize = DOMAIN.len() + NONCE_LEN + 4;
const MAX_ACTIONS: usize = MAX_TRANSACTION_BYTES / (ACTION_SIZE + SPEND_AUTH_SIG_SIZE);
const MAX_PLAINTEXT_BYTES: usize = MAX_PRIVATE_INPUT_BYTES + 4 + 4 * MAX_ACTIONS;
const MAX_ENVELOPE_BYTES: usize = HEADER_LEN + MAX_PLAINTEXT_BYTES + TAG_LEN;
static Q_VERIFYING_KEY: LazyLock<VerifyingKey> = LazyLock::new(|| VerifyingKey::build(OrchardCircuitVersion::PostNu6_3));

/// Full private P/Q preparation plus the builder's nth-requested-output mapping.
/// This never contains a solver capability or permission to release source authorization.
#[derive(Clone)]
pub struct PrivatePreparation {
    pub witness: PreparationWitness,
    pub requested_output_actions: Vec<u32>,
}

impl fmt::Debug for PrivatePreparation {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("PrivatePreparation([redacted])")
    }
}

/// Categories only: no raw I/O/source error, private path, note, memo or key is retained.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CustodyError {
    UnsupportedPlatform,
    UnsupportedVersion,
    UnsafePath,
    Io,
    NotFound,
    ResourceLimit,
    Encoding,
    Authentication,
    Preparation,
    Conflict,
    /// A barrier failed. An installed final is retained and must be authenticated/synced
    /// on retry; callers must not export protected material based on this outcome.
    Durability,
}

impl fmt::Display for CustodyError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        let message = match self {
            Self::UnsupportedPlatform => "private preparation custody requires Linux",
            Self::UnsupportedVersion => "private preparation custody version is unsupported; retained bytes require their authenticated restore capability",
            Self::UnsafePath => "custody path is not owner-private",
            Self::Io => "private custody filesystem operation failed",
            Self::NotFound => "private preparation custody is absent",
            Self::ResourceLimit => "private preparation custody exceeds its resource bound",
            Self::Encoding => "private preparation custody encoding rejected",
            Self::Authentication => "private preparation custody authentication rejected",
            Self::Preparation => "private preparation custody relation rejected",
            Self::Conflict => "immutable private preparation custody conflicts",
            Self::Durability => "private preparation custody durability is indeterminate",
        };
        formatter.write_str(message)
    }
}

impl std::error::Error for CustodyError {}

impl PrivatePreparation {
    /// Recover actual sender authority from caller-private material, never an S packet.
    /// Complete load/save additionally validate the P/Q relation and executable Q proof.
    pub fn restore_payout(&self) -> Result<PayoutWitness, CustodyError> {
        if self.requested_output_actions.is_empty() || self.requested_output_actions.len() > MAX_ACTIONS {
            return Err(CustodyError::ResourceLimit);
        }
        let witness = &self.witness;
        let recipient = Option::<Address>::from(Address::from_raw_address_bytes(&witness.note_recipient))
            .ok_or(CustodyError::Preparation)?;
        let rho = Option::<Rho>::from(Rho::from_bytes(&witness.note_rho))
            .ok_or(CustodyError::Preparation)?;
        let rseed = Option::<RandomSeed>::from(RandomSeed::from_bytes(witness.note_rseed, &rho))
            .ok_or(CustodyError::Preparation)?;
        let note = Option::<Note>::from(Note::from_parts(
            recipient, NoteValue::from_raw(witness.note_value), rho, rseed, NoteVersion::V3,
        )).ok_or(CustodyError::Preparation)?;
        let fvk = FullViewingKey::from_bytes(&witness.full_viewing_key)
            .ok_or(CustodyError::Preparation)?;
        let anchor = Option::<Anchor>::from(Anchor::from_bytes(witness.anchor))
            .ok_or(CustodyError::Preparation)?;
        let mut siblings = [MerkleHashOrchard::from_bytes(&[0; 32]).unwrap(); 32];
        for (sibling, bytes) in siblings.iter_mut().zip(&witness.merkle_siblings) {
            *sibling = Option::<MerkleHashOrchard>::from(MerkleHashOrchard::from_bytes(bytes))
                .ok_or(CustodyError::Preparation)?;
        }
        let input = OwnedInput::new(note, fvk, MerklePath::from_parts(witness.merkle_position, siblings), anchor)
            .map_err(|_| CustodyError::Preparation)?;
        let mapping = self.requested_output_actions.iter()
            .map(|index| usize::try_from(*index).map_err(|_| CustodyError::ResourceLimit))
            .collect::<Result<Vec<_>, _>>()?;
        PayoutWitness::restore(input, witness.private_p_pczt.clone(), mapping)
            .map_err(|_| CustodyError::Preparation)
    }

    fn validate(&self, expected_context: [u8; 32]) -> Result<(), CustodyError> {
        let context = ValidatedContext::decode(&self.witness.context_bytes)
            .map_err(|_| CustodyError::Preparation)?;
        if context.digest() != expected_context {
            return Err(CustodyError::Authentication);
        }
        verify_preparation(&self.witness).map_err(|_| CustodyError::Preparation)?;
        self.restore_payout()?;
        let q = IronwoodTransaction::parse(&self.witness.q_transaction, BranchId::Nu6_3)
            .map_err(|_| CustodyError::Preparation)?;
        q.verify_authorization(
            &Q_VERIFYING_KEY,
            &mut OsRng,
        ).map_err(|_| CustodyError::Preparation)
    }

    fn encode(&self) -> Result<Zeroizing<Vec<u8>>, CustodyError> {
        if self.requested_output_actions.is_empty() || self.requested_output_actions.len() > MAX_ACTIONS {
            return Err(CustodyError::ResourceLimit);
        }
        // The existing codec is already filled with private bytes. Growing it would
        // let Vec free an unwiped old allocation; keep it guarded and copy once into
        // a guarded destination sized for mapping/count and the later AEAD tag.
        let base = self.witness.encode_private().map_err(|_| CustodyError::Encoding)?;
        let capacity = base.len()
            .checked_add(4 * self.requested_output_actions.len() + 4 + TAG_LEN)
            .ok_or(CustodyError::ResourceLimit)?;
        let mut bytes = Zeroizing::new(Vec::with_capacity(capacity));
        bytes.extend_from_slice(&base);
        drop(base);
        for index in &self.requested_output_actions {
            bytes.extend_from_slice(&index.to_le_bytes());
        }
        bytes.extend_from_slice(&(self.requested_output_actions.len() as u32).to_le_bytes());
        Ok(bytes)
    }

    fn decode(bytes: &[u8]) -> Result<Self, CustodyError> {
        if bytes.len() > MAX_PLAINTEXT_BYTES {
            return Err(CustodyError::ResourceLimit);
        }
        let tail = bytes.len().checked_sub(4).ok_or(CustodyError::Encoding)?;
        let count = u32::from_le_bytes(bytes[tail..].try_into().map_err(|_| CustodyError::Encoding)?) as usize;
        if count == 0 || count > MAX_ACTIONS {
            return Err(CustodyError::ResourceLimit);
        }
        let mapping_len = count.checked_mul(4).ok_or(CustodyError::ResourceLimit)?;
        let mapping_at = tail.checked_sub(mapping_len).ok_or(CustodyError::Encoding)?;
        let witness = PreparationWitness::decode_private(&bytes[..mapping_at])
            .map_err(|_| CustodyError::Encoding)?;
        let requested_output_actions = bytes[mapping_at..tail].as_chunks::<4>().0.iter()
            .map(|bytes| u32::from_le_bytes(*bytes))
            .collect();
        Ok(Self { witness, requested_output_actions })
    }
}

fn aad(header: &[u8], namespace: [u8; 32], context: [u8; 32]) -> [u8; HEADER_LEN + 64] {
    let mut bytes = [0; HEADER_LEN + 64];
    bytes[..HEADER_LEN].copy_from_slice(header);
    bytes[HEADER_LEN..HEADER_LEN + 32].copy_from_slice(&namespace);
    bytes[HEADER_LEN + 32..].copy_from_slice(&context);
    bytes
}

fn decrypt(
    envelope: &mut Zeroizing<Vec<u8>>,
    key: &[u8; 32],
    namespace: [u8; 32],
    context: [u8; 32],
) -> Result<PrivatePreparation, CustodyError> {
    if !matches!(envelope_shape(envelope)?, EnvelopeShape::Complete) {
        return Err(CustodyError::Encoding);
    }
    let header: [u8; HEADER_LEN] = envelope[..HEADER_LEN].try_into()
        .map_err(|_| CustodyError::Encoding)?;
    let cipher = XChaCha20Poly1305::new(key.into());
    let end = envelope.len() - TAG_LEN;
    let (content, tag) = envelope.split_at_mut(end);
    cipher.decrypt_in_place_detached(
        XNonce::from_slice(&header[DOMAIN.len()..DOMAIN.len() + NONCE_LEN]),
        &aad(&header, namespace, context),
        &mut content[HEADER_LEN..],
        chacha20poly1305::Tag::from_slice(tag),
    ).map_err(|_| CustodyError::Authentication)?;
    let artifact = PrivatePreparation::decode(&content[HEADER_LEN..])?;
    artifact.validate(context)?;
    Ok(artifact)
}

enum EnvelopeShape { Complete, Incomplete }

fn envelope_shape(bytes: &[u8]) -> Result<EnvelopeShape, CustodyError> {
    if bytes.len() > MAX_ENVELOPE_BYTES {
        return Err(CustodyError::ResourceLimit);
    }
    // Old complete and interrupted prefixes are not current disposable staging.
    // Retaining bytes is not evidence that old funded rights remain exercisable.
    if !bytes.is_empty()
        && RETAINED_DOMAINS.iter().any(|domain| bytes.starts_with(domain)
            || (bytes.len() < domain.len() && domain.starts_with(bytes)))
    {
        return Err(CustodyError::UnsupportedVersion);
    }
    if bytes.len() < DOMAIN.len() {
        // Empty or a domain prefix can only represent an interrupted write in our private
        // reserved staging entry. Unknown bytes are not authorized for deletion.
        return if DOMAIN.starts_with(bytes) { Ok(EnvelopeShape::Incomplete) } else { Err(CustodyError::Encoding) };
    }
    if !bytes.starts_with(DOMAIN) {
        return Err(CustodyError::Encoding);
    }
    if bytes.len() < HEADER_LEN {
        return Ok(EnvelopeShape::Incomplete);
    }
    let cipher_len = u32::from_le_bytes(bytes[HEADER_LEN - 4..HEADER_LEN].try_into()
        .map_err(|_| CustodyError::Encoding)?) as usize;
    if !(TAG_LEN..=MAX_PLAINTEXT_BYTES + TAG_LEN).contains(&cipher_len) {
        return Err(CustodyError::ResourceLimit);
    }
    let total = HEADER_LEN.checked_add(cipher_len).ok_or(CustodyError::ResourceLimit)?;
    match bytes.len().cmp(&total) {
        std::cmp::Ordering::Equal => Ok(EnvelopeShape::Complete),
        std::cmp::Ordering::Less => Ok(EnvelopeShape::Incomplete),
        std::cmp::Ordering::Greater => Err(CustodyError::Encoding),
    }
}

/// Save validated complete P/Q custody immutably. Identical logical retries authenticate
/// the existing envelope and complete its barriers without generating a new nonce.
/// Any error prevents a caller from treating this attempt as durable custody.
pub fn save_preparation(
    path: impl AsRef<Path>,
    key: &[u8; 32],
    namespace: [u8; 32],
    artifact: &PrivatePreparation,
) -> Result<(), CustodyError> {
    #[cfg(target_os = "linux")]
    {
        let context = ValidatedContext::decode(&artifact.witness.context_bytes)
            .map_err(|_| CustodyError::Preparation)?.digest();
        artifact.validate(context)?;
        let plaintext = artifact.encode()?;
        linux::save(path.as_ref(), key, namespace, context, plaintext)
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (path, key, namespace, artifact);
        Err(CustodyError::UnsupportedPlatform)
    }
}

/// Load only against independently supplied caller/order bindings; a file's header is
/// never its own source of trust. Returns actual validated restart material, not a receipt.
pub fn load_preparation(
    path: impl AsRef<Path>,
    key: &[u8; 32],
    namespace: [u8; 32],
    expected_context_digest: [u8; 32],
) -> Result<PrivatePreparation, CustodyError> {
    #[cfg(target_os = "linux")]
    {
        linux::load(path.as_ref(), key, namespace, expected_context_digest)
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (path, key, namespace, expected_context_digest);
        Err(CustodyError::UnsupportedPlatform)
    }
}

// The prover reuses the exact custody ownership/ancestor policy, but never
// creates the caller-selected root or takes the custody publication lock.
#[cfg(all(feature = "sp1-local", target_os = "linux"))]
pub(crate) fn trusted_private_directory(path: &Path) -> Result<(std::fs::File, std::path::PathBuf), CustodyError> {
    linux::directory(path, false, false)
}

#[cfg(target_os = "linux")]
mod linux {
    use super::*;
    use std::{
        ffi::{OsStr, OsString}, fs::File, io::{Read, Write},
        os::unix::fs::MetadataExt, path::Component,
    };
    use rustix::{
        fs::{AtFlags, FlockOperation, Mode, OFlags, RenameFlags},
        io::Errno,
    };

    fn io_error(error: Errno) -> CustodyError {
        match error {
            Errno::LOOP | Errno::NOTDIR => CustodyError::UnsafePath,
            Errno::NOENT => CustodyError::NotFound,
            _ => CustodyError::Io,
        }
    }

    fn sync(file: &File) -> Result<(), CustodyError> {
        file.sync_all().map_err(|_| CustodyError::Durability)
    }

    fn directory_is_trusted(directory: &File, immediate: bool) -> Result<(), CustodyError> {
        let metadata = directory.metadata().map_err(|_| CustodyError::Io)?;
        let owner = rustix::process::geteuid().as_raw();
        let mode = metadata.mode() & 0o7777;
        if !metadata.is_dir()
            || if immediate {
                metadata.uid() != owner || mode != 0o700
            } else {
                (metadata.uid() != 0 && metadata.uid() != owner)
                    || (mode & 0o022 != 0 && !(metadata.uid() == 0 && mode == 0o1777))
            }
        {
            return Err(CustodyError::UnsafePath);
        }
        Ok(())
    }

    fn absolute(path: &Path) -> Result<std::path::PathBuf, CustodyError> {
        if path.components().any(|component| matches!(component, Component::ParentDir)) {
            return Err(CustodyError::UnsafePath);
        }
        let absolute = if path.is_absolute() { path.to_owned() } else {
            std::env::current_dir().map_err(|_| CustodyError::Io)?.join(path)
        };
        if absolute.components().any(|component| matches!(component, Component::ParentDir)) {
            return Err(CustodyError::UnsafePath);
        }
        Ok(absolute)
    }

    pub(super) fn directory(path: &Path, create: bool, durable: bool) -> Result<(File, std::path::PathBuf), CustodyError> {
        let absolute = absolute(path)?;
        let flags = OFlags::RDONLY | OFlags::DIRECTORY | OFlags::NOFOLLOW | OFlags::CLOEXEC | OFlags::NONBLOCK;
        let mut directory: File = rustix::fs::open("/", flags, Mode::empty()).map_err(io_error)?.into();
        directory_is_trusted(&directory, false)?;
        if durable { sync(&directory)?; }
        for component in absolute.components() {
            let child_name = match component {
                Component::RootDir | Component::CurDir => continue,
                Component::Normal(name) => name,
                _ => return Err(CustodyError::UnsafePath),
            };
            let child = match rustix::fs::openat(&directory, child_name, flags, Mode::empty()) {
                Ok(fd) => fd,
                Err(Errno::NOENT) if create => {
                    match rustix::fs::mkdirat(&directory, child_name, Mode::RUSR | Mode::WUSR | Mode::XUSR) {
                        Ok(()) | Err(Errno::EXIST) => {},
                        Err(error) => return Err(io_error(error)),
                    }
                    rustix::fs::openat(&directory, child_name, flags, Mode::empty()).map_err(io_error)?
                },
                Err(error) => return Err(io_error(error)),
            };
            let child: File = child.into();
            directory_is_trusted(&child, false)?;
            // Every accepted entry (including existing and mkdir-EEXIST) must cross both
            // barriers before descent; a previous failed initializer is not proof of sync.
            if durable {
                sync(&child)?;
                sync(&directory)?;
            }
            directory = child;
        }
        directory_is_trusted(&directory, true)?;
        Ok((directory, absolute))
    }

    fn parent(path: &Path, create: bool) -> Result<(File, OsString), CustodyError> {
        let absolute = absolute(path)?;
        let name = absolute.file_name().ok_or(CustodyError::UnsafePath)?.to_owned();
        // Dot-prefixed entries are exclusively uncommitted staging, never caller
        // finals. Otherwise a valid final could be renamed away as another's stage.
        if std::os::unix::ffi::OsStrExt::as_bytes(name.as_os_str()).first() == Some(&b'.') {
            return Err(CustodyError::UnsafePath);
        }
        let path = absolute.parent().ok_or(CustodyError::UnsafePath)?;
        let (directory, _) = directory(path, create, true)?;
        // ponytail: one blocking directory-wide publication lock; use per-artifact locks
        // only if real concurrent batch throughput needs them. Drop releases on all errors.
        rustix::fs::flock(&directory, FlockOperation::LockExclusive).map_err(io_error)?;
        directory_is_trusted(&directory, true)?;
        Ok((directory, name))
    }

    fn validate_file(file: &File) -> Result<(), CustodyError> {
        let metadata = file.metadata().map_err(|_| CustodyError::Io)?;
        if !metadata.is_file() || metadata.uid() != rustix::process::geteuid().as_raw()
            || metadata.nlink() != 1 || metadata.mode() & 0o7777 != 0o600
        {
            return Err(CustodyError::UnsafePath);
        }
        Ok(())
    }

    fn opened(directory: &File, name: &OsStr) -> Result<Option<File>, CustodyError> {
        match rustix::fs::openat(directory, name,
            OFlags::RDONLY | OFlags::NOFOLLOW | OFlags::CLOEXEC | OFlags::NONBLOCK, Mode::empty())
        {
            Ok(fd) => {
                let file: File = fd.into();
                validate_file(&file)?;
                Ok(Some(file))
            },
            Err(Errno::NOENT) => Ok(None),
            Err(error) => Err(io_error(error)),
        }
    }

    fn read(file: &File) -> Result<Zeroizing<Vec<u8>>, CustodyError> {
        let length = file.metadata().map_err(|_| CustodyError::Io)?.len();
        if length > MAX_ENVELOPE_BYTES as u64 {
            return Err(CustodyError::ResourceLimit);
        }
        // Fixed guarded storage: a file growing after metadata must not cause a
        // filled buffer to reallocate and free unwiped bytes on this read path.
        let mut bytes = Zeroizing::new(vec![0; length as usize]);
        let mut reader = file;
        reader.read_exact(&mut bytes).map_err(|_| CustodyError::Io)?;
        let mut extra = Zeroizing::new([0; 1]);
        if reader.read(&mut *extra).map_err(|_| CustodyError::Io)? != 0 {
            return Err(CustodyError::Io);
        }
        Ok(bytes)
    }

    fn is_same(envelope: &[u8], plaintext: &[u8]) -> bool {
        let end = envelope.len() - TAG_LEN;
        bool::from(envelope[HEADER_LEN..end].ct_eq(plaintext))
    }

    fn finish_publication(parent: &File, staging_name: &OsStr, name: &OsStr) -> Result<(), CustodyError> {
        rustix::fs::renameat_with(parent, staging_name, parent, name, RenameFlags::NOREPLACE)
            .map_err(|error| if error == Errno::EXIST { CustodyError::Conflict } else { io_error(error) })?;
        // A failed barrier after installation leaves final untouched. An authenticated
        // identical retry syncs file and parent rather than replacing its only copy.
        sync(parent)
    }

    pub(super) fn save(
        path: &Path, key: &[u8; 32], namespace: [u8; 32], context: [u8; 32],
        mut plaintext: Zeroizing<Vec<u8>>,
    ) -> Result<(), CustodyError> {
        let (parent, name) = parent(path, true)?;
        if let Some(final_file) = opened(&parent, &name)? {
            let mut envelope = read(&final_file)?;
            decrypt(&mut envelope, key, namespace, context)?;
            if !is_same(&envelope, &plaintext) { return Err(CustodyError::Conflict); }
            sync(&final_file)?;
            return sync(&parent);
        }
        let mut staging_name = OsString::from(".");
        staging_name.push(&name);
        staging_name.push(".pending");
        if let Some(stage) = opened(&parent, &staging_name)? {
            let mut envelope = read(&stage)?;
            match envelope_shape(&envelope) {
                Ok(EnvelopeShape::Complete) => {
                    decrypt(&mut envelope, key, namespace, context)?;
                    if !is_same(&envelope, &plaintext) { return Err(CustodyError::Conflict); }
                    sync(&stage)?;
                    return finish_publication(&parent, &staging_name, &name);
                },
                Ok(EnvelopeShape::Incomplete) => {
                    // Only a reserved, owner-private, known interrupted envelope can be
                    // removed; complete authentication failures/unknown bytes stay intact.
                    rustix::fs::unlinkat(&parent, &staging_name, AtFlags::empty()).map_err(io_error)?;
                    sync(&parent)?;
                },
                Err(CustodyError::UnsupportedVersion) => return Err(CustodyError::UnsupportedVersion),
                Err(_) => return Err(CustodyError::Conflict),
            }
        }
        let mut header = [0; HEADER_LEN];
        header[..DOMAIN.len()].copy_from_slice(DOMAIN);
        OsRng.try_fill_bytes(&mut header[DOMAIN.len()..DOMAIN.len() + NONCE_LEN])
            .map_err(|_| CustodyError::Io)?;
        let cipher_len = plaintext.len().checked_add(TAG_LEN).ok_or(CustodyError::ResourceLimit)?;
        if cipher_len > MAX_PLAINTEXT_BYTES + TAG_LEN { return Err(CustodyError::ResourceLimit); }
        header[HEADER_LEN - 4..].copy_from_slice(&(cipher_len as u32).to_le_bytes());
        XChaCha20Poly1305::new(key.into()).encrypt_in_place(
            XNonce::from_slice(&header[DOMAIN.len()..DOMAIN.len() + NONCE_LEN]),
            &aad(&header, namespace, context),
            &mut *plaintext,
        ).map_err(|_| CustodyError::Authentication)?;
        let mut stage: File = rustix::fs::openat(&parent, &staging_name,
            OFlags::WRONLY | OFlags::CREATE | OFlags::EXCL | OFlags::NOFOLLOW | OFlags::CLOEXEC | OFlags::NONBLOCK,
            Mode::RUSR | Mode::WUSR,
        ).map_err(io_error)?.into();
        validate_file(&stage)?;
        stage.write_all(&header).map_err(|_| CustodyError::Io)?;
        stage.write_all(&plaintext).map_err(|_| CustodyError::Io)?;
        sync(&stage)?;
        finish_publication(&parent, &staging_name, &name)
    }

    pub(super) fn load(path: &Path, key: &[u8; 32], namespace: [u8; 32], context: [u8; 32]) -> Result<PrivatePreparation, CustodyError> {
        let (parent, name) = parent(path, false)?;
        let file = opened(&parent, &name)?.ok_or(CustodyError::NotFound)?;
        let artifact = decrypt(&mut read(&file)?, key, namespace, context)?;
        // Recovery completes a formerly indeterminate publication before success.
        sync(&file)?;
        sync(&parent)?;
        Ok(artifact)
    }
}
