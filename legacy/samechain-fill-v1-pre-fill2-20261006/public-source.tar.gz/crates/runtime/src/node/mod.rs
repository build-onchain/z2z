//! Bounded authenticated direct-peer transport only. No financial identity,
//! order book, owner secrets, SQL, proving, chain actions or recovery lifecycle.
mod config;
#[cfg(target_os = "linux")]
mod discovery;
#[cfg(target_os = "linux")]
mod network;
#[cfg(target_os = "linux")]
mod reconnect;

use clap::{Parser, Subcommand};
use std::{ffi::OsString, process::ExitCode};

#[derive(Parser)]
#[command(
    name = "z2z-node",
    version,
    about = "Direct TCP/Noise/yamux peer transport; ephemeral identity, no trading or proofs"
)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Run authenticated direct-peer transport until Ctrl-C or an explicit duration.
    Run(config::Options),
}

type Result<T, E = Error> = std::result::Result<T, E>;

#[derive(Debug)]
enum Error {
    Configuration,
    Transport,
    Signal,
    Output,
    OutputBackpressure,
    #[cfg(not(target_os = "linux"))]
    UnsupportedPlatform,
}

impl std::fmt::Display for Error {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        #[cfg(not(target_os = "linux"))]
        if matches!(self, Self::UnsupportedPlatform) {
            return formatter.write_str("node transport requires Linux nonblocking public output");
        }
        write!(formatter, "node rejected: {self:?}")
    }
}

impl std::error::Error for Error {}

#[cfg(target_os = "linux")]
fn diagnostic(error: &Error) {
    let message: &[u8] = match error {
        Error::Configuration => b"node rejected: Configuration\n",
        Error::Transport => b"node rejected: Transport\n",
        Error::Signal => b"node rejected: Signal\n",
        Error::Output => b"node rejected: Output\n",
        Error::OutputBackpressure => b"node rejected: OutputBackpressure\n",
    };
    let stderr = std::io::stderr();
    let Ok(original) = rustix::fs::fcntl_getfl(&stderr) else { return };
    if rustix::fs::fcntl_setfl(&stderr, original | rustix::fs::OFlags::NONBLOCK).is_err() {
        return;
    }
    // A full stderr (including stdout merged with 2>&1) cannot prevent exit.
    // Diagnostics are best-effort atomic pipe records, not a blocking fallback.
    for _ in 0..2 {
        match rustix::io::write(&stderr, message) {
            Err(rustix::io::Errno::INTR) => continue,
            _ => break,
        }
    }
    let _ = rustix::fs::fcntl_setfl(&stderr, original);
}

#[cfg(not(target_os = "linux"))]
fn diagnostic(_: &Error) {}

/// Parse only public transport options; this entry point has no owner capability.
pub fn run_cli(arguments: impl IntoIterator<Item = OsString>) -> ExitCode {
    let argv = std::iter::once(OsString::from("z2z-node")).chain(arguments);
    let cli = match Cli::try_parse_from(argv) {
        Ok(cli) => cli,
        Err(error) => {
            let code = error.exit_code();
            if error.print().is_err() {
                return ExitCode::FAILURE;
            }
            return ExitCode::from(code as u8);
        }
    };
    let Command::Run(options) = cli.command;
    let config = match config::Config::from_options(options) {
        Ok(config) => config,
        Err(error) => {
            diagnostic(&error);
            return ExitCode::from(2);
        }
    };
    #[cfg(target_os = "linux")]
    let result = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|_| Error::Transport)
        .and_then(|runtime| runtime.block_on(network::run(config)));
    #[cfg(not(target_os = "linux"))]
    let result: Result<()> = {
        let _ = config;
        Err(Error::UnsupportedPlatform)
    };
    match result {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            diagnostic(&error);
            ExitCode::FAILURE
        }
    }
}
