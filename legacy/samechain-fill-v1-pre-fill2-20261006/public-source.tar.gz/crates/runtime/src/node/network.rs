use super::{Error, Result, config, discovery, reconnect};
use futures_util::StreamExt;
use libp2p::{
    Multiaddr, PeerId, Swarm, SwarmBuilder, connection_limits,
    core::{Endpoint, transport::PortUse, upgrade::DeniedUpgrade},
    identify, multiaddr::Protocol, noise, ping,
    swarm::{
        ConnectionDenied, ConnectionHandler, ConnectionHandlerEvent, ConnectionId,
        DialError, FromSwarm, ListenError, NetworkBehaviour, SubstreamProtocol, SwarmEvent, THandler,
        THandlerInEvent, THandlerOutEvent, ToSwarm, dummy, handler::ConnectionEvent, behaviour::toggle::Toggle,
    },
    tcp, yamux,
};
use serde::Serialize;
use std::{
    collections::HashSet,
    convert::Infallible,
    fmt::Display,
    io::{Cursor, Write},
    num::{NonZeroU8, NonZeroUsize},
    task::{Context, Poll},
    time::Duration,
};

const IDENTIFY_PROTOCOL: &str = "/z2z/transport/1.0.0";

// Reject unknown identities before connection_limits, whose per-peer map keeps
// empty historical entries. No private owner identity is read or authenticated.
struct PeerCohort {
    maximum: usize,
    peers: HashSet<PeerId>,
}

impl PeerCohort {
    fn admit(&mut self, peer: PeerId) -> std::result::Result<DirectConnection, ConnectionDenied> {
        if !self.peers.contains(&peer) {
            if self.peers.len() == self.maximum {
                return Err(ConnectionDenied::new(PeerCapacity));
            }
            // ponytail: lifetime cohort is capped; restart to select new peers.
            // Discovery shares this ceiling; scalable rotation needs eviction-safe accounting.
            self.peers.insert(peer);
        }
        Ok(DirectConnection(dummy::ConnectionHandler))
    }
}

#[derive(Debug)]
struct PeerCapacity;
impl std::fmt::Display for PeerCapacity {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("peer capacity")
    }
}
impl std::error::Error for PeerCapacity {}

impl NetworkBehaviour for PeerCohort {
    type ConnectionHandler = DirectConnection;
    type ToSwarm = Infallible;

    fn handle_established_inbound_connection(
        &mut self, _: ConnectionId, peer: PeerId, _: &Multiaddr, _: &Multiaddr,
    ) -> std::result::Result<THandler<Self>, ConnectionDenied> {
        self.admit(peer)
    }

    fn handle_established_outbound_connection(
        &mut self, _: ConnectionId, peer: PeerId, _: &Multiaddr, _: Endpoint, _: PortUse,
    ) -> std::result::Result<THandler<Self>, ConnectionDenied> {
        self.admit(peer)
    }

    fn on_swarm_event(&mut self, _: FromSwarm) {}

    fn on_connection_handler_event(
        &mut self, _: PeerId, _: ConnectionId, event: THandlerOutEvent<Self>,
    ) {
        match event {}
    }

    fn poll(&mut self, _: &mut Context<'_>) -> Poll<ToSwarm<Self::ToSwarm, THandlerInEvent<Self>>> {
        Poll::Pending
    }
}

// Ping deliberately opts out of libp2p keepalive. Keep the owner's bounded direct
// connection until explicit shutdown, remote close or our ping-failure policy.
struct DirectConnection(dummy::ConnectionHandler);

impl ConnectionHandler for DirectConnection {
    type FromBehaviour = Infallible;
    type ToBehaviour = Infallible;
    type InboundProtocol = DeniedUpgrade;
    type OutboundProtocol = DeniedUpgrade;
    type InboundOpenInfo = ();
    type OutboundOpenInfo = ();

    fn listen_protocol(&self) -> SubstreamProtocol<Self::InboundProtocol> {
        self.0.listen_protocol()
    }

    fn connection_keep_alive(&self) -> bool {
        true
    }

    fn on_behaviour_event(&mut self, event: Infallible) {
        self.0.on_behaviour_event(event);
    }

    fn poll(
        &mut self, cx: &mut Context<'_>,
    ) -> Poll<ConnectionHandlerEvent<Self::OutboundProtocol, (), Self::ToBehaviour>> {
        self.0.poll(cx)
    }

    fn on_connection_event(
        &mut self, event: ConnectionEvent<Self::InboundProtocol, Self::OutboundProtocol>,
    ) {
        self.0.on_connection_event(event);
    }
}

#[derive(NetworkBehaviour)]
#[behaviour(to_swarm = "Event")]
struct Behaviour {
    cohort: PeerCohort,
    limits: connection_limits::Behaviour,
    ping: ping::Behaviour,
    identify: identify::Behaviour,
    discovery: Toggle<discovery::Discovery>,
}

// Keep only public authenticated identity and a comparison result from identify;
// never retain/log remote agent strings, addresses or arbitrary diagnostic text.
enum Event {
    Ping(ping::Event),
    Identified { peer: PeerId, protocol_matches: bool, supports_kad: bool },
    IdentifyFailed(PeerId),
    Ignore,
    Discovery(discovery::Event),
}

impl From<Infallible> for Event {
    fn from(event: Infallible) -> Self {
        match event {}
    }
}
impl From<ping::Event> for Event {
    fn from(event: ping::Event) -> Self {
        Self::Ping(event)
    }
}
impl From<discovery::Event> for Event {
    fn from(event: discovery::Event) -> Self { Self::Discovery(event) }
}
impl From<identify::Event> for Event {
    fn from(event: identify::Event) -> Self {
        match event {
            identify::Event::Received { peer_id, info, .. } => Self::Identified {
                peer: peer_id,
                protocol_matches: info.protocol_version == IDENTIFY_PROTOCOL,
                supports_kad: info.protocols.contains(&discovery::PROTOCOL),
            },
            identify::Event::Error { peer_id, .. } => Self::IdentifyFailed(peer_id),
            _ => Self::Ignore,
        }
    }
}

#[derive(Serialize)]
#[serde(tag = "event", rename_all = "snake_case")]
enum PublicEvent<'a> {
    NodeStarted {
        schema_version: u16,
        transport_only: bool,
        identity: &'static str,
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        max_peers: u32,
        features: [&'static str; 5],
        persistent_identity: bool,
        discovery_ready: bool,
        peer_discovery_enabled: bool,
        reconnect_enabled: bool,
        gossip_ready: bool,
        trading_ready: bool,
        backing_ready: bool,
        proof_ready: bool,
        recovery_ready: bool,
    },
    Listening {
        #[serde(serialize_with = "serialize_display")]
        address: &'a Multiaddr,
    },
    PeerConnected {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        connected_peers: usize,
    },
    PeerIdentified {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        protocol_matches: bool,
    },
    PeerPing {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        rtt_ms: u64,
    },
    PeerPingFailed {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        reason: &'static str,
    },
    PeerIdentifyFailed {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
    },
    PeerDisconnected {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        connected_peers: usize,
    },
    PeerRejected { reason: &'static str },
    DialFailed { reason: &'static str },
    PeerRetryScheduled {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        attempt: u8,
        delay_ms: u64,
    },
    PeerQueryStarted {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
    },
    PeerQueryResult {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
    },
    PeerQueryFailure {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        reason: &'static str,
    },
    PeerDiscovered {
        #[serde(serialize_with = "serialize_display")]
        peer_id: &'a PeerId,
        #[serde(serialize_with = "serialize_display")]
        address: &'a Multiaddr,
    },
    NodeStopped { reason: &'static str, connected_peers: usize },
}

fn serialize_display<T: Display, S: serde::Serializer>(value: &T, serializer: S) -> Result<S::Ok, S::Error> {
    serializer.collect_str(value)
}

struct Output {
    stdout: std::io::Stdout,
    original_flags: rustix::fs::OFlags,
}

impl Output {
    fn new() -> Result<Self> {
        let stdout = std::io::stdout();
        let original_flags = rustix::fs::fcntl_getfl(&stdout).map_err(|_| Error::Output)?;
        rustix::fs::fcntl_setfl(&stdout, original_flags | rustix::fs::OFlags::NONBLOCK)
            .map_err(|_| Error::Output)?;
        Ok(Self { stdout, original_flags })
    }
}

impl Drop for Output {
    fn drop(&mut self) {
        let _ = rustix::fs::fcntl_setfl(&self.stdout, self.original_flags);
    }
}

fn emit(output: &mut Output, event: PublicEvent<'_>) -> Result<()> {
    // One stack record below Linux PIPE_BUF: a nonblocking pipe write is atomic.
    // No buffered/blocking stdout worker or growing event queue survives shutdown.
    let mut bytes = [0_u8; 1024];
    let length = {
        let mut cursor = Cursor::new(bytes.as_mut_slice());
        serde_json::to_writer(&mut cursor, &event).map_err(|_| Error::Output)?;
        cursor.write_all(b"\n").map_err(|_| Error::Output)?;
        cursor.position() as usize
    };
    for _ in 0..2 {
        match rustix::io::write(&output.stdout, &bytes[..length]) {
            Ok(count) if count == length => return Ok(()),
            Err(rustix::io::Errno::INTR) => continue,
            Err(rustix::io::Errno::AGAIN) => return Err(Error::OutputBackpressure),
            _ => return Err(Error::Output),
        }
    }
    Err(Error::Output)
}

pub(super) async fn run(mut config: config::Config) -> Result<()> {
    let maximum = config.max_peers;
    let mut swarm = SwarmBuilder::with_new_identity()
        .with_tokio()
        .with_tcp(tcp::Config::default().nodelay(true), noise::Config::new, || {
            let mut config = yamux::Config::default();
            // The pinned wrapper selects its supported yamux 0.12 implementation
            // for this setter. It retains OnRead backpressure and Noise security.
            config.set_max_num_streams(8);
            config
        })
        .map_err(|_| Error::Transport)?
        .with_behaviour(|key| Behaviour {
            cohort: PeerCohort { maximum: maximum as usize, peers: HashSet::with_capacity(maximum as usize) },
            limits: connection_limits::Behaviour::new(
                connection_limits::ConnectionLimits::default()
                    .with_max_pending_incoming(Some(maximum))
                    .with_max_pending_outgoing(Some(maximum))
                    .with_max_established_incoming(Some(maximum))
                    .with_max_established_outgoing(Some(maximum))
                    .with_max_established(Some(maximum))
                    .with_max_established_per_peer(Some(1)),
            ),
            ping: ping::Behaviour::new(
                ping::Config::new().with_interval(Duration::from_secs(5)).with_timeout(Duration::from_secs(10)),
            ),
            identify: identify::Behaviour::new(
                identify::Config::new(IDENTIFY_PROTOCOL.to_owned(), key.public())
                    .with_agent_version(concat!("z2z-node/", env!("CARGO_PKG_VERSION")).to_owned())
                    .with_cache_size(0)
                    .with_push_listen_addr_updates(false),
            ),
            discovery: config.peer_discovery.then(|| discovery::Discovery::new(key.public().to_peer_id(), &config)).into(),
        })
        .map_err(|_| Error::Transport)?
        .with_swarm_config(|_| {
            // Poll the bounded connection futures inside the swarm itself: drop
            // cancels all of them, with no detached executor tasks to outlive run.
            libp2p::swarm::Config::without_executor()
                .with_notify_handler_buffer_size(NonZeroUsize::new(8).expect("nonzero constant"))
                .with_per_connection_event_buffer_size(8)
                .with_dial_concurrency_factor(NonZeroU8::new(1).expect("nonzero constant"))
                .with_max_negotiating_inbound_streams(4)
                .with_idle_connection_timeout(Duration::from_secs(30))
        })
        .with_connection_timeout(Duration::from_secs(10))
        .build();
    let local_peer = *swarm.local_peer_id();
    if config.find_peer == Some(local_peer) { return Err(Error::Configuration); }
    let listener = swarm.listen_on(config.listen).map_err(|_| Error::Transport)?;
    let mut output = Output::new()?;
    emit(&mut output, PublicEvent::NodeStarted {
        schema_version: 1,
        transport_only: true,
        identity: "ephemeral_transport",
        peer_id: &local_peer,
        max_peers: maximum,
        features: ["tcp", "noise", "yamux", "ping", "identify"],
        persistent_identity: false,
        discovery_ready: false,
        peer_discovery_enabled: config.peer_discovery,
        reconnect_enabled: config.reconnect,
        gossip_ready: false,
        trading_ready: false,
        backing_ready: false,
        proof_ready: false,
        recovery_ready: false,
    })?;
    let mut reconnect = config.reconnect.then(|| {
        reconnect::Reconnect::new(std::mem::take(&mut config.dial), maximum as usize)
    });
    if let Some(reconnect) = &mut reconnect {
        for index in 0..reconnect.len() {
            direct_dial(&mut swarm, &mut output, reconnect, index, false)?;
        }
    } else {
        for address in config.dial {
            let peer = config::dial_peer(&address);
            let options = libp2p::swarm::dial_opts::DialOpts::peer_id(peer).addresses(vec![address]).build();
            if let Err(error) = swarm.dial(options) {
                emit(&mut output, PublicEvent::DialFailed { reason: dial_reason(&error) })?;
            }
        }
    }
    let signal = tokio::signal::ctrl_c();
    let duration = async {
        match config.run_for_ms {
            Some(ms) => tokio::time::sleep(Duration::from_millis(ms)).await,
            None => std::future::pending::<()>().await,
        }
    };
    tokio::pin!(signal, duration);
    let reason = loop {
        let retry_deadline = reconnect.as_ref().and_then(reconnect::Reconnect::deadline);
        let retry = async {
            match retry_deadline {
                Some(deadline) => tokio::time::sleep_until(deadline).await,
                None => std::future::pending::<()>().await,
            }
        };
        tokio::select! {
            biased;
            result = &mut signal => {
                result.map_err(|_| Error::Signal)?;
                break "ctrl_c";
            }
            () = &mut duration => break "duration_elapsed",
            event = swarm.next() => handle_event(&mut swarm, &mut output, &mut reconnect, event.ok_or(Error::Transport)?, false)?,
            () = retry => {
                if let Some(reconnect) = &mut reconnect
                    && let Some(index) = reconnect.due(tokio::time::Instant::now())
                {
                    direct_dial(&mut swarm, &mut output, reconnect, index, true)?;
                }
            }
        }
    };
    if let Some(reconnect) = &mut reconnect { reconnect.stop(); }
    if let Some(discovery) = swarm.behaviour_mut().discovery.as_mut() {
        discovery.stop();
    }
    swarm.remove_listener(listener);
    let peers: Vec<_> = swarm.connected_peers().copied().collect();
    for peer in peers {
        let _ = swarm.disconnect_peer_id(peer);
    }
    let grace = tokio::time::sleep(Duration::from_secs(1));
    tokio::pin!(grace);
    while swarm.connected_peers().next().is_some() {
        tokio::select! {
            () = &mut grace => break,
            event = swarm.next() => handle_event(&mut swarm, &mut output, &mut reconnect, event.ok_or(Error::Transport)?, true)?,
        }
    }
    let remaining: Vec<_> = swarm.connected_peers().copied().collect();
    drop(swarm); // Owned connection and handshake futures/sockets are closed here.
    for (index, peer) in remaining.iter().enumerate() {
        emit(&mut output, PublicEvent::PeerDisconnected {
            peer_id: peer, connected_peers: remaining.len() - index - 1,
        })?;
    }
    emit(&mut output, PublicEvent::NodeStopped { reason, connected_peers: 0 })
}

fn scheduled(output: &mut Output, scheduled: Option<reconnect::Scheduled>) -> Result<()> {
    if let Some(scheduled) = scheduled {
        emit(output, PublicEvent::PeerRetryScheduled {
            peer_id: &scheduled.peer, attempt: scheduled.attempt, delay_ms: scheduled.delay_ms,
        })?;
    }
    Ok(())
}

fn direct_dial(
    swarm: &mut Swarm<Behaviour>, output: &mut Output, reconnect: &mut reconnect::Reconnect,
    index: usize, retry: bool,
) -> Result<()> {
    let options = reconnect.begin(index);
    let id = options.connection_id();
    match swarm.dial(options) {
        Ok(()) => reconnect.accepted(index, retry),
        Err(error) => {
            emit(output, PublicEvent::DialFailed { reason: dial_reason(&error) })?;
            scheduled(output, reconnect.failed(id, &error, tokio::time::Instant::now()))?;
        }
    }
    Ok(())
}

fn handle_event(
    swarm: &mut Swarm<Behaviour>, output: &mut Output, reconnect: &mut Option<reconnect::Reconnect>,
    event: SwarmEvent<Event>, stopping: bool,
) -> Result<()> {
    match event {
        SwarmEvent::NewListenAddr { mut address, .. } if !stopping => {
            address.push(Protocol::P2p(*swarm.local_peer_id()));
            emit(output, PublicEvent::Listening { address: &address })?;
        }
        SwarmEvent::ConnectionEstablished { peer_id, connection_id, .. } => {
            if !stopping && let Some(reconnect) = reconnect {
                reconnect.established(peer_id, connection_id);
            }
            emit(output, PublicEvent::PeerConnected { peer_id: &peer_id, connected_peers: swarm.connected_peers().count() })?;
            if stopping {
                let _ = swarm.disconnect_peer_id(peer_id);
            }
        }
        SwarmEvent::ConnectionClosed { peer_id, num_established, .. } => {
            if !stopping && num_established == 0 && !swarm.is_connected(&peer_id)
                && let Some(reconnect) = reconnect
            {
                scheduled(output, reconnect.closed(peer_id, tokio::time::Instant::now()))?;
            }
            emit(output, PublicEvent::PeerDisconnected { peer_id: &peer_id, connected_peers: swarm.connected_peers().count() })?;
        }
        SwarmEvent::Behaviour(Event::Ping(ping::Event { peer, result, .. })) => match result {
            Ok(rtt) => emit(output, PublicEvent::PeerPing { peer_id: &peer, rtt_ms: rtt.as_millis() as u64 })?,
            Err(error) => {
                let reason = match error {
                    ping::Failure::Timeout => "timeout",
                    ping::Failure::Unsupported => "unsupported",
                    ping::Failure::Other { .. } => "io_or_protocol",
                };
                emit(output, PublicEvent::PeerPingFailed { peer_id: &peer, reason })?;
                let _ = swarm.disconnect_peer_id(peer);
            }
        },
        SwarmEvent::Behaviour(Event::Identified { peer, protocol_matches, supports_kad }) => {
            emit(output, PublicEvent::PeerIdentified { peer_id: &peer, protocol_matches })?;
            if !stopping && let Some(discovery) = swarm.behaviour_mut().discovery.as_mut() {
                discovery.identified(peer, protocol_matches && supports_kad);
            }
        }
        SwarmEvent::Behaviour(Event::IdentifyFailed(peer)) => {
            emit(output, PublicEvent::PeerIdentifyFailed { peer_id: &peer })?;
        }
        SwarmEvent::Behaviour(Event::Discovery(event)) if !stopping => match event {
            discovery::Event::Started(peer) => emit(output, PublicEvent::PeerQueryStarted { peer_id: &peer })?,
            discovery::Event::Result(peer) => emit(output, PublicEvent::PeerQueryResult { peer_id: &peer })?,
            discovery::Event::Failure { peer, reason } => emit(output, PublicEvent::PeerQueryFailure { peer_id: &peer, reason })?,
            discovery::Event::Candidate { peer, address } => emit(output, PublicEvent::PeerDiscovered { peer_id: &peer, address: &address })?,
        },
        SwarmEvent::Dialing { peer_id: Some(peer), connection_id } if !stopping => {
            if let Some(reconnect) = reconnect { reconnect.dialing(peer, connection_id); }
        }
        SwarmEvent::OutgoingConnectionError { connection_id, error, .. } => {
            emit(output, PublicEvent::DialFailed { reason: dial_reason(&error) })?;
            if !stopping && let Some(reconnect) = reconnect {
                scheduled(output, reconnect.failed(connection_id, &error, tokio::time::Instant::now()))?;
            }
        }
        SwarmEvent::IncomingConnectionError { error, .. } => {
            let reason = match &error {
                ListenError::Denied { cause } if capacity(cause) => "peer_capacity",
                _ => "handshake_failed",
            };
            emit(output, PublicEvent::PeerRejected { reason })?;
        }
        SwarmEvent::ListenerClosed { .. } | SwarmEvent::ListenerError { .. } if !stopping => {
            return Err(Error::Transport);
        }
        _ => {}
    }
    Ok(())
}

fn capacity(error: &ConnectionDenied) -> bool {
    error.downcast_ref::<PeerCapacity>().is_some()
        || error.downcast_ref::<connection_limits::Exceeded>().is_some()
}

fn dial_reason(error: &DialError) -> &'static str {
    match error {
        DialError::WrongPeerId { .. } => "peer_id_mismatch",
        DialError::Denied { cause } if capacity(cause) => "peer_capacity",
        DialError::LocalPeerId { .. } => "self_dial",
        _ => "unreachable_or_handshake_failed",
    }
}
