//! Owner-local fresh unsigned note creation and accepted fill recipient outputs.
//! This creates neither common private Terms nor consent, durable recovery,
//! proofs, root admission, spentness evidence or financial execution.
use ed25519_dalek::SigningKey;
use primitive_types::{U256, U512};
use std::fmt;
use zeroize::{Zeroize, Zeroizing};
use ziquid_proofs::samechain::{
    NoteOpening, OrderState, PreparedOutputOpening, RelationError, prepare_output,
};
use ziquid_proofs::samechain::creation::{NoteCreationWitness, review_note_creation};
use ziquid_protocol::samechain::creation::{InitialOrder, NoteCreationPacket};
use ziquid_protocol::samechain::{
    Asset, Deployment, MAX_OUTPUTS, OrderPolicy, OutputDescriptor, Role, SamechainError,
};

/// Public descriptors and confidential owner-local openings, not a wire format.
/// Opening indexes are local to `descriptors`; offset them when merging this
/// list into the full ordered manifest before constructing an OwnerWitness.
/// Retaining these erasing in-memory values does not qualify durable backup.
pub struct PreparedFillOutputs {
    pub descriptors: Vec<OutputDescriptor>,
    pub openings: Vec<PreparedOutputOpening>,
}

impl fmt::Debug for PreparedFillOutputs {
    fn fmt(&self, out: &mut fmt::Formatter<'_>) -> fmt::Result {
        out.write_str("PreparedFillOutputs([REDACTED])")
    }
}

/// Owner-local requested deposit terms, not a serializable private transport.
/// `amount` is public; optional capacity and policy remain owner-private.
pub struct CreationRequest {
    pub deployment: Deployment,
    pub token: [u8; 20],
    pub payer: [u8; 20],
    pub role: Role,
    pub asset: Asset,
    pub amount: U256,
    pub expiry: u64,
    pub order: Option<InitialOrderRequest>,
}

/// Initial private backing policy; identity is freshly generated, generation one.
pub struct InitialOrderRequest {
    pub remaining_sell: U256,
    pub policy: OrderPolicy,
}

impl fmt::Debug for CreationRequest {
    fn fmt(&self, out: &mut fmt::Formatter<'_>) -> fmt::Result {
        out.write_str("CreationRequest([REDACTED])")
    }
}

impl fmt::Debug for InitialOrderRequest {
    fn fmt(&self, out: &mut fmt::Formatter<'_>) -> fmt::Result {
        out.write_str("InitialOrderRequest([REDACTED])")
    }
}

impl Drop for InitialOrderRequest {
    fn drop(&mut self) {
        self.remaining_sell.0.zeroize();
        // The owned policy erases itself through its existing Drop.
    }
}

/// Construct and retain a fresh owner-local unsigned capability in erasing memory.
/// The caller must independently select/review its complete public packet before
/// consent. This self-check is not authorization, backup, proof or asset receipt.
pub fn prepare_note_creation(request: &CreationRequest)
    -> Result<NoteCreationWitness, RelationError>
{
    request.deployment.validate()?;
    if request.token == [0; 20]
        || matches!(request.asset, Asset::Token(token) if token != request.token)
    {
        return Err(SamechainError::InvalidAsset.into());
    }
    if request.payer == [0; 20] || request.amount.is_zero() || request.expiry == 0 {
        return Err(SamechainError::InvalidTerms.into());
    }
    if let Some(order) = &request.order {
        order.policy.validate_for(request.role)?;
        if order.remaining_sell.is_zero() || order.remaining_sell > request.amount
            || order.policy.sell_asset != request.asset
        {
            return Err(RelationError::Note);
        }
        let opposite = match request.asset {
            Asset::Native => Asset::Token(request.token),
            Asset::Token(_) => Asset::Native,
        };
        if order.policy.buy_asset != opposite { return Err(RelationError::Policy); }
    }
    // Install the complete erasing witness before any entropy or secret-bearing
    // fallible operation. Never validate, hash or encode this internal placeholder.
    let mut witness = NoteCreationWitness {
        packet: NoteCreationPacket {
            deployment: request.deployment, token: request.token, payer: request.payer,
            creation_nonce: [0; 32], owner_key: [0; 32], role: request.role,
            asset: request.asset, amount: request.amount, order: None,
            output: OutputDescriptor::Note { role: request.role, commitment: [0; 32],
                recovery_key_commitment: [0; 32], ciphertext_version: 0, ciphertext: Vec::new() },
            expiry: request.expiry, terms_commitment: [0; 32],
        },
        blind: [0; 32], owner_seed: [0; 32],
        note: NoteOpening { deployment_digest: [0; 32], owner_key: [0; 32],
            nf_key: [0; 32], nonce: [0; 32], salt: [0; 32], asset: request.asset,
            value: request.amount, order: request.order.as_ref().map(|order| OrderState {
                id: [0; 32], generation: 1, remaining_sell: order.remaining_sell,
                policy: order.policy.clone(),
            }) },
        recovery_key: [0; 32], consent: [0; 64],
    };
    witness.note.deployment_digest = request.deployment.digest()?;
    fill_nonzero(&mut witness.owner_seed)?;
    witness.packet.owner_key = SigningKey::from_bytes(&witness.owner_seed).verifying_key().to_bytes();
    witness.note.owner_key = witness.packet.owner_key;
    fill_nonzero(&mut witness.packet.creation_nonce)?;
    if let Some(order) = &mut witness.note.order {
        fill_nonzero(&mut order.id)?;
        witness.packet.order = Some(InitialOrder { id: order.id });
    }
    fill_nonzero(&mut witness.note.nf_key)?;
    fill_nonzero(&mut witness.note.nonce)?;
    fill_nonzero(&mut witness.note.salt)?;
    fill_nonzero(&mut witness.recovery_key)?;
    fill_nonzero(&mut witness.blind)?;
    let mut nonce = Zeroizing::new([0; 24]);
    fill_nonzero(&mut nonce[..])?;
    witness.packet.output = prepare_output(&witness.note, request.role,
        &witness.recovery_key, *nonce)?;
    witness.packet.terms_commitment = witness.packet.terms_commitment_for(&witness.blind)?;
    // Check against the borrowed selection, including the fixed token even for
    // Native creation and the private policy/capacity omitted from public terms.
    let packet = &witness.packet;
    if packet.deployment != request.deployment || packet.token != request.token
        || packet.payer != request.payer || packet.role != request.role
        || packet.asset != request.asset || packet.amount != request.amount
        || packet.expiry != request.expiry
    {
        return Err(RelationError::Manifest);
    }
    match (&request.order, &witness.note.order) {
        (None, None) => {}
        (Some(expected), Some(actual)) if actual.remaining_sell == expected.remaining_sell
            && actual.policy == expected.policy => {}
        _ => return Err(RelationError::Note),
    }
    // The generated nonce is a construction self-check input, not an independent
    // owner authorization choice; later packet selection freezes nonce/id/output.
    review_note_creation(packet, &witness, &request.deployment,
        request.payer, packet.creation_nonce)?;
    Ok(witness)
}

/// Prepare only this owner's recipient notes, with no other owner's secrets.
/// `fees` must be an explicit own-role Fee-only slice; returned descriptors do
/// not include those caller-owned fees. Exits are outside this API's scope.
/// The caller must independently establish complete Terms/blind and review the
/// exact assembled packet with `review_owner_fill` before authorizing anything.
pub fn prepare_fill_outputs(
    input: &NoteOpening, expected_deployment: &Deployment, expected_order_id: [u8; 32],
    role: Role, sold: U256, credit: U256, fees: &[OutputDescriptor],
) -> Result<PreparedFillOutputs, RelationError> {
    expected_deployment.validate()?;
    input.validate()?;
    let order = input.order.as_ref().ok_or(RelationError::Input)?;
    if input.deployment_digest != expected_deployment.digest()?
        || expected_order_id == [0; 32] || order.id != expected_order_id
    {
        return Err(RelationError::Input);
    }
    let policy = &order.policy;
    policy.validate_for(role)?;
    if sold.is_zero() || credit.is_zero() {
        return Err(SamechainError::InvalidTerms.into());
    }
    let remaining = order.remaining_sell.checked_sub(sold).ok_or(RelationError::Successor)?;
    if fees.len() > MAX_OUTPUTS { return Err(RelationError::ResourceLimit); }
    let mut sell_fees = U512::zero();
    let mut buy_fees = U512::zero();
    for fee in fees {
        let OutputDescriptor::Fee { payer, asset, amount, .. } = fee else {
            return Err(RelationError::Output);
        };
        if *payer != role { return Err(RelationError::Output); }
        if *asset == policy.sell_asset {
            sell_fees += U512::from(*amount);
        } else if *asset == policy.buy_asset {
            buy_fees += U512::from(*amount);
        } else {
            return Err(RelationError::Output);
        }
    }
    // The existing validator requires a nonempty complete manifest. An empty
    // accepted fee-only slice is valid; never weaken the financial validator.
    if !fees.is_empty() { policy.fee_policy.validate_fees(role, fees)?; }
    let residual = U512::from(input.value).checked_sub(U512::from(sold))
        .and_then(|value| value.checked_sub(sell_fees)).ok_or(RelationError::Conservation)?;
    let proceeds = U512::from(credit).checked_sub(buy_fees).ok_or(RelationError::Conservation)?;
    if proceeds * U512::from(policy.min_sell_den) < sold.full_mul(policy.min_buy_num) {
        return Err(SamechainError::LimitNotMet.into());
    }
    let residual = U256::try_from(residual).map_err(|_| RelationError::Conservation)?;
    let proceeds = U256::try_from(proceeds).map_err(|_| RelationError::Conservation)?;
    let successor = if remaining.is_zero() {
        None
    } else {
        if residual < remaining { return Err(RelationError::Successor); }
        Some(OrderState { id: order.id,
            generation: order.generation.checked_add(1).ok_or(RelationError::Successor)?,
            remaining_sell: remaining, policy: policy.clone() })
    };
    let input_nullifier = input.nullifier()?;
    let mut previous_nullifier = None;
    // At most sell remainder/change and buy proceeds. Allocate the complete
    // secret-bearing vector before filling any secret; never grow it afterward.
    let mut prepared = PreparedFillOutputs {
        descriptors: Vec::with_capacity(2), openings: Vec::with_capacity(2),
    };
    for (asset, value, order) in [
        (policy.sell_asset, residual, successor), (policy.buy_asset, proceeds, None),
    ] {
        if value.is_zero() { continue; }
        // Install Drop erasure guards before entropy calls or any fallible
        // cryptography so partial entropy failures erase the filled fields.
        let mut opening = PreparedOutputOpening {
            manifest_index: prepared.descriptors.len() as u32,
            note: NoteOpening { deployment_digest: input.deployment_digest,
                owner_key: input.owner_key, nf_key: [0; 32], nonce: [0; 32], salt: [0; 32],
                asset, value, order },
            recovery_key: [0; 32],
        };
        fill_nonzero(&mut opening.note.nf_key)?;
        fill_nonzero(&mut opening.note.nonce)?;
        fill_nonzero(&mut opening.note.salt)?;
        fill_nonzero(&mut opening.recovery_key)?;
        let mut nonce = Zeroizing::new([0; 24]);
        fill_nonzero(&mut nonce[..])?;
        let nullifier = opening.note.nullifier()?;
        if nullifier == input_nullifier || previous_nullifier == Some(nullifier) {
            return Err(RelationError::Output);
        }
        let descriptor = prepare_output(&opening.note, role, &opening.recovery_key, *nonce)?;
        prepared.descriptors.push(descriptor);
        prepared.openings.push(opening);
        previous_nullifier = Some(nullifier);
    }
    Ok(prepared)
}

fn fill_nonzero(bytes: &mut [u8]) -> Result<(), RelationError> {
    getrandom::fill(bytes).map_err(|_| RelationError::Key)?;
    if bytes.iter().all(|byte| *byte == 0) { return Err(RelationError::Key); }
    Ok(())
}
