//! Actual transport processes only: no wallets, SQL, proof jobs or order fixtures.
#![cfg(target_os = "linux")]
use serde_json::{Value, json};
use std::{
    io::{BufRead, BufReader},
    path::PathBuf,
    process::{Child, Command, ExitStatus, Output, Stdio},
    sync::mpsc::{self, Receiver},
    thread,
    time::{Duration, Instant},
};

fn binary() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_z2z-node"))
}

fn run(args: &[&str]) -> Output {
    Command::new(binary())
        .args(args)
        .output()
        .expect("the runnable z2z-node transport executable must exist")
}
fn events(output: &Output) -> Vec<Value> {
    std::str::from_utf8(&output.stdout)
        .unwrap()
        .lines()
        .map(|line| serde_json::from_str(line).expect("public transport output must be NDJSON"))
        .collect()
}

fn transport_only(started: &Value) {
    assert_eq!(started["event"], "node_started");
    assert_eq!(started["schema_version"], 1);
    assert_eq!(started["transport_only"], true);
    assert_eq!(started["identity"], "ephemeral_transport");
    assert!(started["peer_id"].as_str().is_some_and(|id| !id.is_empty()));
    for flag in [
        "persistent_identity", "discovery_ready", "gossip_ready", "trading_ready",
        "backing_ready", "proof_ready", "recovery_ready",
    ] {
        assert_eq!(started[flag], false, "transport must not imply {flag}");
    }
}

fn rejected(args: &[&str]) {
    let output = run(args);
    assert_eq!(output.status.code(), Some(2), "{:?}", output);
    assert!(output.stdout.is_empty(), "invalid configuration must not start a node");
    assert!(!output.stderr.is_empty());
}

struct Node {
    child: Child,
    receiver: Option<Receiver<Result<Value, String>>>,
    reader: Option<thread::JoinHandle<()>>,
    seen: Vec<Value>,
}

impl Node {
    fn start(args: &[&str]) -> Self {
        let mut child = Command::new(binary())
            .args(args)
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .expect("the runnable z2z-node transport executable must exist");
        let stdout = child.stdout.take().unwrap();
        let (sender, receiver) = mpsc::sync_channel(128);
        let reader = thread::spawn(move || {
            for line in BufReader::new(stdout).lines() {
                let event = line
                    .map_err(|error| error.to_string())
                    .and_then(|line| serde_json::from_str(&line).map_err(|error| error.to_string()));
                if sender.send(event).is_err() {
                    break;
                }
            }
        });
        Self { child, receiver: Some(receiver), reader: Some(reader), seen: Vec::new() }
    }

    fn event(&mut self, name: &str) -> Value {
        if let Some(event) = self.seen.iter().find(|event| event["event"] == name) {
            return event.clone();
        }
        let deadline = Instant::now() + Duration::from_secs(12);
        loop {
            let remaining = deadline.saturating_duration_since(Instant::now());
            let event = self.receiver.as_ref().unwrap().recv_timeout(remaining)
                .unwrap_or_else(|error| panic!("missing {name}: {error}; observed {:?}", self.seen))
                .expect("transport event must decode");
            let matches = event["event"] == name;
            self.seen.push(event.clone());
            if matches {
                return event;
            }
        }
    }

    fn exit(&mut self) -> ExitStatus {
        let deadline = Instant::now() + Duration::from_secs(4);
        loop {
            if let Some(status) = self.child.try_wait().unwrap() {
                return status;
            }
            assert!(Instant::now() < deadline, "node did not exit after shutdown");
            thread::sleep(Duration::from_millis(10));
        }
    }

    #[cfg(unix)]
    fn interrupt(&self) {
        assert!(Command::new("kill")
            .args(["-INT", &self.child.id().to_string()])
            .status().unwrap().success());
    }
}

impl Drop for Node {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        self.receiver.take();
        if let Some(reader) = self.reader.take() {
            let _ = reader.join();
        }
    }
}

#[test]
fn help_version_and_invalid_cli_do_not_start_transport() {
    for args in [["--help"], ["--version"]] {
        let output = run(&args);
        assert!(output.status.success());
        assert!(output.stderr.is_empty());
        assert!(String::from_utf8(output.stdout).unwrap().contains("z2z-node"));
    }
    for args in [
        vec![], vec!["run"], vec!["trade"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--unknown"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--max-peers", "0"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--max-peers", "65"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "0"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "3600001"],
        vec!["run", "--listen", "/ip4/127.0.0.1/udp/9"],
        vec!["run", "--listen", "/dns4/localhost/tcp/9"],
        vec!["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", "/ip4/127.0.0.1/tcp/9"],
    ] {
        rejected(&args);
    }
}

#[test]
fn strict_bounded_config_rejects_ambiguous_or_unbounded_inputs_before_start() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("public transport config.json");
    let config = path.to_str().unwrap();
    let valid = json!({
        "schema_version":1, "listen":"/ip4/127.0.0.1/tcp/0", "dial":[],
        "max_peers":8, "run_for_ms":100,
    });
    for (field, value) in [
        ("schema_version", json!(2)), ("schema_version", json!("1")),
        ("listen", json!({"tcp":null})), ("listen", json!("x".repeat(257))),
        ("max_peers", json!(0)), ("max_peers", json!(65)),
        ("run_for_ms", json!(0)), ("run_for_ms", json!(3600001)),
        ("dial", json!(vec!["/ip4/127.0.0.1/tcp/9"; 65])),
        ("wallet_key", json!("PRIVATE_SENTINEL")),
    ] {
        let mut invalid = valid.clone();
        invalid[field] = value;
        std::fs::write(&path, serde_json::to_vec(&invalid).unwrap()).unwrap();
        rejected(&["run", "--config", config]);
    }
    for bytes in [
        br#"{"schema_version":1,"schema_version":1,"listen":"/ip4/127.0.0.1/tcp/0"}"#.as_slice(),
        br#"{"listen":"/ip4/127.0.0.1/tcp/0"}"#.as_slice(),
        br#"{"schema_version":1}"#.as_slice(),
        br#"{"schema_version":1,"listen":"/ip4/127.0.0.1/tcp/0"} trailing"#.as_slice(),
    ] {
        std::fs::write(&path, bytes).unwrap();
        rejected(&["run", "--config", config]);
    }
    std::fs::write(&path, vec![b' '; 16_385]).unwrap();
    rejected(&["run", "--config", config]);
    std::fs::write(&path, serde_json::to_vec(&valid).unwrap()).unwrap();
    rejected(&["run", "--config", config, "--listen", "/ip4/127.0.0.1/tcp/0"]);
    rejected(&["run", "--config", config, "--max-peers", "4"]);
    rejected(&["run", "--config", config, "--run-for-ms", "200"]);
    let output = run(&["run", "--config", config]);
    assert!(output.status.success(), "{:?}", output);
    assert!(output.stderr.is_empty());
    let observed = events(&output);
    transport_only(&observed[0]);
    assert_eq!(observed[0]["max_peers"], 8);
    assert!(observed.iter().any(|event| event["event"] == "listening"));
    assert_eq!(observed.last().unwrap()["reason"], "duration_elapsed");
}

#[test]
fn finite_no_peer_run_is_honest_and_terminates_without_background_workers() {
    let mut node = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--max-peers", "1", "--run-for-ms", "200",
    ]);
    transport_only(&node.event("node_started"));
    let address = node.event("listening")["address"].as_str().unwrap().to_owned();
    assert!(address.starts_with("/ip4/127.0.0.1/tcp/"));
    assert!(address.contains("/p2p/"));
    let stopped = node.event("node_stopped");
    assert_eq!(stopped["reason"], "duration_elapsed");
    assert_eq!(stopped["connected_peers"], 0);
    assert!(!node.seen.iter().any(|event| event["event"] == "peer_connected" || event["event"] == "peer_ping"));
    assert!(node.exit().success());
}

#[test]
#[cfg(unix)]
fn two_loopback_processes_authenticate_identify_ping_disconnect_and_handle_ctrl_c() {
    let mut listener = Node::start(&["run", "--listen", "/ip4/127.0.0.1/tcp/0"]);
    let listener_started = listener.event("node_started");
    transport_only(&listener_started);
    let address = listener.event("listening")["address"].as_str().unwrap().to_owned();
    let mut dialer = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &address, "--run-for-ms", "2500",
    ]);
    let dialer_started = dialer.event("node_started");
    transport_only(&dialer_started);
    assert_ne!(listener_started["peer_id"], dialer_started["peer_id"]);
    for (node, expected) in [
        (&mut listener, &dialer_started["peer_id"]),
        (&mut dialer, &listener_started["peer_id"]),
    ] {
        assert_eq!(node.event("peer_connected")["peer_id"], *expected);
        assert_eq!(node.event("peer_identified")["peer_id"], *expected);
        let ping = node.event("peer_ping");
        assert_eq!(ping["peer_id"], *expected);
        assert!(ping["rtt_ms"].as_u64().is_some());
    }
    assert_eq!(dialer.event("node_stopped")["reason"], "duration_elapsed");
    assert!(dialer.exit().success());
    assert_eq!(listener.event("peer_disconnected")["peer_id"], dialer_started["peer_id"]);
    listener.interrupt();
    let stopped = listener.event("node_stopped");
    assert_eq!(stopped["reason"], "ctrl_c");
    assert_eq!(stopped["connected_peers"], 0);
    assert!(listener.exit().success());
}

#[test]
#[cfg(unix)]
fn peer_cap_keeps_existing_peer_and_never_admits_a_second_connection() {
    let mut listener = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--max-peers", "1",
    ]);
    let address = listener.event("listening")["address"].as_str().unwrap().to_owned();
    let mut first = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &address,
    ]);
    let first_peer = first.event("node_started")["peer_id"].clone();
    assert_eq!(listener.event("peer_connected")["peer_id"], first_peer);
    listener.event("peer_ping");
    let mut extra = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &address, "--run-for-ms", "1000",
    ]);
    extra.event("node_stopped");
    assert!(extra.exit().success());
    first.interrupt();
    assert_eq!(first.event("node_stopped")["reason"], "ctrl_c");
    assert!(first.exit().success());
    assert_eq!(listener.event("peer_disconnected")["peer_id"], first_peer);
    // Freeing an active slot cannot grow the process's bounded identity cohort.
    let mut unfamiliar = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &address, "--run-for-ms", "1000",
    ]);
    unfamiliar.event("node_stopped");
    assert!(unfamiliar.exit().success());
    assert_eq!(listener.event("peer_rejected")["reason"], "peer_capacity");
    listener.interrupt();
    listener.event("node_stopped");
    assert!(listener.exit().success());
    let admitted: Vec<_> = listener.seen.iter()
        .filter(|event| event["event"] == "peer_connected").collect();
    assert_eq!(admitted.len(), 1);
    assert_eq!(admitted[0]["peer_id"], first_peer);
}

#[test]
fn expected_peer_id_mismatch_never_becomes_an_authenticated_connection() {
    let unrelated = run(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "100",
    ]);
    assert!(unrelated.status.success());
    let wrong_peer = events(&unrelated)[0]["peer_id"].as_str().unwrap().to_owned();
    let mut listener = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "4000",
    ]);
    let address = listener.event("listening")["address"].as_str().unwrap().to_owned();
    let (tcp, _) = address.rsplit_once("/p2p/").unwrap();
    let wrong_address = format!("{tcp}/p2p/{wrong_peer}");
    let mut dialer = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &wrong_address, "--run-for-ms", "1000",
    ]);
    assert_eq!(dialer.event("dial_failed")["reason"], "peer_id_mismatch");
    dialer.event("node_stopped");
    assert!(dialer.exit().success());
    assert!(!dialer.seen.iter().any(|event| event["event"] == "peer_connected"));
}

#[test]
fn occupied_listen_address_exits_with_transport_error_not_success() {
    let occupied = std::net::TcpListener::bind((std::net::Ipv4Addr::LOCALHOST, 0)).unwrap();
    let address = format!("/ip4/127.0.0.1/tcp/{}", occupied.local_addr().unwrap().port());
    let output = run(&["run", "--listen", &address, "--run-for-ms", "100"]);
    assert_eq!(output.status.code(), Some(1), "{:?}", output);
    assert!(!output.stderr.is_empty());
    assert!(!events(&output).iter().any(|event| event["event"] == "listening"));
}

#[test]
#[cfg(target_os = "linux")]
fn undrained_full_output_pipe_fails_without_hanging_or_torn_json() {
    use rustix::{fs::OFlags, pipe::{PipeFlags, pipe_with}};
    let (reader, writer) = pipe_with(PipeFlags::NONBLOCK | PipeFlags::CLOEXEC).unwrap();
    let fill = [b'x'; 4096];
    let mut filled = 0;
    loop {
        match rustix::io::write(&writer, &fill) {
            Ok(count) => filled += count,
            Err(rustix::io::Errno::AGAIN) => break,
            other => panic!("cannot fill owned test pipe: {other:?}"),
        }
    }
    assert!(filled >= fill.len());
    // The child must make its inherited blocking stdout nonblocking itself.
    rustix::fs::fcntl_setfl(&writer, OFlags::WRONLY).unwrap();
    let mut child = Command::new(binary())
        .args(["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "100"])
        .stdout(Stdio::from(writer)).stderr(Stdio::null()).spawn().unwrap();
    let deadline = Instant::now() + Duration::from_secs(3);
    let status = loop {
        if let Some(status) = child.try_wait().unwrap() {
            break status;
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            panic!("undrained stdout prevented bounded transport exit");
        }
        thread::sleep(Duration::from_millis(10));
    };
    assert_eq!(status.code(), Some(1));
    let mut drained = 0;
    let mut buffer = [0; 4096];
    loop {
        match rustix::io::read(&reader, &mut buffer) {
            Ok(0) => break,
            Ok(count) => {
                assert!(buffer[..count].iter().all(|byte| *byte == b'x'));
                drained += count;
            }
            Err(rustix::io::Errno::AGAIN) => break,
            other => panic!("cannot drain owned test pipe: {other:?}"),
        }
    }
    assert_eq!(drained, filled, "a full pipe must not receive partial NDJSON");
}

#[test]
fn merged_full_output_pipe_cannot_block_error_exit() {
    use rustix::{fs::OFlags, pipe::{PipeFlags, pipe_with}};
    let (reader, writer) = pipe_with(PipeFlags::NONBLOCK | PipeFlags::CLOEXEC).unwrap();
    let fill = [b'x'; 4096];
    let mut filled = 0;
    loop {
        match rustix::io::write(&writer, &fill) {
            Ok(count) => filled += count,
            Err(rustix::io::Errno::AGAIN) => break,
            other => panic!("cannot fill owned merged pipe: {other:?}"),
        }
    }
    rustix::fs::fcntl_setfl(&writer, OFlags::WRONLY).unwrap();
    let stderr = rustix::io::dup(&writer).unwrap();
    let mut child = Command::new(binary())
        .args(["run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "100"])
        .stdout(Stdio::from(writer)).stderr(Stdio::from(stderr)).spawn().unwrap();
    let deadline = Instant::now() + Duration::from_secs(3);
    let status = loop {
        if let Some(status) = child.try_wait().unwrap() {
            break status;
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            panic!("merged stdout/stderr prevented bounded transport error exit");
        }
        thread::sleep(Duration::from_millis(10));
    };
    assert_eq!(status.code(), Some(1));
    let mut buffer = [0; 4096];
    let mut drained = 0;
    loop {
        match rustix::io::read(&reader, &mut buffer) {
            Ok(0) => break,
            Ok(count) => {
                assert!(buffer[..count].iter().all(|byte| *byte == b'x'));
                drained += count;
            }
            Err(rustix::io::Errno::AGAIN) => break,
            other => panic!("cannot drain owned merged pipe: {other:?}"),
        }
    }
    assert_eq!(drained, filled, "full pipe must receive neither partial events nor diagnostics");
}

#[test]
fn healthy_authenticated_peer_survives_idle_window_until_explicit_shutdown() {
    let mut listener = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--run-for-ms", "45000",
    ]);
    let address = listener.event("listening")["address"].as_str().unwrap().to_owned();
    let mut dialer = Node::start(&[
        "run", "--listen", "/ip4/127.0.0.1/tcp/0", "--dial", &address, "--run-for-ms", "45000",
    ]);
    listener.event("peer_connected");
    dialer.event("peer_connected");
    listener.event("peer_ping");
    dialer.event("peer_ping");
    // A real process-clock boundary crosses the former 30-second idle timeout.
    // Continue consuming actual events; no test-only production timeout switch.
    let started = Instant::now();
    let mut late_ping = false;
    while started.elapsed() < Duration::from_secs(36) {
        let event = listener.receiver.as_ref().unwrap()
            .recv_timeout(Duration::from_secs(6)).expect("healthy peer stopped progressing")
            .expect("transport event must decode");
        assert_ne!(event["event"], "peer_disconnected", "healthy peer was dropped before caller shutdown");
        assert_ne!(event["event"], "node_stopped");
        if event["event"] == "peer_ping" && started.elapsed() > Duration::from_secs(32) {
            late_ping = true;
        }
        listener.seen.push(event);
    }
    assert!(late_ping, "no successful ping after the former idle window");
    dialer.interrupt();
    assert_eq!(dialer.event("node_stopped")["reason"], "ctrl_c");
    assert!(dialer.exit().success());
    listener.event("peer_disconnected");
    listener.interrupt();
    assert_eq!(listener.event("node_stopped")["reason"], "ctrl_c");
    assert!(listener.exit().success());
}
