#![no_main]
#[path="../../../src/samechain.rs"]mod samechain;
use ziquid_protocol::samechain::PublicPacket;
sp1_zkvm::entrypoint!(main);
pub fn main(){
 let input=zeroize::Zeroizing::new(sp1_zkvm::io::read_vec());assert!(input.len()<=1+4+65536+262144,"owner frame too large");
 let (mode,frame)=input.split_first().expect("missing owner mode");
 let journal=match mode{
  0=>{assert!(frame.len()>=4,"missing public packet length");let length=u32::from_be_bytes(frame[..4].try_into().unwrap())as usize;assert!(length<=65536,"public packet too large");let end=4usize.checked_add(length).expect("packet length overflow");let packet=PublicPacket::decode(frame.get(4..end).expect("truncated public packet")).expect("invalid public packet");let witness=samechain::OwnerWitness::decode(frame.get(end..).expect("truncated owner witness")).expect("invalid owner witness");samechain::verify_owner_relation(&packet,&witness).expect("owner bilateral relation failed").encode().expect("invalid owner journal")},
  1=>{let witness=samechain::CancelExitWitness::decode(frame).expect("invalid single owner witness");samechain::verify_cancel_exit_relation(&witness).expect("owner cancel exit relation failed").encode().expect("invalid owner journal")},
  2=>{let witness=samechain::withdrawal::NoteWithdrawalWitness::decode(frame).expect("invalid ordinary withdrawal witness");samechain::withdrawal::verify_note_withdrawal_relation(&witness).expect("ordinary withdrawal relation failed").encode().expect("invalid ordinary withdrawal journal")},
  3=>{let witness=samechain::creation::NoteCreationWitness::decode(frame).expect("invalid note creation witness");samechain::creation::verify_note_creation_relation(&witness).expect("note creation relation failed").encode().expect("invalid note creation journal")},
  _=>panic!("unsupported owner mode"),
 };
 sp1_zkvm::io::commit_slice(&journal);
}
