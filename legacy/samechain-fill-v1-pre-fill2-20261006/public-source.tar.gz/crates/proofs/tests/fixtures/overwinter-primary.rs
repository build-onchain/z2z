//! Original ZIP143 digest tuples; recorded transaction is in overwinter-mined.rs.
//! Expected digests are source literals, never computed by the code under test.
//! Digest vectors are not claims of consensus-valid or mined transactions.
//! The sibling mined fixture is isolated, not connected Overwinter history.
//
// Original combined extraction provenance below is retained unchanged; the
// transaction byte block and offsets moved verbatim to scoped sibling modules.
// All immutable sources retrieved 2026-10-03; offsets below are zero-based, half-open.
// zcash_primitives 0.30.1 cached original, byte-identical to pinned upstream:
// https://raw.githubusercontent.com/zcash/librustzcash/97aefdc39a037da9c4f19a0e8a450d2c7932f53e/zcash_primitives/src/transaction/tests/data.rs
// Original UTF8 bytes: 684905; Git blob SHA1: df009b2dabd2137ec4b6b1ef9ee63b34462dd465
// Original blob SHA256: 97e2a2e8c108f82a0b49b5445bebef001857f3dcd9dfdc3be60e1eaa60b7a2f1
// Original zcashd C digest oracle:
// https://raw.githubusercontent.com/zcash/zcash/0512e9eb00f97172346e0fac854625d59771e4f7/src/test/data/sighash.json
// Original UTF8 bytes: 3878177; Git blob SHA1: 12434b325dc1d8c99c398f471881f524439480b4
// Original blob SHA256: 6e10f3e5649c876a8968a3ba13885aeb8dcee8040fd89e7e39651b041d07f30c
// Original Zebra testnet block 207501:
// https://raw.githubusercontent.com/ZcashFoundation/zebra/e3eef2f37c35127ad1769f19a1ebc7eaa5d5d291/zebra-test/src/vectors/block-test-0-207-501.txt
// Original UTF8 bytes: 7543; Git blob SHA1: 62a03fa9588358c3f501cbd7302b12bfce7b0e89
// Original blob SHA256: 368a80e92d71b96931f26cce89eb9b23547cb7a67ab954e07b02c330ddb8e40e
// ZIP143 module UTF8 range 13292..181980, lines 142..1956;
// module SHA256: eab6089f00ad98d04b776dceea9cdd091b4c5fef7fbdc9f9ba8e70aec5a09e99
// C physical line 51 UTF8 range 390191..390716.
// C tuple: script53000053/input0/raw-i32 -865463971/branch1537743641/amount0.
// C expected display order: 60ce3ff808a1909a2abcd358309671a9953828761473dd5dd255443cb68a4d76
// Literal raw bytes after one display-order reversal: 764d8ab63c4455d25ddd731476283895a971963058d3bc2a9a90a108f83fce60
// C decoded tx SHA256: 8ef6edba6744b6eac6d73b7e2b6bd70ce20e438ce28d8ccfa0f0bacd7d9ee386
// Zebra original block is one7542-character hex line plus LF: decoded3771bytes.
// Decoded block SHA256: 86543feb898e975521cf14d338bd182a675a6f20253141e8df02dc951c801665
// Header range0..1487 (1344-byte Equihash solution); tx-count at1487 is3.
// Original tx ranges: 0=1488..1620, 1=1620..1854, 2=1854..3771.
// MINED_V3_TX_HEX is the original range1854..3771, not a reserialization.
// Original text character range3708..7542; decoded tx length1917.
// Original tx SHA256: 7c7dc59bd131a5d5b25c37f49ac22f87a3e590e75d06b271fc6bacfbf09285f5
// Display txid: 58b072f17a88e5786bc0f13a6f790f1ce4eb7049699571a6c59c0ef607a47777
// Parsing used a faithful read-only field/length translation of cached primitives:
// block.rs:133..162; transaction/mod.rs:82..106,736..841;
// transaction/components/sprout.rs:89..165; transparent0.10.0 bundle.rs:
// 263..272,385..397; encoding0.4.0 CompactSize::read:33..78.
// This data extraction performed no Rust build, tests, signature/proof verification,
// block consensus validation or implementation-generated digest calculation.
// Tx has zero vin/vout, one PHGR JoinSplit, vpub_old0/vpub_new10000,
// locktime0 and expiry207521. Relative offsets: vpub_old19/vpub_new27;
// anchor35; nullifiers67,99; commitments131,163; ephemeral_key195;
// random_seed227; macs259,291; PHGR323..619; ciphertexts619,1220;
// joinsplit_pubkey1821..1853; original signature1853..1917.
//
// Maintained vector source: MIT (also offered under Apache-2.0); MIT selected.
// https://raw.githubusercontent.com/zcash/librustzcash/97aefdc39a037da9c4f19a0e8a450d2c7932f53e/zcash_primitives/LICENSE-MIT
// The MIT License (MIT)
//
// Copyright (c) 2017-2019 Electric Coin Company
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// C tuple source: MIT.
// https://raw.githubusercontent.com/zcash/zcash/0512e9eb00f97172346e0fac854625d59771e4f7/COPYING
// Copyright (c) 2016-2019 The Zcash developers
// Copyright (c) 2009-2019 The Bitcoin Core developers
// Copyright (c) 2009-2019 Bitcoin Developers
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Zebra recorded block source: MIT (MIT selected).
// https://raw.githubusercontent.com/ZcashFoundation/zebra/e3eef2f37c35127ad1769f19a1ebc7eaa5d5d291/LICENSE-MIT
// Copyright (c) 2019-2025 Zcash Foundation
//
// Permission is hereby granted, free of charge, to any
// person obtaining a copy of this software and associated
// documentation files (the "Software"), to deal in the
// Software without restriction, including without
// limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of
// the Software, and to permit persons to whom the Software
// is furnished to do so, subject to the following
// conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
// ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
// SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
// CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
// IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.
//

pub struct DigestVector {
    pub tx_hex: &'static str,
    pub script_hex: &'static str,
    pub input_index: Option<usize>,
    pub amount: u64,
    pub raw_hash_type: i32,
    pub expected: [u8; 32],
}

pub const ZIP143_VECTORS: &[DigestVector] = &[
    // Maintained source tuple 0, original data.rs lines 161..178.
    DigestVector {
        tx_hex: "030000807082c4030002e7719811893e0000095200ac6551ac636565b2835a0805750200025151481cdd86b3cc431800",
        script_hex: "6a00000063ac53",
        input_index: None,
        amount: 1672704339313879,
        raw_hash_type: 1,
        expected: [
            0xa1, 0xf1, 0xa4, 0xe5, 0xcd, 0x9b, 0xd5, 0x22, 0x32, 0x2d, 0x66, 0x1e, 0xdd, 0x2a, 0xf1, 0xbf,
            0x2a, 0x70, 0x19, 0xcf, 0xab, 0x94, 0xec, 0xe1, 0x8f, 0x4b, 0xa9, 0x35, 0xb0, 0xa1, 0x90, 0x73,
        ],
    },
    // Maintained source tuple 1, original data.rs lines 179..488.
    DigestVector {
        tx_hex: concat!(
            "030000807082c403024201cfb1cd8dbf69b8250c18ef41294ca97993db546c1fe01f7e9c8e36d6a5e29d4e30a703ac6a",
            "0098421c69378af1e40f64e125946f62c2fa7b2fecbcb64b6968912a6381ce3dc166d56a1d62f5a8d7056363635353e8",
            "c7203d02d2da86387ae60100080063656a63ac5200a7622997f4ff0400075151005353656597b0e4e4c705fc05020000",
            "000000000000000000000000000076495c222f7fba1e31defa3d5a57efc2e1e9b01a035587d5fb1a38e01d94903d3c3e",
            "0ad3360c1d3710acd20b183e31d49f25c9a138f49b1a537edcf04be34a9851a7af9db6990ed83dd64af3597c04323ea5",
            "1b0052ad8084a8b9da948d320dadd64f5431e61ddf658d24ae67c22c8d1309131fc00fe7f235734276d38d47f1e191e0",
            "0c7a1d48af046827591e9733a97fa6b679f3dc601d008285edcbdae69ce8fc1be4aac00ff2711ebd931de518856878f7",
            "3476f21a482ec9378365c8f7393c94e2885315eb4671098b79535e790fe53e29fef2b3766697ac32b4f473f468a008e7",
            "2389fc03880d780cb07fcfaabe3f1a84b27db59a4a153d882d2b2103596555ed9494c6ac893c49723833ec8926c10395",
            "86a7afcf4a0d9c731e985d99589c03b838e8aaf745533ed9e8ae3a1cd074a51a20da8aba18d1dbebbc862ded42435e02",
            "476930d069896cff30eb414f727b89e001afa2fb8dc3436d75a4a6f26572504b0b2232ecb9f0c02411e52596bc5e9045",
            "7e745939ffedbd12863ce71a02af117d417adb3d15cc54dcb1fce467500c6b8fb86b12b56da9c382857deecc40a98d5f",
            "2903395ee4762dd21afdbb5d47fa9a6dd984d567db2857b927b7fae2db587105415d0242789d38f50b8dbcc129cab3d1",
            "7d19f3355bcf73cecb8cb8a5da01307152f13902a270572670dc82d39026c6cb4cd4b0f7f5aa2a4f5a5341ec5dd71540",
            "6f2fdd2a02733f5f641c8c21862a1bafce2609d9eecfa158cfb5cd79f88008e315dc7d8388036c1782fd2795d18a7636",
            "24c25fa959cc97489ce75745824b77868c53239cfbdf73caec65604037314faaceb56218c6bd30f8374ac13386793f21",
            "a9fb80ad03bc0cda4a44946c00e1b1a1df0e5b87b5bece477a709649e950060591394812951e1fe3895b8cc3d14d2cf6",
            "556df6ed4b4ddd3d9a69f53357d7767f4f5ccbdbc596631277f8fecd08cb056b95e3025b9792fff7f244fc716269b926",
            "d62e9596fa825c6bf21aff9e68625a192440ea06828123d97884806f15fa08da52754a1095e3ff1abd5ce4fddfccfc3a",
            "6128aef784a64610a89d1a7099216d0814d3a2d452431c32d411ac1cce82ad0229407bbc48985675e3f874a4533f1d63",
            "a84dfa3e0f460fe2f57e34fbc75423c3737f5b2a0615f5722db041a3ef66fa483afd3c2e19e59444a64add6df1d963f5",
            "dd5b5010d3d025f0287c4cf19c75f33d51ddddba5d657b43ee8da645443814cc7329f3e9b4e54c236c29af3923101756",
            "d9fa4bd0f7d2ddaacb6b0f86a2658e0a07a05ac5b950051cd24c47a88d13d659ba2a46ca1830816d09cd7646f76f716a",
            "bec5de07fe9b523410806ea6f288f8736c23357c85f45791e1708029d9824d90704607f387a03e49bf9836574431345a",
            "7877efaa8a08e73081ef8d62cb780ab6883a50a0d470190dfba10a857f82842d3825b3d6da0573d316eb160dc0b716c4",
            "8fbd467f75b780149ae8808f4e68f50c0536acddf6f1aeab016b6bc1ec144b4e553acfd670f77e755fc88e0677e31ba4",
            "59b44e307768958fe3789d41c2b1ff434cb30e15914f01bc6bc2307b488d2556d7b7380ea4ffd712f6b02fe806b94569",
            "cd4059f396bf29b99d0a40e5e1711ca944f72d436a102fca4b97693da0b086fe9d2e7162470d02e0f05d4bec9512bfb3",
            "f38327296efaa74328b118c27402c70c3a90b49ad4bbc68e37c0aa7d9b3fe17799d73b841e751713a02943905aae0803",
            "fd69442eb7681ec2a05600054e92eed555028f21b6a155268a2dd6640a69301a52a38d4d9f9f957ae35af7167118141c",
            "e4c9be0a6a492fe79f1581a155fa3a2b9dafd82e650b386ad3a08cb6b83131ac300b0846354a7eef9c410e4b62c47c54",
            "26907dfc6685c5c99b7141ac626ab4761fd3f41e728e1a28f89db89ffdeca364dd2f0f0739f0534556483199c71f1893",
            "41ac9b78a269164206a0ea1ce73bfb2a942e7370b247c046f8e75ef8e3f8bd821cf577491864e20e6d08fd2e32b555c9",
            "2c661f19588b72a89599710a88061253ca285b6304b37da2b5294f5cb354a894322848ccbdc7c2545b7da568afac87ff",
            "a005c312241c2d57f4b45d6419f0d2e2c5af33ae243785b325cdab95404fc7aed70525cddb41872cfcc214b13232edc7",
            "8609753dbff930eb0dc156612b9cb434bc4b693392deb87c530435312edcedc6a961133338d786c4a3e103f60110a16b",
            "1337129704bf4754ff6ba9fbe65951e610620f71cda8fc877625f2c5bb04cbe1228b1e886f4050afd8fe94e97d2e9e85",
            "c6bb748c0042d3249abb1342bb0eebf62058bf3de080d94611a3750915b5dc6c0b3899d41222bace760ee9c8818ded59",
            "9e34c56d7372af1eb86852f2a732104bdb750739de6c2c6e0f9eb7cb17f1942bfc9f4fd6ebb6b4cdd4da2bca26fac457",
            "8e9f543405acc7d86ff59158bd0cba3aef6f4a8472d144d99f8b8d1dedaa9077d4f01d4bb27bbe31d88fbefac3dcd479",
            "7563a26b1d61fcd9a464ab21ed550fe6fa09695ba0b2f10e00000000000000000000000000000000ea6468cc6e20a66f",
            "826e3d14c5006f0563887f5e1289be1b2004caca8d3f34d6e84bf59c1e04619a7c23a996941d889e4622a9b9b1d59d5e",
            "319094318cd405ba27b7e2c084762d31453ec4549a4d97729d033460fcf89d6494f2ffd789e98082ea5ce9534b3acd60",
            "fe49e37e4f666931677319ed89f85588741b3128901a93bd78e4be0225a9e2692c77c969ed0176bdf9555948cbd5a332",
            "d045de6ba6bf4490adfe7444cd467a09075417fcc0062e49f008c51ad4227439c1b4476ccd8e97862dab7be1e8d399c0",
            "5ef27c6e22ee273e15786e394c8f1be31682a30147963ac8da8d41d804258426a3f70289b8ad19d8de13be4eebe3bd4c",
            "8a6f55d6e0c373d456851879f5fbc282db9e134806bff71e11bc33ab75dd6ca067fb73a043b646a70339cab492838678",
            "6d2f24141ee120fdc34d6764eafc66880ee0204f53cc1167ed02b43a52dea3ca7cff8ef35cd8e6d7c111a68ef44bcd0c",
            "1513ad47ca61c659cc5d0a5b440f6b9f59aff66879bb6688fd2859362b182f207b3175961f6411a493bffd048e7d0d87",
            "d82fe6f990a2b0a25f5aa0111a6e68f37bf6f3ac2d26b84686e569038d99c1383597fad81193c4c1b16e6a90e2d507cd",
            "fe6fbdaa86163e9cf5de310003ca7e8da047b090db9f37952fbfee76af61668190bd52ed490e677b515d014384030721",
            "9c7c0ee7fc7bfc79f325644e4df4c0d7db08e9f0bd024943c705abff899403a605cfbc7ed746a7d3f7c37d9e8bdc433b",
            "7d79e08a12f738a8f0dbddfef2f26502f3e47d1b0fd11e6a13311fb799c79c641d9da43b33e7ad012e28255398789262",
            "275f1175be8462c01491c4d842406d0ec4282c9526174a09878fe8fdde33a29604e5e5e7b2a025d6650b97dbb52befb5",
            "9b1d30a57433b0a351474444099daa371046613260cf3354cfcdada663ece824ffd7e44393886a86165ddddf2b4c4177",
            "3554c86995269408b11e6737a4c447586f69173446d8e48bf84cbc000a807899973eb93c5e819aad669413f8387933ad",
            "1584aa35e43f4ecd1e2d0407c0b1b89920ffdfdb9bea51ac95b557af71b89f903f5d9848f14fcbeb1837570f544d6359",
            "eb23faf38a0822da36ce426c4a2fbeffeb0a8a2e297a9d19ba15024590e3329d9fa9261f9938a4032dd34606c9cf9f3d",
            "d33e576f05cd1dd6811c6298757d77d9e810abdb226afcaa4346a6560f8932b3181fd355d5d391976183f8d993888396",
            "32d6354f666d09d3e5629ea19737388613d38a34fd0f6e50ee5a0cc9677177f50028c141378187bd2819403fc534f800",
            "76e9380cb4964d3b6b45819d3b8e9caf54f051852d671bf8c1ffde2d1510756418cb4810936aa57e6965d6fb656a760b",
            "7f19adf96c173488552193b147ee58858033dac7cd0eb204c06490bbdedf5f7571acb2ebe76acef3f2a01ee987486dfe",
            "6c3f0a5e234c127258f97a28fb5d164a8176be946b8097d0e317287f33bf9c16f9a545409ce29b1f4273725fc0df02a0",
            "4ebae178b3414fb0a82d50deb09fcf4e6ee9d180ff4f56ff3bc1d3601fc2dc90d814c3256f4967d3a8d64c83fea339c5",
            "1f5a8e5801fbb97835581b602465dee04b5922c2761b54245bec0c9eef2db97d22b2b3556cc969fbb13d06509765a52b",
            "3fac54b93f421bf08e18d52ddd52cc1c8ca8adfaccab7e5cc2f4573fbbf8239bb0b8aedbf8dad16282da5c9125dba1c0",
            "59d0df8abf621078f02d6c4bc86d40845ac1d59710c45f07d585eb48b32fc0167ba256e73ca3b9311c62d109497957d8",
            "dbe10aa3e866b40c0baa2bc492c19ad1e6372d9622bf163fbffeaeee796a3cd9b6fbbfa4d792f34d7fd6e763cd5859dd",
            "26833d21d9bc5452bd19515dff9f4995b35bc0c1f876e6ad11f2452dc9ae85aec01fc56f8cbfda75a7727b75ebbd6bbf",
            "fb43b63a3b1b671e40feb0db002974a3c3b1a788567231bf6399ff89236981149d423802d2341a3bedb9ddcbac1fe7b6",
            "435e1479c72e7089d029e7fbbaf3cf37e9b9a6b776791e4c5e6fda57e8d5f14c8c35a2d270846b9dbe005cda16af4408",
            "f3ab06a916eeeb9c9594b70424a4c1d171295b6763b22f47f80b53ccbb904bd68fd65fbd3fbdea1035e98c21a7dbc91a",
            "9b5bc7690f05ec317c97f8764eb48e911d428ec8d861b708e8298acb62155145155ae95f0a1d1501034753146e22d05f",
            "586d7f6b4fe12dad9a17f5db70b1db96b8d9a83edadc966c8a5466b61fc998c31f1070d9a5c9a6d268d304fe6b8fd3b4",
            "010348611abdcbd49fe4f85b623c7828c71382e1034ea67bc8ae97404b0c50b2a04f559e49950afcb0ef462a2ae024b0",
            "f0224dfd73684b88c7fbe92d02b68f759c4752663cd7b97a14943649305521326bde085630864629291bae25ff8822a1",
            "4c4b666a9259ad0dc42a8290ac7bc7f53a16f379f758e5de750f04fd7cad47701c8597f97888bea6fa0bf2999956fbfd",
            "0ee68ec36e4688809ae231eb8bc4369f5fe1573f57e099d9c09901bf39caac48dc11956a8ae905ead86954547c448ae4",
            "3d315e669c4242da565938f417bf43ce7b2b30b1cd4018388e1a910f0fc41fb0877a5925e466819d375b0a912d4fe843",
            "b76ef6f223f0f7c894f38f7ab780dfd75f669c8c06cffa43eb47565a50e3b1fa45ad61ce9a1c4727b7aaa53562f523e7",
            "3952",
        ),
        script_hex: "53",
        input_index: Some(1),
        amount: 365293780364847,
        raw_hash_type: 3,
        expected: [
            0x23, 0x65, 0x2e, 0x76, 0xcb, 0x13, 0xb8, 0x5a, 0x0e, 0x33, 0x63, 0xbb, 0x5f, 0xca, 0x06, 0x1f,
            0xa7, 0x91, 0xc4, 0x0c, 0x53, 0x3e, 0xcc, 0xee, 0x89, 0x93, 0x64, 0xe6, 0xe6, 0x0b, 0xb4, 0xf7,
        ],
    },
    // Maintained source tuple 2, original data.rs lines 489..659.
    DigestVector {
        tx_hex: concat!(
            "030000807082c4030299a69fdf1c5ac7732146ee5e1d6b6ca9b9180f964cc9d0878ae1373524d7d510e58227df095153",
            "636a006aac516ab0f1856e28d5c8afb095ef6184fed651589022eeaea4c0ce1fa6f085092b04979489172b3ef8194a01",
            "63f5724d6b02dee136f3a9aa0200035252ac17b73f8d383e000006ac630053ac5104b47556af73b60801000000000000",
            "00000000000000000000e2321d146071789d2335934a680614e83562f82dfd405b54a45eb32c165448d4d5d61ca28595",
            "85369f53f1a137e9e82b67b8fdaf01bda54a317311896ae10280a032440c420a421e944d1e952b70d5826cd3b08b7db9",
            "630fe4fd5f22125de840fcc40b98038af11d55be25432597b4b65b9ec1c7a8bbfd052cbf7e1c1785314934b262d58537",
            "54f1f17771cfb7503072655753fa3f54ecc587e9f83b581916092df26e63e18994cb0db91a0bbdc7b6119b32222adf5e",
            "61d8d8ae89dae4954b54813bb33f08d562ba513fee1b09c0fcd516055419474dd7fda038a89c84ea7b9468287f0eb0c1",
            "0c4b132520194d3d8d5351fc10d09c15c8cc101aa1663bbf17b84111f38bb439f07353bdea3596d15e713e1e2e7d3f1c",
            "383135b47fa7f81f46df02902a404699ec912f5656c35b85763e4de583aecaa1dfd5d2677d9c8ffee877f60340a5ca0d",
            "67f6e554124739f805af876aeede53aa8b0f8e5604a73c30cbd09dad0a3d6f8a5dcc40def40797342113ba206fae8ebe",
            "4f3bc3caf69259e462eff9ba8b3f4bfaa1300c26925a8729cd32915bfc966086f0d5560bbe32a598c22adfb48c0372ba",
            "5d4287c0cefbacfd8ce195b4963c34a94bba7a175dae4bbe3ef4863d53700315090f47a068e227433f9e49d3aa09e356",
            "d8d66d0c0121e91a3c4aa3f27fa1b60396e2b41db908fdab8b18cc7304e94e970568f9421c0dbbbaf84598d972b0534f",
            "02a5e52670436aaa776ed2482ad703430201e53443c36dcfd34a0cb6637876105e03bf3bd58ec148cb64970e3223a91f",
            "71dfcfd5a04b667fbaf3d4b3b908b9828820dfecdd753750b5f9d2216e56c615272f854464c0ca4b1e85aedd038292c4",
            "e1a57744ebba010b9ebfbb011bd6f0b78805025d27f3c17746bae116c15d9f471f0f6288a150647b2afe9df7cccf01f5",
            "cde5f04680bbfed87f6cf429fb27ad6babe791766611cf5bc20e48bef119259b9b8a0e39c3df28cb9582ea338601cdc4",
            "81b32fb82adeebb3dade25d1a3df20c37e712506b5d996c49a9f0f30ddcb91fe9004e1e83294a6c9203d94e8dc2cbb44",
            "9de4155032604e47997016b304fd437d8235045e255a19b743a0a9f2e336b44cae307bb3987bd3e4e777fbb34c0ab8cc",
            "3d67466c0a88dd4ccad18a07a8d1068df5b629e5718d0f6df5c957cf71bb00a5178f175caca944e635c5159f738e2402",
            "a2d21aa081e10e456afb00b9f62416c8b9c0f7228f510729e0be3f305313d77f7379dc2af24869c6c74ee4471498861d",
            "192f0ff0f508285dab6b6a36ccf7d12256cc76b95503720ac672d08268d2cf7773b6ba2a5f664847bf707f2fc10c98f2",
            "f006ec22ccb5a8c8b7c40c7c2d49a6639b9f2ce33c25c04bc461e744dfa536b00d94baddf4f4d14044c695a33881477d",
            "f124f0fcf206a9fb2e65e304cdbf0c4d2390170c130ab849c2f22b5cdd3921640c8cf1976ae1010b0dfd9cb2543e45f9",
            "9749cc4d61f2e8aabfe98bd905fa39951b33ea769c45ab9531c57209862ad12fd76ba4807e65417b6cd12fa8ec916f01",
            "3ebb8706a96effeda06c4be24b04846392e9d1e6930eae01fa21fbd700583fb598b92c8f4eb8a61aa6235db60f2841cf",
            "3a1c6ab54c67066844711d091eb931a1bd6281aedf2a0e8fab18817202a9be06402ed9cc720c16bfe881e4df4255e87a",
            "fb7fc62f38116bbe03cd8a3cb11a27d568414782f47b1a44c97c680467694bc9709d32916c97e8006cbb07ba0e4180a3",
            "738038c374c4cce8f32959afb25f303f5815c4533124acf9d18940e77522ac5dc4b9570aae8f47b7f57fd8767bea1a24",
            "ae7bed65b4afdc8f1278c30e2db98fd172730ac6bbed4f1127cd32b04a95b205526cfcb4c4e1cc955175b3e8de1f5d81",
            "b18669692350aaa1a1d797617582e54d7a5b57a683b32fb1098062dad7b0c2eb518f6862e83db25e3dbaf7aed504de93",
            "2acb99d735992ce62bae9ef893ff6acc0ffcf8e3483e146b9d49dd8c7835f43a37dca0787e3ec9f6605223d5ba7ae0ab",
            "9025b73bc03f7fac36c009a56d4d95d1e81d3b3ebca7e54cc1a12d127b57c8138976e791013b015f06a624f521b6ee04",
            "ec980893c7e5e01a336203594094f82833d7445fe2d09130f63511da54832de9136b39f4599f5aa5dfbb45da60cdceab",
            "7eefde89be63f3f7c0d2324847cce1405def7c469b0e272494e5df54f568656cb9c8818d92b72b8bc34db7bb3112487e",
            "746eefe4e808bbb287d99bf07d00dabededc5e5f074ffeae0cba7da3a516c173be1c513323e119f635e8209a074b216b",
            "7023fadc2d25949c90037e71e3e550726d210a2c688342e52440635e9cc14afe10102621a9c9accb782e9e4a5fa87f0a",
            "956f5b85509960285c22627c59483a5a4c28cce4b156e551406a7ee8355656a21e43e38ce129fdadb759eddfa08f00fc",
            "8e567cef93c6792d01df05e6d580f4d5d48df042451a33590d3e8cf49b2627218f0c292fa66ada945fa55bb23548e33a",
            "83a562957a3149a993cc472362298736a8b778d97ce423013d64b32cd172efa551bf7f368f04bdaec6091a3004a75759",
            "8b801dcf675cb83e43a53ae8b254d333bcda20d4817d3477abfba25bb83df5949c126f149b1d99341e4e6f9120f4d41e",
            "629185002c72c012c414d2382a6d47c7b3deaba7",
        ),
        script_hex: "ac00",
        input_index: Some(0),
        amount: 711752082734717,
        raw_hash_type: 3,
        expected: [
            0xb3, 0x8e, 0x31, 0x70, 0x8c, 0xb7, 0x8e, 0xee, 0xc7, 0x66, 0x3e, 0xca, 0x1e, 0x01, 0xb7, 0x53,
            0x9e, 0x26, 0xb7, 0x30, 0xcf, 0x44, 0x6d, 0x3b, 0xf5, 0x7a, 0x99, 0x8e, 0x9e, 0xd9, 0x2b, 0x47,
        ],
    },
    // Maintained source tuple 3, original data.rs lines 660..962.
    DigestVector {
        tx_hex: concat!(
            "030000807082c40300020d386ae30dd30100070065516553536ad50942f76967020005ac656365ac61a7b8b9f699d601",
            "02000000000000000000000000000000002849232f329fef95c7af370098ffe4918e0ca1df47f275867b739e0a514d32",
            "09325e217045927b479c1ce2e5d54f25488cad1513e3f44a21266cfd841633327dee6cf810fbf7393e317d9e53d1be1d",
            "5ae7839b66b943b9ed18f2c530e975422332c3439cce49a29f2a336a4851263c5e9bd13d731109e844b7f8c392a5c1dc",
            "aa2ae5f50ff63fab9765e016702c35a67cd7364d3fab552fb349e35c15c50250453fd18f7b855992632e2c76c0fbf1ef",
            "963ea80e3223de3277bc559251725829ec03f213ba8955cab2822ff21a9b0a4904d668fcd77224bde3dd01f6ffc4828f",
            "6b64230b35c6a049873494276ea1d7ed5e92cb4f90ba83a9e49601b194042f2900d99d312d7b70508cf176066d154dbe",
            "96ef9d4367e4c840e4a17b5e5122e8ebe2038a3c5f4cbae21ea3fa1ae6c25a9462ebcbb0fd5f14554bc97747c33e34da",
            "90c802d8d0d50bfe37618c5812891484fa259322c15092d4155d8696d6f12f24fd36440ab3be0871ca3dd9625348a614",
            "b59bde45885649bae36de34def8fcec85343475d976ae1e9b27829ce2ac5efd0b399a8b448be6504294ee6b3c1c6a534",
            "2d7c01ae038ad3070c2b1a91573af5e0c5e4cbbf4acdc6b54c9272200d9970250c17c1036f02085c41858ed3a0c48150",
            "bc697e4a695fef335f7ad07e1a46dc767ff822db70e6029080b9816b2232c81a4c66cc586abfe1eaa8ca6cf41fc3c3e6",
            "c7b886fb6dac9f0222b4fc6fff9d0513d61a21c80a377671d135a668a0ae2bb934c82c4142da69d102a7de9a7df70640",
            "0ec79878d868e17e8f71ea31495af819a016cc419e07c501aa8309b2e6c85b79b2763733a37bbc0420d42537b871b429",
            "4a65d3e055ff718dd9dc8c75e7e5b2efe442637371b7c48f6ee99e3ea38a4b0f2f67fc2b908cda657eae754e037e262e",
            "9a9f9bd7ec4267ed8e96930e1084783c37d6f9dd15fd29f4cc477e66f130d630430dcc0104899b4f9f46eb090ef7fc90",
            "b479abf61f93955ee00e6a1848f1ab14ad334f2b68035808cdf1bb9e9d9a816baf728a955b960b7701fa626687dc3c9c",
            "ba646337b53e29816e9482ddf5578a8768aae477fce410ac2d5de6095861c111d7feb3e6bb4fbb5a5495549597279835",
            "0a253f05f66c2ecfcbc0ed43f5ec2e6d8dba15a51254d97b1821107c07dd9a16ef8406f943e282b95d4b362530c913d6",
            "ba421df6027de5af1e4745d5868106954be6c1962780a2941072e95131b1679df0637625042c37d48ffb152e5ebc185c",
            "8a2b7d4385f1c95af937df78dfd8757fab434968b0b57c66574468f160b447ac8221e5060676a842a1c6b7172dd3340f",
            "764070ab1fe091c5c74c95a5dc043390723a4c127da14cdde1dc2675a62340b3e6afd0522a31de26e7d1ec3a9c8a091f",
            "fdc75b7ecfdc7c12995a5e37ce3488bd29f8629d68f696492448dd526697476dc061346ebe3f677217ff9c60efce943a",
            "f28dfd3f9e59692598a6047c23c4c01400f1ab5730eac0ae8d5843d5051c376240172af218d7a1ecfe65b4f751006389",
            "83c14de4974755dade8018c9b8f4543fb095961513e67c61dbc59c607f9b51f8d09bdcad28bcfb9e5d2744ea8848b262",
            "3ac07f8ef61a81a35910b8a1baf39a919a7b60bc604d63185f759221d847cc54a22765a4c33475b5791e9af3271fc8d9",
            "350667090d8184ec50522d804f23c4fb44ffa481bc92ae408d1b9f2b131904f9705c59e2f4bde7a3b2c085d93fd2abc5",
            "e14d163001a12f51938d021afa92239b873dc6c357eaa8af4ee6d00540657fe32914103b5d98f68bd3e2b5359f08ccd8",
            "8d0c811e4c31fbb49f3a90bbd05dce62f344e7077593159ae35050b04c9e6b86bc432dc8b048c73c0018ca5b69411297",
            "732a4e1aa99a928c71e7a24fd277856aa42501e51b012aea9446a2104e93f815a0b3a29b458314f3d8be2b9823d342f4",
            "6213e942a7e19a46e970b5c506708430317b1bb3b35df68ae33a4926a03e6bfeb5510416fcbb0524c9ca5074156cc5a5",
            "d6fe1c995edc60a2f550411aa41e3da3bdcf64bcf04a0510571b936d47e55cec0330ee8dfe73563404f047d7f3a8a3d7",
            "743bc554955210f1eb0d08599ea77d5f974d87176d37d98b9c0ad440407209ed6a9f08464d565593e1a63b938536b492",
            "44e97d880173b640f2ddb74d068ecb46cf289b7d891307bba37054cf91b31fc82f74d5fcc000942ede911825f53fe609",
            "686f463223b1e9bc03bde895d1238fad04a3bfce68a075e8a37c0e87bf46dd015545f9b4fb0eec645ffcbbe0ca5f8c56",
            "1b257d52d602d8c94c502873a01d9251d8c860c041525b3bf4e3a2eb9272815c7586768428b4c2b25e3745f009c5dce2",
            "0b69d5d7c43ceb736b6831e8c110f16cfdb3a467e9414c00ecf13731500894555678c497faba9a95d01cc464390fc4a7",
            "6bfa8b0e1c68a525d706d6604b2330b6b3485215f606f1883a751588c7efa506c3e8d0c60192e8476bd1175d9562087b",
            "db818e66216286bafe47ff4dbcced51444480a9a5673ece7fac73a000000000000000000000000000000000ed41ab005",
            "1753a7caa89be3139afd9793b3e02f27f040046595acd47bf13fd0da27f09eda48036d3ee437f2ee8f8606ea97343c33",
            "584657f46dba99db5cfe6ca176fab7b0f3bfa0ab61e340c34eb9f17c7ec2be03b180f0bb6f434c2a6542e00e84373f4f",
            "4649cda32bf686666143f622aa480460b5afac518607cd9af8bcd6b58c30127316b25d5ea7bf6b0cab8542ff69d9b2f1",
            "80be12ed75344a395aa10f852f083ad64ef40e9c0309e9bba54b8cb33c95498a69538d3ae5b25e247098306fa8c74a8e",
            "e5bca941531d61aac27aab3dc5617d5606c9577a2a8346e8d85b32b8505775108dc85e2ade2eac1e636e1af4054c8b6f",
            "57632df269c3723b320872e4c57b218358dc7e9905bb04edf92edf0df635f3bf361e57a13296e1447af5080272d636e2",
            "7518a9876e15eb01f5e8ded81892511cc2851b00b832712a6d3ba5660317bcd3567621a7cf8445589653262020c33bf7",
            "8031b8ee0707de072068c170570b27e6d9f5c6ddc335402efc548862f5a07094fd428a7bbc15d7b38d05362c9ca985f5",
            "8a76647d2be4c2cd6b3d17d6870971d7a098baf72c6f6f1214cf1faae488037de259d3415c2f0ddec7457004f35708d1",
            "eccccc0df65a04943ad5cbc13f295f020fe056c40b2d88f27dc34cfeb803be3483a9ebf9b5a9026057725d63ead2c0c0",
            "031fe26ac1e7bdfcd6fad875842d194f331750462c06b8d7982d67995ed5d3ae96025ae0067f4eb1c7c93231bd39773c",
            "be0a9d66b0c9aa8cff6a376e1f372eac6ac4026cc0942245d4c2dcf02d7640ffcc5a6ac3a87f5c411551bcc2f26cb949",
            "61d53f95ddb19ae930c8d70f031b29a5df99ff36695e802cbcb6b58c1ba7ed5eacfa76414a41ad4a44f71f1b580d34c3",
            "a952920b254a145fea517f5b42b2f65ecd0f82595478d80ae5c8ceea12a161ccbb5eac09990fc619a46080436dbd08d7",
            "4784af002d58e06faf7f3ceae7d3419b1fca265a5559cf9e2d3b60978d81a678b9ed8e4486b4d14609d6c127c0c2fbff",
            "e30a60f7bff1d9fb8300ed009253ba9b996fa05241b10f5ac9a8408e925b626bb21a471fe3bede52bba097b2a99a9ba5",
            "a86658c3fd9ec55bfa9b328567254ab36d2c7f44d2c7e13eb54beb70ea8fa94b6c6e012d79e3f53689c2b1a18eaf2d47",
            "1d13c1ab39d9194ae843ab1d28ffa8f69dc7e15cc38b12e8fcd79255b7216056d9edb7482fb98aa033b65e51c1a08b8a",
            "11d84d0409b734f452aaf0d6b18f50258683d3f9a76d399fd047eee288bb4585851dc93eccc62322924cd13b5dd4eed6",
            "6ed8d9972d772629ea64742e54733981b006c062468e4bd8f7dd9af698f52ae814634e81d7f3e0c420317caca9ae4811",
            "c6af06fe80a8c02ab7a00e18e4a6aa1ea1b76945d2615d43ac118b56c2f2960fe93a025f13ec91ffc6d2c353699abb09",
            "2dedc065db8fa214dbc46466f897b88c58b30152133aa3831af37c74d99e9e36ff7011d3238305691508a2c3a43e755d",
            "c081b511d6482a7db65fa9699ea87ff47099ed3637dbb0a3d0ef79796a8ef1e4d94d42b4bc2b4a038ae6e46b24cfc841",
            "53d31eaf895063a5ca959be63f37f2ba0d432366736d8632fce072b6ae5b6f3fd59d3faff638275a992fefc87e60d44c",
            "2cadc2b5c494e3e72eb4597c96b40167799a9001a2ed3676a8b403ae25ffd772f7081e9a32bcc1c5e2edd4e2a6576b78",
            "3cce3aae11fa432262548856183ee682d5dc31beb38f061cbdeca7021a444e2dd417df26dcd220f2b731772b439e96d6",
            "14e1facb486c7a7d5171b1de359f6ad3a96f649c969102a1964fb4b4a1a4279c68e6c372e42187d754e804a616530920",
            "69fb9b6d25266890808b015df28c801065da6febdc1a56bfd002625acfaa5373fde149c1cfc3649b4869696d44ecb124",
            "79c5ebef995f10029f8b530eeb3fdc2e50e8757fc0bb9e263023db82f878d9ac7ffb0bd4391df1d879899a3ef57bfd0d",
            "1f7755648edd85bb052a6edf71cd2628c987429f36dc505ccc43f30e7a869c9e255e2af9fcf30c121796d190000960cb",
            "6fe2f1bf246118b498f3247f9d484c73cf09393039e45326b8ffffb3e7e6159c46699f100792d4672950348a90552e45",
            "943beeacf03f3216f94e274d63d637d9f190e8a266cdeef153530bee5cb8355260505c2c2e5d990fffdc34ec0ff7f1af",
            "81b24ced0efa6213da6c7c60c487f5f7b03f8160a057f46d05bf8218b3add9c06893bd02db9b61191dfb133bfabe4858",
            "e47a4cc32e416ec08b8ac7915a43733f4406e9d967c560f344d7e904a28045d99f3af8c82e97e1b9c1b205e585fbebb4",
            "8faf58f1b65dca2497e09a70aad4865f85715a280e186f3fc1740d8184d33e8322169521cdc132212939c84a108964e2",
            "de74b6ea55b4cb8f6f9bee98b10d415109455f48b776082dc30b4bc73477075511700308158ce2f2f9bf0f691b2ce53e",
            "61142cb740c15b7b623cf48b3f7bfefa31bcdc665c6d7123e95350811375947b055a43db07e03f33627df5c638bfad95",
            "6ddc1ea7d7620a20f2792f63817a1cf32580d04274234af2a51b56bb68a29e43a954142ba4ca6823bde9053d72fdadbc",
            "61ad5936c53fdd7579446d11c44607f41630e4c08915e631771550e9ce1fca2c63fe06b7989d584fa7d782a88c1e7d64",
            "b6fbf55e35",
        ),
        script_hex: "6a535363",
        input_index: None,
        amount: 379068098637835,
        raw_hash_type: 1,
        expected: [
            0x92, 0xe7, 0xb4, 0x8f, 0x32, 0x81, 0x87, 0x71, 0x26, 0x87, 0xaf, 0x4d, 0xc1, 0x7a, 0x73, 0xfe,
            0x0a, 0x70, 0xac, 0x07, 0x8d, 0x24, 0xcd, 0xcd, 0xd4, 0x58, 0xa3, 0xd6, 0x86, 0x61, 0xec, 0x0a,
        ],
    },
    // Maintained source tuple 4, original data.rs lines 963..1132.
    DigestVector {
        tx_hex: concat!(
            "030000807082c40302249df05701dab031c4bac1ea267a2996a2028d1e6a0f80a3847c531dba96ee65a24189bd0952ac",
            "656365ac006500b2a4f951ef8f497dfff2f2f271eab89c628e18b5fcb43882537eaf6ad2a6b1754633caa86bf2c76f07",
            "53636a6a656a53a2210c2701ea6c542cc8c7060000e01129f03a1e9c090100000000000000000000000000000000be07",
            "62c0b1c65855deba8422ca4b88abeea6a4382cf16ccd6dc7c37c44e549c4534819acd8bb0a02a5fa7a1c1d3806fbc340",
            "7fd7da93fd0de6400d3ab8977485cddfbed5932f507b79947adb2fad37615aa717db5f298099f20f263b359a1151a6b7",
            "5c01365eb154ae42140d6e10342f14f34dc33e07ff0e4d1a6be375b32f84b92e5d81ebb639c4f27e715aa42cc75707d4",
            "ebd1bbfbe8f90fc7c953e7a9715e65af8267373d3451674ff084efd92ccf3bcc7aca1467b6327e4f9522b2cc579a7a8f",
            "ff7ca7cf145dfc13eafc34153b2c3e8afbe53444d0c73b3bd5bc870b01cd457911e356313fd1dafb4c8151634a01aff7",
            "cf116d433c3d2b3adda9cebe18f7d172443e5e7b5ac9abe8db2256d7ebe2ff28020939503870597b9a955892c7380250",
            "a2d42ec92be723fedf2f2ede5a472aa1e74f33ad41901544edbbe3ac464cf403196015f4f22ac2b8fc01496beab4d459",
            "07f479812a259431a2cbc93d4f3b84e40b366020273a6752e501af6ff1b78ddc817e6ea351d6006becf8d2ffb03990f6",
            "7774a81e05b7f4bbad8577fa27c9de64e1b11dcf384f5956443748755a9fc6f2a00310c3657ebac03bfc0b587bef2f45",
            "ec8acdaa51c143b0cb25b9142c61bd790a8003c23f90cc03495b51e4d2843e557f9e2545108c6c6fae359f645c276891",
            "c0dcab03af187700c082dc477740fb3f2cd7bb59fb358554e94c7e678ce01aebf94e515e03722967995aea858d64e778",
            "9ff306369577228180326a5b0af475e27a54b207b40392e376170e3fb005028261c99c2dbd0eedee871c1c0f48b8e9b8",
            "e4be77d1b737fe21f0fa5a18ebb52755b5a6cf6130fb56944cfab87527c250d113b29bcac9aaa10c2e7de415edb0806c",
            "6da03020a134ca7ecdc8da1bd57a37f55a46940b45b241b1c16ee100927d1bd860d445a9de50d4c384d6e1d00108026c",
            "0ea5ebbf0b72fbf5c370bce18d3acbc46599099baae1d802f77333494a7ae130fe86e8f818f9261a2dadb4125229ba0f",
            "fc0e7090324430b521a90d224ab7a1024e1d893e7404fedb348e4d5e2235c59a7876a0fc60145c6a009687684460271e",
            "e133a437fe52fb6cfba97fcec161df515dde905a24da6d37bdc34044a955e682b47471ca1e8c78c51ed377cd4afa894b",
            "d9bd12e707156da0726f7cf5729fabe372160463fe0429244d067489ba5d09472ecd9bcdc4d5e4df101e189db8463eb5",
            "38307b587deff78de9c73af28080b2fd05003e11d3e1b3299dc9521f8b513badb010e91bfeb91b0b2a6cb129c2e825a5",
            "97b8fb75bc562d654d62104640dd74e56cd14baaba565b84b845e163d1caef2533c3981637204f96a59c8e8024d9041b",
            "2029e94c15245f1a958840ba3f380a4d20f1184e77827de3ff8f3d73459afe241f723c084823230e003d3d21e53501ec",
            "0499b083a7dad685c57127f4de64733a880c2db28fdaabf1b542d205f664a35135712711dcccd931a50b9c5661882360",
            "d4cac0047681bc2e2b3bf6c99760d7cfb4fa21394377a4551c76d1f75ac03c262054dffd79a9ded05e888958199eea45",
            "01e2990a53a5cd2a46a401576588fd7d058a26f28438e5782f45ac1d07f6f6f5ed73741d5785837a6b844b474775718c",
            "29dd99084e9f88ef153a8329f532a69017dc3a97ed754367723098e5765840b022897244745fbbbb30a7cb54fa051116",
            "6e9544122000610bd2aacbd82325a59b95154ecd82c88d23abd1e20770ffb8aabf83fc0734964ccd411d1c935714e24a",
            "ab566f4f08424014c4eca91b590f082b473f361c87415d37bd20d70fd0b52b6ddf1865f766702e32b05b3cf1630ee859",
            "7aae19633f3516a8555ac5be32c675be1817efbffd9369041a089c283f19649968c2498cde56f500434f280d77a9c62e",
            "43cbd3f136a4c6a00a43e6ed530cb2e8ae838860adc88aacc7bd6a00ae0c19ff4533a485efde082b5f4d1f7a8ebe7ed8",
            "2b7b05a8cfe1e373459f1bdcbf9525747e8c9508a555facb798740e0bdf994d9739bbe5538a0ae0f076c582c0f5ba878",
            "b99b8249db1d7e95056c98af083d98cb0ed9e3f7436e1c7643766f966b83e999206ebd1393b9b2a7f414480fa0174800",
            "69f85c7749c435ae2fba2ddc1038d547d84854817ef39635c29827aad86726c9ade3b265b9086c8b5b75ef56fe4bd8b4",
            "d62893895b3fd2734fdac464156d7e5ebc7ecf1d83b86f659637e3b142c164963b8cdcf4ba4f4035dffc5a7894588477",
            "81918ac72fc18bbbf5110032e66d75b3171ef4b513290164a77b42b0a4cfb89639ab23845e1aa2a452f3731c8cb65082",
            "a622a7c2e0013ea47d0bdd42d6990466649a905c684c3251716d61f760d53de6e3f790fba7f5f1f4de267113bdfcd742",
            "2822330b32d58e6777765f22a4116344eeb65b2ec516393ab3751b5356d2b0c9500c0f3e469181035bc3660f0b8f9fbe",
            "6e40b5e89cb79b063714ca75e72e2e100a10d63bf784df0820ef25f8ef40fe5f05fb95683f9105ff3cb2d219ab76605a",
            "064f69219f1dc0d00b3b48642f970dc00cca4b8b43308be18286ec5a4288d600a3785cb622d468a4c6969b3792f24850",
            "27d0ad9aa4a9c2cc972f9ee5190a95b1eb058dddd8c08e7d753f5e011b2bcfee1d52c1c4f2cacda30bdb6930653c0cc4",
            "486e60e89fa849b3",
        ),
        script_hex: "5352",
        input_index: Some(0),
        amount: 1437866676382615,
        raw_hash_type: 3,
        expected: [
            0xd8, 0xe9, 0xb9, 0x72, 0xb2, 0x89, 0x8e, 0xfc, 0xca, 0x8e, 0x96, 0xbc, 0x98, 0x70, 0x00, 0x8c,
            0xdb, 0xc1, 0x9d, 0x45, 0xb7, 0x8d, 0x09, 0xef, 0xb1, 0x02, 0xf2, 0xd7, 0x0d, 0xba, 0x01, 0xad,
        ],
    },
    // Maintained source tuple 5, original data.rs lines 1133..1153.
    DigestVector {
        tx_hex: concat!(
            "030000807082c4030187daa731f570a7a4060af0ce700d31bca7e74b3e3ba3d0e8a6392a062b8e86d9d7d00b21026553",
            "062e06b1013011ff08f083050009636a52635163006aac9abcef2a9908731900",
        ),
        script_hex: "63",
        input_index: None,
        amount: 1993227025071196,
        raw_hash_type: 1,
        expected: [
            0x2b, 0x62, 0xff, 0x0c, 0x8d, 0xec, 0x4d, 0xf1, 0x8b, 0x99, 0x56, 0x61, 0x5b, 0x57, 0x4d, 0xda,
            0x39, 0x42, 0xfe, 0x45, 0x2d, 0x91, 0x78, 0xb0, 0xbb, 0xb2, 0xea, 0xee, 0x4d, 0xe4, 0x4a, 0x8c,
        ],
    },
    // Maintained source tuple 6, original data.rs lines 1154..1177.
    DigestVector {
        tx_hex: concat!(
            "030000807082c403027c82977c0ff797093e2c1f3ae855f65aea91e1312fc6b8a4351a2ec03e02e5d02f53354b056a53",
            "52636a82cd1f55ebca57b6337c85938a79813d2021d6094c68b375e984f68393300871e348fc5236cca63305ac636551",
            "63418701ff0186d26fee28ca060001ac5aa727ab7985da0e00",
        ),
        script_hex: "655351",
        input_index: Some(1),
        amount: 449567650863240,
        raw_hash_type: 130,
        expected: [
            0x49, 0x3d, 0x49, 0xc3, 0xe2, 0x22, 0x5d, 0x11, 0xc4, 0x64, 0x05, 0x18, 0x20, 0x14, 0x76, 0x25,
            0xf3, 0x90, 0x9f, 0xa7, 0x18, 0x9f, 0x61, 0xc7, 0xea, 0xec, 0xfc, 0x6d, 0xad, 0x2e, 0x82, 0x03,
        ],
    },
    // Maintained source tuple 7, original data.rs lines 1178..1480.
    DigestVector {
        tx_hex: concat!(
            "030000807082c4030002e96aa73cd9d1040002005306f699e0b19a040006ac656551ac510e68ae387505511302000000",
            "000000000000000000000000003792f135bf5f68787d370ca8c4c4074dc5d601ae90495437c3c2d48a3d966683ac0516",
            "0b7a84eaa7aab74009e57a85f7bf68a2e482000f829c545073a15d5cd0fcc57439a4350eaf098dfb82a085ea8a4af6fa",
            "8381f0658819eab483f65b325d5aeda15232cfadec75ab1866e4c0155a9c74a7a57ccf34c483ac7da1588a1b6b9941f1",
            "1040f94cf78fad89bf11fed69aa0d83105adacdd4e5f04a62424023c9b9e33c4fb7f12bdf21f07f265c537d51c6551f4",
            "617b915d21991839c3d0d36393d646e0a8a41509217d0e7d2ca1a0a0d677a3eaca23edeb07b74e652a0bc50c6c083a55",
            "d6c7306e74086f4768933aa24873681867a7893d77cb7f29b8c847c583f2d071a686616e206719f761ae39c110442e06",
            "163d2b84590360695d4e19849e034f24d9ad396c19ff83ce74f46e645f932e141a41195936c85d514414f112e60b0225",
            "37c38d6dc6c4638305c9bd6c62e366bc63123e3e6dd36eedd3136fce8deeca0aa09a3298a39d83859efc9b2b69cf9a7d",
            "ee08a98e4be558ac7912fdcb42209075420260f7cad0f2c01f2afe33073f26249d944f7a50dd84839bc3ea7fdee4ed71",
            "029cf07533d26e1e27a3efb032c3a3b34bd3092622d2062ae536ef5149c49b5bc9035eafab6e675761008b0daddeecaa",
            "604470bbe0fada255d290e92b190c2c2d8c202e5455d1fa9a9f3db7779b584643464aa8014ba66994de25517f83980e6",
            "6ee4f60314ae6dbef452d5d38b0a16f3991f36d8a8b39ddc0d5595eed98762878cdf3f4a02dc5cda77d5fe4faf63a15f",
            "568a540da57dd9beb6fb1a977ccb91b4d79cb39b28911a29e7bf028ac6103796dfb6b20967239ad373c38c53f6df1823",
            "d4950a0283e99b9c06ab2966667c9df677716b0caded818df9e449c072e22f9d98bb0f9b03bd5fd013fcef3ed6a49aeb",
            "98720254087ef728e31947ffe8f766e63ee46ff20816d5fa8ff55a26398961490ab9ae366fc5a2d1996ed693ccca8235",
            "6f600ab099f6eca8bfe645270d3f95edba5b0de7a32819233bcc754a5ce2e5ea07842e5ff2cebe62ad76e8eff8d15ea4",
            "c24a5f207868319a5af6b035be3f44f434094f6e525be614dac920a330bdfb26d75fe7b4b365d094459250aaa5544489",
            "fb1d992581800a77b8912157fc9713aaac25b4c26eb03f716646619af02456ae695962fe5e931a63b5c79052ecd333e1",
            "8412db91e15f7cbc70b4cd7e8e3c951f358572e37767e7d52704a6721b30efc41017ae4d231558c5c82cc7dd7e3356c0",
            "9dc24906f0438dfcc300856ac2ced8f77fa8015736c661e80248aeeb774874aa79d290b8f5027a0a509537fc7c689b7a",
            "d86116cfec2647ccaae1c74b416f3e6ae8f7cc60eaaf7b6a590d51544138e1732945603a53462c60e1f6cb0c9ca0390c",
            "488224c313269fcd59fcb611fb2d9b4c8fa601bb1cb8d07d797bf5de52bceeb02301c8962ac1fc0491dc81affd6c1ebf",
            "89a13d6f290eda5d5cef382215c5e951d71305ef33d9737126d0e662905f1250926f6a229990e38f69ad9a9192b302f2",
            "6bdda465d90b94b12c57fa3fd6930083f184438d8a889d3f5ecea2c6d23d6736f2a0f18e26f4fa45d1be8f3dc4a70713",
            "7e95d2ad594f6c03d24923067ae47fd6425efb9c1d504e6fd5575340945601fe806f5756acb562f13c0ca1d803a195c2",
            "ebb2ef02ac33e6a88dea075ba996d3c336648e8694d3a19d3dca531beb50d4327c5c0c23cb7cfdb08ca7cf2cac6bc139",
            "d0741473d376029cb4ab6bf054557ce294c728a4687d57ec8909ff51a4d02f9dcd11193d7d1c9fdae6a17396a1bf57a9",
            "94934f5e7a59f045debeaff62ef326b947f2a8b49555e4d99b3bf5c81ff9fe314e047af152508f57015ca402c67d925c",
            "99acea3ee8cc4b008c5cb43966e714ef480fd05e07c7b2dda9aa3966113eaa293d3f622b309d64803ce1e6378b6aac4f",
            "ab527c43cd45ed0a3c1a4b9fb18dcccfcdb6ac0c2421639cda0075a20dc5111b8d3d3199495bd9133dbab94541410e4f",
            "ba92c7b606a5cb122f140cf1a3596f2788f3c8b92660f14cb65af5dd23dfdbac1371ecf4b33712fed2292c44f70834cf",
            "96c05d58827e69bfc2e696fa0874869c02f3dca11c3b90cb214e68bc1cae039d7a146cdc1d609d7a6b3fd5d461b0951c",
            "82cfb3e763fad2d1bc7678cdf82779f8fd5a1ce22a8d3c4547abd959838a46fb80afe01f8ecc9931513b1962ec540856",
            "cb189387cfbfcc0f7c68223cba47fb0c9b486e4d99171941f7675a8b46328a3bc109bf07c66d5ede771cc4c74ce80333",
            "829191eedc493508a644530a6144f22dcf97525a4cdca1ad71073b080b73ea4549f5401bff4318268e6ad637363157a1",
            "9a53f123a0b0e16d0b77f02028da464100fde76d83dd0bb224f7b57a00c02f68ae648fdc529957a10490dce1fddbb090",
            "4f0d518bb387544019983b616975a78e74d854fddc49b255167b55ef4bee465668b20ea4118ca569ae480e0f6e5e043a",
            "357b36d3ab36c861f2278301dce57674d5073b3a6f510300000000000000000000000000000000a0793af1b7d46f957e",
            "22d8d2583bf181836c3be9930bac8fa460e968aa7109870bbed17df5f888c8ca1467ae17dbbcde31c1105cb5bda88ac6",
            "c627002ce21c02140ffe81ec58bf1e6d1bb7aaada41fba0bb588778a7f65202ad811ea73d26c74550395aff75325107c",
            "9b3f9ae9dcdcd86ed081a2e7424719a3d185b7e0a43a472e298ac0afdc5287d7ad124cd9405a62cd1ca08b282efef7f9",
            "28df76e2821a418413eb7ceaa5ff1290b03ec91ce6dd28130c3ab0b23b602bd5be5dc26003aae04b33d7bd2590e90c8c",
            "388ea7955122dbaca67b30395a928b57b8575123205ae19152e41e002931b45746198e5dd9571a56a7e0d423ff27989d",
            "3eb417ecd3c3093fb82c5658e29624c53219a60cd0a8c4da367e29a71779a73032985a3d1fd03d02d06e05566f3b8436",
            "7cf0faee9bc3bd7a3a606a9fdb849c5d82d0a61923c2e5d80263a8a50c38bd038772c4143d8b7acfd74e72c04d89248d",
            "ff20fe8dc5ec2149050aa24164e85f6744ad0cacf1a8b70126f482c092ed9f6127d2050d12e878a79653a1e84daec3eb",
            "e62d5f6c4abe5ce90a7fe2e52a8d7846e8edf2f2bce05a037c820322caad1261467dcfb7d6b6133dc21e8096c7e9f8e9",
            "e10c1e3fac4058b682c68e02facae0f9c2dd4d64d9046152b4762332939f17e6aaf7d8b9d358e2218d4e0d6902f119e1",
            "c64eec4c8b532809707131f01f55c7ad04cfb63f7c4a3d0a2b0ffb0b0502be055b8c94ca80bb0a1d13cd4cd69ab98304",
            "ae2515d5f7699d4abee5c20be6090273511012f234bd85a7eff5fb634cff2658ba6516048563095ecefb3015ee3f03ca",
            "52a177f261ecdc26bc089d34c6404846e9c647fcfe98cc6acdbb464f64278ad8ce9d1ae0d415bc0c05245fddaf4ebc8d",
            "c703a85cb270f796ad2d937e2ac0d5e0a34821758000aa59c9d4652485294ee0ab29696b21430fa54dcfbf2b9c49d142",
            "064209eeeed4d471ffc017d4e20a796b0927804c061b9f4a7091fe015ada68fd8442e01825c88dfe55cf5de38936f7ce",
            "25311b902ba97a3c12a95cfa1c3a591b818f60832709d9e4839e410fb36b84f3ac4f070fc35e161978259e5b8edc744d",
            "90919aa770bb36215128e582b59641e23852e958eb8fc3c0aa96152ba4f77f138d6a6712a3ae3226015883f81db23e58",
            "3c869c4c71143a6fffd65e8dfdc50c99a2f1f314cdcc71359e235f1d7dc2b5f38ef7b970843163c03f9dd40a8015efdc",
            "8791956a3f3cedd9ea64f8efa7a0815a70381d71467817bd04ca529aede07ff60d176aed0f855a2eaea89eaeaca89358",
            "c081826a0812a5bca28be1373f086dbdba7e43e203212c9fed21474ba19a055ffcc179412e893a744832298c5fe24cc6",
            "b18667f49b34dfb12379267419a9cb9403d8167d8d1e91d2811a043b29243b069b37587847dc6fcddb1831bd1cc2567c",
            "a033ac40f74ab6955f683b12e4e8254e4ea760d38b3f46791c5c4cb12bc7ccb0ed1865f25d601c303f81fb1fa1db4853",
            "3d3d6b288e4d9a4dff8ec21c96f578399710c825fe7e32f93a8c0743f9ebd54cc151c7610337aebf7e9b915720a54351",
            "d49ab8c22fa34998dcf583d4387361ef3ff86f50ec53f49249e4ad349603066fc9c661d69f911dfa7241c8d5792d43c4",
            "57d5de96523a53d667ec5c4ef9d502a16f1522475896d79bc57833e977171c324dce2a1ea1e4304f49e43ae065e3fb19",
            "6f76d9b879c7200862ead18dea5fb6a17acea33386eb4ca1b51486a9148fbdf9a95332aa605c5d5483ce4ba8ece01a8f",
            "f2b7ef82d05c0b6e861b915f13ca0eb3ea13d5070807a2cb6680a249ea9c7224392cbc8ab82501b26f112ac789a12a31",
            "ad1314e2ede08fad3143af30c27f403bc866c755177852afd0abb90ade1d682726f42008b46ad7f8abdb18117f726413",
            "90f086b6e1498be69548527e6ada2b38b9fe121ef670af7437d32536d5cf5c4ab19dd99771582d038104b7e039a376f7",
            "acbbeadb34f945beb9d7ca0e4e3d5c5e4eb1d8526ebd13dacb1ba35735c6d04a4555acf4bf117626500d77b38189dd48",
            "88041225acbe3874a4c0f607fe6745f9355b3fa188f1d65c09f389af1b9d6232aa79447919c550f6f31fec35481cb922",
            "de2db5b4da2f81948617028e321706a3a778c1938c443bb00e5b0ff06ad8ab9b1ab0c11477673f85df9561dbea45d5f9",
            "781ebe317a0710ae5461e34fe6f1b1aa9b4e67b14910984802c2a7e38193bc7bdc8ba3e4e3d1d933bfb580f5b3e87a2a",
            "06517051410fe1b4ff1ea0ade824f338515456a57c7a916a74388ee8f1281f9ade0ae2a2613a0612c469df792b8df4ca",
            "e4fc25c1cadba95a807ce61e5a5303faaf9e14653996b5a8adc34fd475ef1499094babaf1f3f07da9a390b1d9fc9a083",
            "27987adfe9564863fbdfa8f6b46a8841583099afb7870118face76347e40b6fd8cd15582ae8e23be9a0219bc3e4e4546",
            "a30d3bbbbd1686086876be0e4c859be71fb58f4fab3d28c0b4f7e75ad1edb7f88946fb40cfa5786a0fcba1303c8347ec",
            "ee93d46d140bb5f69531d666548b109ce764bead7c87bd4c876494de82db6e5073a6c94f7c099a40d7a31c4a04b69c9f",
            "ccf3c7dd56f5544776c53b4df7953981d55a96a6dcff9904a90842e5bafec8840c2d255bf5ad61c460f98feb82a10fa1",
            "c0",
        ),
        script_hex: "656a6551526563",
        input_index: None,
        amount: 1712463999734827,
        raw_hash_type: 1,
        expected: [
            0xbb, 0x10, 0x30, 0x0e, 0x4d, 0xaf, 0xe3, 0x0c, 0x3f, 0xf0, 0x26, 0x34, 0xd0, 0xe0, 0x03, 0x2f,
            0x17, 0x15, 0xb0, 0x0c, 0xbc, 0x77, 0x3d, 0xf6, 0xb0, 0x9e, 0x00, 0x43, 0x38, 0x6a, 0x14, 0x18,
        ],
    },
    // Maintained source tuple 8, original data.rs lines 1481..1649.
    DigestVector {
        tx_hex: concat!(
            "030000807082c4030213e56c772f2c3b860ea5b03a8854bc6e6590d63cc0ea54f10b73ba241bf74b635551a2aa06656a",
            "ac525163368b26d70a737f267685998a3f7d2637914909c746495d24c498635ef97ac66a400894c09f73488e076a5365",
            "5251655205f91ad7007965c299361d600d01000000000000000000000000000000007e89ee0962f58c051d11d055fce2",
            "04a562de68088a1b2648b8174cbcfc8b5b5cd077115afde18405054e5da9a04310342c5d3b526e0b02c5ca1722badeee",
            "23d145e8eb2213fc4af1e450e4d5217c6617008c78f4fb1112f4028a704fc5a9382c6b03e7d8085e906cf84ca2c1207c",
            "87a2bce2080a9891668d69b044beced6cda32c229c9117917aa07ddffcd377395cba616d63c0b69c01fcc45391fd5b87",
            "63fb96d7ca333a12de3cefa91c6c98f9473b8e104a71293e46374705baf65fa41384ba5c8e0c88a3eb07e0be34daddfa",
            "bb7b65543b5f39cb2023d46789eb7d989af779e5b8d28385a85b0da2abe07f0c2bb4255fcea03188527a307d409159e9",
            "0166fac6a070ba05b3e4dbfd3a2bfcc9ee6ed016c0f665be8133b7dc1d86044db0f90340fb0e9f8bc2e4db5382a8b4f8",
            "15b4e8434ad0dfbc51a5e9b145e1596cbf467003e05dfdafbb0cf3ddee28d76a82428e8aba4364e84bac379298df2932",
            "e69bb5d00b516efc33ae6cc3947ceb09ed371667212a831b5485eafce8488188ea4e27d0cdf7ddd348abff777f4a13bb",
            "c716b6a5944ee727965690e209b49eb962c039975f039ed5c6e4c400d887759433d3ad716da0cb446113c7727a64b58c",
            "3f8a0f81189f02005233a81366aee73cec85228ebcfd5ee3c3fb44db76ba243f2842b7b5fc746a031b0bc4bd4fc9fd83",
            "3565ea852b92b224f6990318ad8c7d9437e20e2a1f20e81803057c5abaaa2e5c15b94945cd424c28a5fa385dadfe4907",
            "b274d842707db3697a02e6c8f542e5ecc07fe47350d1014670212efe81fb7c73e8450df814ef6232f7490f63ccf07480",
            "f884a66eaffc28fea448d7b401cdae10e7c0c7f9a7b15331969fc8cb36396773de191931c750f6ce5caaf29768ebb27d",
            "acc738056a8125b4772bf87ae10a8a309b9bd655043cfc3159494368c5ab8cadb7f671e9626bd263e31181a604b506a0",
            "3b439a7ffe4355892477e2bdf338c62c3922f7d3c9a56c7103d911948a84b5ae2dbb16a3761add053a0f967e6b5bc942",
            "11b6547153267c6ee1cad0d974a71088583735e4f63d33156dadd54c2faf89114a127b97b94cc2a22ef303f459d04fc0",
            "b53ace5918d47ff33a558bd71a75f355fbd06bbccf4e02c3c0a4b63d0cc949801d63a64cb2d32373b2c7b274ab2db468",
            "2142c8b21d84c481f5ef21e4b5e3603451bf94774d0ef47f63fa6abb78d21c193cbe65b695fe67423c1e2d312e2776fa",
            "24ece84683e74876c55ea0369e4ea0e86494e00dde236a1689731f0a5d8203afde5c423640b81e4f631c981c11a2e1d1",
            "84c67c528df92d53aec44a40a4ea2a131b4733cfe45c6b0012c3e9e20975baaecb0232df880bd7d1de13e1349462ec8d",
            "5df3e780ffa72eba8a8df7fcf398ec230513ca9d6123f8b9d8178560daf975111955a2bca3423eeefc527be3a8543eb9",
            "0a5ec02f35a7c64b7dd59a72da0074634e01d2abf3637add77c7350f12b011b294168ec75576e47d169e3938bf6ae2aa",
            "8ff7cfba7cacb1f92b6e4c2497bffa9f17cad242fa9c3179c1a3aa81f7361649572c715c25a1f6cd5ace82c00ab2342b",
            "9c3cb4fffdda160ca5ab9e9baf2139ef9afbe1b1f309462afce462a79bb9698e22c957c590a753a76b87e009121e06f6",
            "a1bf62a08bf435d92e2fffe86e2a9cbba9133a68e4aebf33c38436f2545fc2d52832d165af415b244adc5f57377deedf",
            "460aa3beb43419c6b082e835ce84ca13b6908a8813c021de9fa9a44e4c18dcb3d21faabdb41931b2fd497644dc3a1507",
            "fa5ac7c76beebbdbd1d49299a55bd49927e9d7f4884e6ed3fd5e4b7cb835b83308964e3c46873fd613317b91d29236ea",
            "90e365d162cc051c846d242176daf6d28618ae31fbaae999a93f175c6938e631a081f2c1f3fd782549d3f3245759606d",
            "9f92d5548acfeadbaf9caa6b93dc08828d74f6d5fdd83331f0969145955297e69f00fd2987f2da2b94b995fecbe622a7",
            "35ef7f1207f671629489202bea0b475e51681aa16778b39bd923c98dc6ff8373c79bb17030417bc200c8f0b855acfec1",
            "79f7674cec2721a10fca693d83cfe5b8cdcc18f81ad617fa26f0dfb83655b8a29a7f834232425e8c474588f18dd326aa",
            "396c3e4775e00205fc9e45f7b7d2e6d55dcb90e23ff6b508459aa699bfcbd56f10997764d087408986e73d6e284fea9a",
            "23c39311782f86cabff9455e4cf699e5f5d4bc0b3905a4e3bd01c54df8643443be0f889032ea325bf07107fd41d673ee",
            "bae6fa637b70cc0ed3f00958dfb8dcf00e85a1d0a6a8908140c2f434c2e260efb0bca2003504c99993a9e1c0ff9cefe6",
            "a665d791428690e47ef8c131a8e9bfb4c3080235032d731b0d3841225f1c11e2c28ee84d35f9226100565972eb269d27",
            "8ef64979bf6515ed4a6840b0883a9e6ef64a0efcae1cf21dfe74854e84c2749fac03825275c9b6302184c72df4c4bb28",
            "62e4e8a7d9a4a282866f9a7b2cfc9a56313da0c47a34b7b9cda3ace8185f07df36e448a76aa477f224d87a074f43af5d",
            "5f79b3ab1128f08191447fa646bfdde5b51e233ca6155d101585bc2c40158ac2106e66a26e46423370636876b434a74f",
            "8ce8060050b082a79b61bb5d344eb5a1158326ced9a9d9f54fb2fe8f9f05cd111ee46c4710f6f63a62694557",
        ),
        script_hex: "535200",
        input_index: Some(1),
        amount: 1564816348934332,
        raw_hash_type: 1,
        expected: [
            0x21, 0x46, 0x62, 0xc6, 0x74, 0x50, 0x60, 0x3d, 0x8a, 0xa7, 0x3b, 0xea, 0xbb, 0xf7, 0x51, 0x8d,
            0x03, 0x6c, 0xe9, 0x1d, 0xc8, 0x7b, 0x01, 0x81, 0xe8, 0xa0, 0xf3, 0xfa, 0x82, 0x2c, 0x7d, 0x8a,
        ],
    },
    // Maintained source tuple 9, original data.rs lines 1650..1953.
    DigestVector {
        tx_hex: concat!(
            "030000807082c403015907929a2f3fdb0d8f7914c42dde2d2000f5ae02d41821c8e1ee0138ebcb728d7c6c3c80026553",
            "7594c670006f3908222e89d1060200000000000000000000000000000000f8271abe660e39e051aaa6fca1862276e2ba",
            "a0fe0b162aebcfe3d9349c8d154bb7ee28212c1baa705d82070d7032f2695d1796809fab41246926af992b6eee95a9a0",
            "6bc4562c5f2f1b19549500372e7ad579a6d6d78b33153130fb448fb79e8a669db8a0f35cdf9ae5d32d732fc79418e23b",
            "451ddc95a22ababb056ec6b5e8ba4f524dfafe875262dd7be41cbbc62420d4ad6df5c9b713604f656088a4485e93be19",
            "07d27ac6ec3c57259bd6981d42c1b78a29ad9685e63c494d4129623ea1a7ffec85fa29411073edb2978ef4e469ddd5cd",
            "a986189995f88d6ab366db019001f5b25288cf860fd998ee573c8cc48aa9efcf9b617e043c329cd1aa1a0ed3a402fb96",
            "e336c719e6253cb691aa0db52736626ed1978875888ec76c846bc227272a025317dff0b1148d92d6f5fb7d95336770a7",
            "d16fac1add860776cb480221f8fb3303e4e9b07902d2ff86fdac72096234aed48de892ff7355073bbf0615f67b1100cc",
            "0aa3ba3d6c1a1a9087b119baeebfa62bc9f0ec479d99c1a3b158b514d1629db3993f11672a26708e5ad816b547ab7e82",
            "7d071ba7842b3e90305383896ec4905f70038b694e6a5a3e4312cd8208132b840f05c714523ca819720ae227fd1acba7",
            "14fa03c45fc5398857b40dc14879856f354ba4d2581d0cda54b638ba9d76f9b52d17c8028ee63f5845b5dcefa4c3479b",
            "ce9acad18b4aeae03c0eae225d42848bdeaa536d038dd3bc979f06586673bc6ff1c5d3b320f349a5b3a8b355592296aa",
            "f61c5b7252033ec0a9466a1b85764fb0831b4a1a36890e224c01acfce48ee3ed93877398e0726d02936d0d032e18e328",
            "8b2670e1362c32d6e4733b9dd2d5f26e1fe306f73c007fddcae9d9c0aaf187d7428b1e9d479c18237b9828bca8b98c9d",
            "9bec7d8270b5d8eec3cc4f43fa0188521bc61b21dd04e37a83ece68ca7a2fa6c8f9e34a6290335aa1fbd83d54aaf441e",
            "319ea47a862ad0293cedf5dd9edadeee33cb522cd0118bbd811ace9a23bda39aba72f1566fc1688497d2a7928c367015",
            "25678bc97214b31b37bab46b88f27f0448decb31622d0f0f87a855ba54000332031f73abffd46591da0b88723504edb2",
            "337230dad2acc0d8bb68bc837a2ff930bff06fde74eb90aae4f60dbb6eb827ea99884acd6285a98892802cf59d5d60d0",
            "1663387b3ed2723bd6489e9c2c106d4aa2de23ced16c720429c7753a7738ec7d9db8624229edd217b80d74875a14cae4",
            "863f139e9c0b131b2a4c28071a38ec61f66801aa5956fcb2a46b9587665b7571aa03481fd8d9d5698f836fc8635e69e3",
            "bde42f4ac071328b5409f6e42d790aedd73bc1a2354723b3b819d0637a6fa4663946a30ac5afdd30ce830f6791b45752",
            "70a1720f91866e2b86f4788894c8da62d8b91faf520e3bedbc1206a5a5e6efd3dfde0843c3b06757643fc006008838ca",
            "473087f8977918cc1b81c9e68e3b888fe6f7c630f1bc7ae188f512842041cada1e05f866d2562dbe09c4b43068f754da",
            "d34df0fcfc181f31801a7992d2f16be0211b4a22f62aab64701bf4a4e6d666fc304a5c79c609acc43b00b4864893d37d",
            "5007f0c329a4755052577570dd38fac043cd91c12ee34e9cfae392a78bdabd4ee31dc0deb02fe7b1d8b0178ac9513105",
            "fcc7e30ba8e016aa36a6b5df5e5a1909f63aba095d9877a8f2dc53f46f6c9b07addf146f4ffa501f9dd3cff924e3010f",
            "af504e2b8aca7357acbffec73ac34c1a73160f2cea1e0510f84d2fe2f73b6e921907a1b7b3751213241b2cfaa55a5ea4",
            "dd517e7b49d2de8c090843730d2408a2a304aa1e2e1370a6bf6c2bc73ff00d893bc1285efca82599d181f12351f939a9",
            "4ea8b975c065a91ff257cac7a92385fc8fa921b106ba8660c60ac8ba5ece45606f04f36a3a90bb3838c42abf62dd2d84",
            "babef3e188e9171aff9bc116669009d887130ac9f7396a627a8474c1811b696f99552b14c484dfe42c24d57c3a9c3fea",
            "1376cdcb63421c314a622a9aef0bc057cb11bc5e3066e33a3b9b31df2575cd5185a4f3fc4e4c3d402ed42046f81f9748",
            "16d279b1513ab81d3f0a3c7f7fcf2fbb4e26321993a513ad3d7f4afe6c1bbdc657585080bb5a0f25973d63eb20ada016",
            "6bbd8a39ff93246f2789732ad05587f8db7bc87c242cfd36ce685a4b656986c39fd7fcb23c91913e4611191edcc88b78",
            "f145ea29d271b940c69941e4c3fd2d71f3b190690ee16f5d14ac2224e6fc89597654527dabe72e75d2d2a13a9fbaa637",
            "8e8a264321087a1900efe3cad14a579686aa3636bd375bd3136bee0bdaabcfac881bc701812721e6fb75aa072d2d187e",
            "62258d65a192157cdf2ec321407f682f5eec6a3297ab20b7061c62245716a44f71fbfc34c79b44e09e4212ac2653f6c4",
            "03643e1c5b9ad134d89c680b707283af54326fc4f84d6a5829a0ad4830806c05758492cd6ac46ba01a2b3722b5e4cdaf",
            "bb3f36785f424af044dac5db5f7df839eb63c0c17d8b0c79db8630942015be13f79af6f43e5ab0770000000000000000",
            "00000000000000008114798f442258eedc436fcc386b36b57e1917d720177366f424b0a54b0b60f4fb1358c20aa41dc5",
            "02e1dd8a1633f3d8e3276b59e7d2c4e624a6f53695bcaf247e36483f13b204422237fc6ab3eba02fc4142b4297ebb568",
            "3db8d24319706ad26aafd81c53b740f34543a6b3e9f5bb7d5c49e8c37f614921254f3212394c797d1cee7899b7b4b65b",
            "59b7342f92531c1d59e17970b7317414438cd80bd0f9a67c9b9e552f013c115a954f35e0616c68d43163d334dac38270",
            "33e5ad8488bfd9c4bbbe8f5935c6c5ea04c3ad49c747a9e7231bcd7d16215e6e80737d6b54fec8b88402f0475245e174",
            "a745b831f8fe03a76fb9ceca4d22b783c328c6915c43405064ae56bc89e64d1578e4d3a34bb95591eaf1d3da02a4549f",
            "a80db0ff7cb03993028ae15a30e87949aa080e94abde68898c3392a217d649616bbe739b13d14df03f027671489be0b4",
            "bebaafa7d1e639d5b3e994ffb6b7a209f6adfe8d1e5ccf010c190a8aeb18aa9d687e24adc0b1135c70c970e0903af6e1",
            "7081d5818e88b14e4f601b8c063e3f4387ffa2322a5181909f0980d689de7f8e6a5c62a777d175002a137d025b888892",
            "9198117aa5d61993e1dcf75876dca609f9d28471f997fa11f99d423f02f1734be8a5ff997d451eb3cf4b3dfdd9d4545c",
            "35b2b5a7dc17a836b12b43befc03e0a1bd369772338078b4ff7d8e2d979a3441e1c8f5afe47b1e7da56cf00602d00311",
            "0c05cf48fda3e6cce32a044000f45c6d1e696d245cbd312bdc3a3a21c992d003c8cc8fa6306d7e130a2ba42018fe5969",
            "49fd82267bcc59dd4626efc3ea7438d05c91b0f8e092550d2d39a01eb45ee8f7d09b038d8383e19bc30e6403828cdb65",
            "2a556b12040931402aa6ac34fc19fdc06e2e7787f5b77b045fd098c031bdbd46277609d842f48424eda31e3cf2cdd643",
            "85bad3118858d142d906eadb7590c94136da6a063514d6a25f7b37d7664f9b9709433e6e702118a4ab9e7a7a3e625912",
            "9937d29d0db26070523e8b0643130abefe943b401298ae01a3ab00abbc60d7db933c7f07a8bf0f7ce1660bccb45e042b",
            "451b935002cece27f36aba5647ac28d8186cdd1fb95dc135d48992f68da12ad61ac756680dd7f8d0774abd6cfda2f032",
            "af3be139a633d6733c75d1aba89018c8572b99cd30c537067941df1c4bc1fd570f7b4ddc97518623e3ae4a87bdb966c9",
            "4d861e80de88c292aee9387194e256c6700752301c73fc9565a40480d8126e9d085879e24b16e9c485d8f0d618ca0dd1",
            "21b51a7cab230c5b45672bdb8ea3a040f7aaa098ba26025d2eab7948693dd5f6d3096501e9e07125d7eb293b3abad57f",
            "d5f01164702dae64bdba8c924fb0799679d77f98d303919fb4a7ff26a96f137a5e5cb95bc4c6ff9993526bda1503168a",
            "b48cbd45153927d30430423dbdf06605f5b54b808feb22b208b064581847b2f64ca64837007216de6ecaffeb4b69e633",
            "47f84abcad8f2e757d5861ce77ee46513da7416837dcb23d33ea72af23d0ad8c9307d0b5858da95b77fff9027b8859e1",
            "1dcbd598350eee50939481708ea708eb9f664388b9c64d6af0f96690342400348e929e07460253f38390f87bd6c05308",
            "c3bde25228e0fa0880b08ef34a5a9cc0ea0a67ca65b6ffd005572909f1c42dd745eeee9dd6b4439c9f3f98a118fe1669",
            "8e9ceff558f16066975fe39583e9b5853b1311391580019fe55d59d1c828d3feb6a3b9ce92d089ae4b408e23d6a437d4",
            "989b519b7a9eb08ae6d448a7a16e8aed26a2ecd0cad80844fd0650d8c4e4d2af90656748d8099a0c756fc16cca06a334",
            "430702ae1961665b4845acd1a8e34101e68bb644ac034dc63e6e344c3d63762a7a5bf59f13095410981d6b6b16bcd4c9",
            "fa68af6e5365e94ecbe7ab8b8043dfbacb23c84d71a8fe5d9ac5502ce9f73f408e14376db86ef57cc37d09896fa90697",
            "2e557180a4ab5ad09d8846dd6da748765436e0160240f8d41c0ac783f939f2d0ed262ce859c131ebc93ff2e6e407d4e2",
            "43e1e931d53a4543b6e26d82596fc53b52312c776d12eb2b659b4fb098df87d683cf9e5412ee56c3fe9841d73fd070df",
            "a51f5bafedf206f13c524e5c50cac9906efa393290042e3bc59f960b7d240ae443fc49269ce00061e65c6d74812a30dd",
            "5f5fe74eff61e0cbab3cec75d0aef95083189452dd3d9edf4487bc734c8b24f21296e4e9ef117d7fb977e3b0e6406e63",
            "085906331a93033d1cb8360fe6fea61a6826df36255789f92e40bafcb2ebcb9e556f6c0ccadc6af08e31ec4ad5288034",
            "e16d155cfdcada7bab599c2fa4ad2e6293f9fe097169148276b6a9eaa72f148b0c9565c3c2dd63125e0fa530861a710d",
            "f8e481f2712920f8787e0aedfe618aff50a3b56213884d6262c11debf2ba7e8ad6692cb17078331418da4be064ff5270",
            "073934abcd2ab0469ecaf7275b4bd72bc6ed34478ea4089b736a16dd906d49f25c33827c571ce0b5d72177aa3508804b",
            "c0f8faa947122231402d2f5cc9a0eb0e09d427b427288d937d9d72b77456f886594cd8c6a462f77fd83076469cc0ecba",
            "3cc40cad69e5b54112eab33396aecfbc211f1f79cf33108e93d95378bae6958274b31088fbd8b3a3a0d154a789735b03",
            "49c4d51c889d08952ddd5488be95560594e6",
        ),
        script_hex: "5263535165",
        input_index: Some(0),
        amount: 483959951916902,
        raw_hash_type: 2,
        expected: [
            0x29, 0x6f, 0xd7, 0x63, 0xf2, 0x54, 0x5e, 0x64, 0xfb, 0x5d, 0x7d, 0x49, 0xc0, 0x00, 0xd2, 0xb4,
            0x18, 0xb9, 0x3b, 0xde, 0x22, 0x34, 0xf8, 0x74, 0x29, 0x11, 0xe8, 0xaf, 0xef, 0xd0, 0x6d, 0x57,
        ],
    },
    // Original zcashd C tuple, physical sighash.json line51.
    DigestVector {
        tx_hex: concat!(
            "030000807082c403035295dcad7fbf1164b60269f1166cc28daa7dd5d0c51c03bb9e94b4be5143aeab00000000056353",
            "6a516affffffffe10bbf07f993e37c33e909fbe992135b512873b83893e7d2472d5ba453f9f827020000000951515351",
            "5300656a52ffffffffe76ced39b39797ca3002163e760758def33d12e0404e3dca2e0fc6836b92e7a4030000000152ff",
            "ffffff03256b80010000000009ac655353536a53acac7543e0020000000005630065656a2ce3470400000000086a0000",
            "6a6a006a004645814d0000000000",
        ),
        script_hex: "53000053",
        input_index: Some(0),
        amount: 0,
        raw_hash_type: -865463971,
        expected: [
            0x76, 0x4d, 0x8a, 0xb6, 0x3c, 0x44, 0x55, 0xd2, 0x5d, 0xdd, 0x73, 0x14, 0x76, 0x28, 0x38, 0x95,
            0xa9, 0x71, 0x96, 0x30, 0x58, 0xd3, 0xbc, 0x2a, 0x9a, 0x90, 0xa1, 0x08, 0xf8, 0x3f, 0xce, 0x60,
        ],
    },
];
