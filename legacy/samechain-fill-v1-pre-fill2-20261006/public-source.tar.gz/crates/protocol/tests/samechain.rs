use primitive_types::U256;
use sha2::{Digest, Sha256};
use ziquid_protocol::samechain::{
    Action, Asset, Deployment, FeePolicy, FeeRule, InputDescriptor, OrderPolicy, OutputDescriptor,
    OwnerJournal, PublicPacket, Role, SamechainError, SingleOwnerPacket, Terms, validate_pair,
    single_terms_commitment, validate_single,
};

#[test]
fn exact_fee_policy_rejects_overcap_and_substituted_beneficiary() {
    let x=Asset::Native;
    let y=Asset::Token([7;20]);
    let policy=FeePolicy { entries:vec![FeeRule { payer:Role::A, asset:y, beneficiary:[9;20], max_atoms:U256::from(1) }] };
    policy.validate_for(Role::A,x,y).unwrap();
    assert!(policy.check_fee(Role::A,y,[9;20],U256::from(1)).is_ok());
    assert!(policy.check_fee(Role::A,y,[9;20],U256::from(2)).is_err());
    assert!(policy.check_fee(Role::A,y,[8;20],U256::from(1)).is_err());
    assert!(policy.check_fee(Role::B,y,[9;20],U256::from(1)).is_err());
}

fn deployment() -> Deployment {
    Deployment {
        chain_id: 31_337,
        authority: [1; 20],
        authority_code: [2; 32],
        verifier: [3; 20],
        verifier_code: [4; 32],
        owner_program: [5; 32],
        schema: 1,
    }
}

fn input(tag: u8, index: u32) -> InputDescriptor {
    InputDescriptor {
        commitment: [tag; 32],
        root: [19; 32],
        tree_id: 0,
        index,
        order_id: [tag + 2; 32],
        generation: 1,
        nullifier: [tag + 4; 32],
        owner_key: [tag + 6; 32],
    }
}

fn note(role: Role, tag: u8) -> OutputDescriptor {
    OutputDescriptor::Note {
        role,
        commitment: [tag; 32],
        recovery_key_commitment: [tag + 1; 32],
        ciphertext_version: 1,
        ciphertext: vec![tag, tag + 1, tag + 2],
    }
}

fn fee(role: Role, asset: Asset, recipient: u8, amount: U256) -> OutputDescriptor {
    OutputDescriptor::Fee {
        payer: role,
        asset,
        recipient: [recipient; 20],
        amount,
    }
}

fn fee_policy(role: Role, asset: Asset, cap: U256) -> FeePolicy {
    FeePolicy {
        entries: vec![FeeRule {
            payer: role,
            asset,
            beneficiary: [9; 20],
            max_atoms: cap,
        }],
    }
}

fn terms() -> Terms {
    let x = Asset::Native;
    let y = Asset::Token([7; 20]);
    Terms {
        deployment: deployment(),
        inputs: [input(30, 0), input(50, 1)],
        policies: [
            OrderPolicy {
                sell_asset: x,
                buy_asset: y,
                min_buy_num: U256::from(1),
                min_sell_den: U256::from(1),
                fee_policy: fee_policy(Role::A, y, U256::from(1)),
            },
            OrderPolicy {
                sell_asset: y,
                buy_asset: x,
                min_buy_num: U256::from(1),
                min_sell_den: U256::from(3),
                fee_policy: FeePolicy { entries: vec![] },
            },
        ],
        sell_a: U256::from(10),
        sell_b: U256::from(20),
        outputs: vec![note(Role::A, 80), note(Role::B, 90)],
        expiry: 100,
    }
}

#[test]
fn split_fee_is_aggregated_before_duplicate_payment_rejection() {
    let policy = fee_policy(Role::A, Asset::Native, U256::from(1));
    let outputs = vec![
        fee(Role::A, Asset::Native, 9, U256::from(1)),
        fee(Role::A, Asset::Native, 9, U256::from(1)),
    ];
    assert_eq!(
        policy.validate_fees(Role::A, &outputs),
        Err(SamechainError::FeeCapExceeded),
    );
    let mut full = terms();
    full.outputs.extend([
        fee(Role::A, full.policies[0].buy_asset, 9, U256::from(1)),
        fee(Role::A, full.policies[0].buy_asset, 9, U256::from(1)),
    ]);
    assert_eq!(full.validate(), Err(SamechainError::FeeCapExceeded));
}

#[test]
fn fee_aggregation_never_wraps_at_256_bits() {
    let policy = fee_policy(Role::A, Asset::Native, U256::MAX);
    let outputs = vec![
        fee(Role::A, Asset::Native, 9, U256::MAX),
        fee(Role::A, Asset::Native, 9, U256::from(1)),
    ];
    assert_eq!(
        policy.validate_fees(Role::A, &outputs),
        Err(SamechainError::FeeCapExceeded),
    );
    assert!(policy.validate_fees(Role::A, &outputs[..1]).is_ok());
}

#[test]
fn fee_policy_is_an_opened_bounded_canonical_allowlist() {
    let mut policy = fee_policy(Role::A, Asset::Native, U256::from(1));
    assert_eq!(FeePolicy::decode(&policy.encode().unwrap()).unwrap(), policy);
    let original = policy.commitment().unwrap();
    policy.entries[0].beneficiary = [10; 20];
    assert_ne!(original, policy.commitment().unwrap());
    assert!(policy.check_fee(Role::A, Asset::Native, [9; 20], U256::from(1)).is_err());
    policy.entries.push(policy.entries[0]);
    assert!(policy.validate().is_err());
    policy.entries[1].beneficiary = [8; 20];
    assert!(policy.validate().is_err());
    policy.entries.clear();
    for recipient in 1..=4 {
        policy.entries.push(FeeRule {
            payer: Role::A,
            asset: Asset::Native,
            beneficiary: [recipient; 20],
            max_atoms: U256::MAX,
        });
    }
    assert!(policy.validate_for(Role::A, Asset::Native, Asset::Token([7; 20])).is_ok());
    policy.entries.push(FeeRule {
        payer: Role::A,
        asset: Asset::Native,
        beneficiary: [5; 20],
        max_atoms: U256::MAX,
    });
    assert!(policy.validate().is_err());
}

#[test]
fn fees_cannot_substitute_assets_payers_or_beneficiaries() {
    let mut t = terms();
    let y = t.policies[0].buy_asset;
    t.outputs.push(fee(Role::A, y, 9, U256::from(1)));
    t.validate().unwrap();
    for changed in [
        fee(Role::A, Asset::Native, 9, U256::from(1)),
        fee(Role::A, y, 8, U256::from(1)),
        fee(Role::B, y, 9, U256::from(1)),
    ] {
        let mut attack = t.clone();
        *attack.outputs.last_mut().unwrap() = changed;
        assert!(attack.validate().is_err());
    }
    t.policies[0].fee_policy.entries[0].payer = Role::B;
    assert!(t.validate().is_err());
    t.policies[0].fee_policy.entries[0].payer = Role::A;
    t.policies[0].fee_policy.entries[0].asset = Asset::Token([8; 20]);
    assert!(t.validate().is_err());
}

#[test]
fn fee_and_exit_cannot_count_the_same_external_payment_twice() {
    let mut t = terms();
    let y = t.policies[0].buy_asset;
    t.outputs.push(fee(Role::A, y, 9, U256::from(1)));
    t.outputs.push(OutputDescriptor::Exit {
        role: Role::A,
        asset: y,
        recipient: [9; 20],
        amount: U256::from(2),
    });
    assert!(t.validate().is_err());
    t.outputs.pop();
    t.outputs.push(fee(Role::A, y, 9, U256::from(1)));
    t.policies[0].fee_policy.entries[0].max_atoms = U256::from(2);
    assert_eq!(t.validate(), Err(SamechainError::DuplicateOutput));
}

#[test]
fn net_buy_limit_includes_fees_and_uses_full_width_products() {
    let mut t = terms();
    t.sell_a = U256::from(20);
    t.policies[1].min_sell_den = U256::from(1);
    t.validate().unwrap();
    t.outputs.push(fee(Role::A, t.policies[0].buy_asset, 9, U256::from(1)));
    assert!(t.validate().is_err());
    t.outputs.pop();
    t.sell_a = U256::MAX;
    t.sell_b = U256::MAX;
    for policy in &mut t.policies {
        policy.min_buy_num = U256::MAX;
        policy.min_sell_den = U256::MAX;
    }
    t.validate().unwrap();
    t.sell_b = U256::MAX - U256::from(1);
    assert!(t.validate().is_err());
}

#[test]
fn terms_reject_overlapping_inputs_but_allow_shared_membership_roots() {
    let t = terms();
    t.validate().unwrap();
    let mut attacks = Vec::new();
    let mut a = t.clone(); a.inputs[1].commitment = a.inputs[0].commitment; attacks.push(a);
    let mut a = t.clone(); a.inputs[1].nullifier = a.inputs[0].nullifier; attacks.push(a);
    let mut a = t.clone(); a.inputs[1].owner_key = a.inputs[0].owner_key; attacks.push(a);
    let mut a = t.clone(); a.inputs[1].order_id = a.inputs[0].order_id; attacks.push(a);
    let mut a = t.clone(); a.inputs[1].index = a.inputs[0].index; attacks.push(a);
    for attack in attacks { assert!(attack.validate().is_err()); }
    let mut other_tree = t;
    other_tree.inputs[1].tree_id = 1;
    other_tree.inputs[1].index = other_tree.inputs[0].index;
    other_tree.validate().unwrap();
}

#[test]
fn terms_require_opposite_assets_positive_quantities_and_limits() {
    let mut attacks = Vec::new();
    let mut a = terms(); a.sell_a = U256::zero(); attacks.push(a);
    let mut a = terms(); a.sell_b = U256::zero(); attacks.push(a);
    let mut a = terms(); a.policies[0].min_buy_num = U256::zero(); attacks.push(a);
    let mut a = terms(); a.policies[1].min_sell_den = U256::zero(); attacks.push(a);
    let mut a = terms(); a.policies[1].sell_asset = Asset::Native; attacks.push(a);
    let mut a = terms(); a.policies[0].buy_asset = Asset::Native; attacks.push(a);
    let mut a = terms(); a.expiry = 0; attacks.push(a);
    for attack in attacks { assert!(attack.validate().is_err()); }
}

#[test]
fn input_generation_root_owner_and_nullifier_are_required() {
    let base = input(30, 0);
    let mut attacks = Vec::new();
    let mut a = base; a.commitment = [0; 32]; attacks.push(a);
    let mut a = base; a.root = [0; 32]; attacks.push(a);
    let mut a = base; a.order_id = [0; 32]; attacks.push(a);
    let mut a = base; a.owner_key = [0; 32]; attacks.push(a);
    let mut a = base; a.nullifier = [0; 32]; attacks.push(a);
    let mut a = base; a.generation = 0; attacks.push(a);
    for attack in attacks { assert!(attack.validate().is_err()); }
    assert_eq!(InputDescriptor::decode(&base.encode().unwrap()).unwrap(), base);
}

#[test]
fn outputs_reject_reused_commitments_ciphertexts_and_input_commitments() {
    let mut t = terms();
    t.outputs.push(t.outputs[0].clone());
    assert!(t.validate().is_err());
    let mut t = terms();
    if let OutputDescriptor::Note { commitment, .. } = &mut t.outputs[0] {
        *commitment = t.inputs[0].commitment;
    }
    assert!(t.validate().is_err());
    let mut t = terms();
    let first_ciphertext = match &t.outputs[0] {
        OutputDescriptor::Note { ciphertext, .. } => ciphertext.clone(),
        _ => unreachable!(),
    };
    if let OutputDescriptor::Note { ciphertext, .. } = &mut t.outputs[1] {
        *ciphertext = first_ciphertext;
    }
    assert!(t.validate().is_err());
}

#[test]
fn descriptors_and_manifests_are_bounded_before_encoding_or_allocation() {
    let mut t = terms();
    if let OutputDescriptor::Note { ciphertext, .. } = &mut t.outputs[0] {
        *ciphertext = vec![1; 4096];
    }
    t.validate().unwrap();
    if let OutputDescriptor::Note { ciphertext, .. } = &mut t.outputs[0] {
        ciphertext.push(1);
    }
    assert_eq!(t.validate(), Err(SamechainError::Oversize));
    let mut t = terms();
    for tag in 100..106 { t.outputs.push(note(Role::A, tag)); }
    t.validate().unwrap();
    t.outputs.push(note(Role::B, 120));
    assert_eq!(t.validate(), Err(SamechainError::Oversize));
    assert_eq!(PublicPacket::decode(&vec![0; 65_537]), Err(SamechainError::Oversize));
    let mut encoded = note(Role::A, 80).encode().unwrap();
    // Header + tag + role + two 32-byte commitments + u16 ciphertext version.
    let len_offset = b"Z2Z_SAMECHAIN_OUTPUT\0".len() + 2 + 1 + 1 + 32 + 32 + 2;
    encoded[len_offset..len_offset + 4].copy_from_slice(&u32::MAX.to_be_bytes());
    assert_eq!(OutputDescriptor::decode(&encoded), Err(SamechainError::Oversize));
}

#[test]
fn terms_opening_is_salted_and_packet_does_not_publish_private_policy() {
    let t = terms();
    let blind = [201; 32];
    let packet = t.public_packet(&blind).unwrap();
    packet.validate_opening(&t, &blind).unwrap();
    assert_eq!(Terms::decode(&t.encode().unwrap()).unwrap(), t);
    let mut hidden = t.clone();
    hidden.policies[0].min_sell_den = U256::from(2);
    let changed = hidden.public_packet(&blind).unwrap();
    assert_ne!(packet.terms_commitment, changed.terms_commitment);
    assert_eq!(packet.inputs, changed.inputs);
    assert_eq!(packet.outputs, changed.outputs);
    let mut masked = changed.clone();
    masked.terms_commitment = packet.terms_commitment;
    assert_eq!(packet.encode().unwrap(), masked.encode().unwrap());
    assert!(packet.validate_opening(&hidden, &blind).is_err());
    assert!(packet.validate_opening(&t, &[202; 32]).is_err());
    assert_eq!(t.commitment(&[0; 32]), Err(SamechainError::InvalidBlind));
    let other = t.public_packet(&[202; 32]).unwrap();
    assert_ne!(packet.terms_commitment, other.terms_commitment);
}

#[test]
fn canonical_frames_and_streaming_digests_have_no_concat_collision() {
    let mut t = terms();
    if let OutputDescriptor::Note { ciphertext, .. } = &mut t.outputs[0] { *ciphertext = vec![1]; }
    if let OutputDescriptor::Note { ciphertext, .. } = &mut t.outputs[1] { *ciphertext = vec![2, 3]; }
    let mut changed = t.clone();
    if let OutputDescriptor::Note { ciphertext, .. } = &mut changed.outputs[0] { *ciphertext = vec![1, 2]; }
    if let OutputDescriptor::Note { ciphertext, .. } = &mut changed.outputs[1] { *ciphertext = vec![3]; }
    assert_ne!(t.commitment(&[201; 32]).unwrap(), changed.commitment(&[201; 32]).unwrap());
    let packet = t.public_packet(&[201; 32]).unwrap();
    assert_eq!(packet.digest().unwrap(), <[u8; 32]>::from(Sha256::digest(packet.encode().unwrap())));
    let mut expected = Sha256::new();
    expected.update(b"Z2Z_SAMECHAIN_TERMS_COMMITMENT\0");
    expected.update(1_u16.to_be_bytes());
    expected.update([201; 32]);
    expected.update(t.encode().unwrap());
    assert_eq!(t.commitment(&[201; 32]).unwrap(), <[u8; 32]>::from(expected.finalize()));
}

#[test]
fn packet_digest_binds_ciphertext_version_recovery_key_owner_and_expiry() {
    let packet = terms().public_packet(&[201; 32]).unwrap();
    let digest = packet.digest().unwrap();
    let mut attacks = Vec::new();
    let mut a = packet.clone(); a.expiry += 1; attacks.push(a);
    let mut a = packet.clone(); a.inputs[0].owner_key = [111; 32]; attacks.push(a);
    let mut a = packet.clone(); a.terms_commitment = [112; 32]; attacks.push(a);
    let mut a = packet.clone(); a.outputs.swap(0, 1); attacks.push(a);
    let mut a = packet.clone();
    if let OutputDescriptor::Note { ciphertext, .. } = &mut a.outputs[0] { ciphertext[0] ^= 1; }
    attacks.push(a);
    let mut a = packet.clone();
    if let OutputDescriptor::Note { ciphertext_version, .. } = &mut a.outputs[0] { *ciphertext_version = 2; }
    attacks.push(a);
    let mut a = packet.clone();
    if let OutputDescriptor::Note { recovery_key_commitment, .. } = &mut a.outputs[0] { *recovery_key_commitment = [113; 32]; }
    attacks.push(a);
    for attack in attacks { assert_ne!(digest, attack.digest().unwrap()); }
}

#[test]
fn packet_decode_rejects_trailing_unknown_role_asset_schema_and_truncation() {
    let packet = terms().public_packet(&[201; 32]).unwrap();
    let encoded = packet.encode().unwrap();
    assert_eq!(PublicPacket::decode(&encoded).unwrap(), packet);
    for end in 0..encoded.len() { assert!(PublicPacket::decode(&encoded[..end]).is_err()); }
    let mut trailing = encoded.clone(); trailing.push(0);
    assert_eq!(PublicPacket::decode(&trailing), Err(SamechainError::TrailingBytes));
    let mut schema = encoded;
    let version_offset = b"Z2Z_SAMECHAIN_PUBLIC_PACKET\0".len();
    schema[version_offset..version_offset + 2].copy_from_slice(&2_u16.to_be_bytes());
    assert_eq!(PublicPacket::decode(&schema), Err(SamechainError::UnsupportedSchema));
    let mut descriptor = note(Role::A, 80).encode().unwrap();
    let tag_offset = b"Z2Z_SAMECHAIN_OUTPUT\0".len() + 2;
    descriptor[tag_offset] = 3;
    assert!(OutputDescriptor::decode(&descriptor).is_err());
    descriptor[tag_offset] = 0;
    descriptor[tag_offset + 1] = 2;
    assert_eq!(OutputDescriptor::decode(&descriptor), Err(SamechainError::InvalidRole));
    let mut asset = Asset::Native.encode().unwrap();
    asset[b"Z2Z_SAMECHAIN_ASSET\0".len() + 2] = 2;
    assert_eq!(Asset::decode(&asset), Err(SamechainError::InvalidAsset));
    assert!(Asset::Token([0; 20]).encode().is_err());
}

#[test]
fn pair_binds_complete_manifest_deployment_terms_and_each_input_field() {
    let packet = terms().public_packet(&[201; 32]).unwrap();
    let a = OwnerJournal::from_packet(&packet, Role::A, Action::Fill).unwrap();
    let b = OwnerJournal::from_packet(&packet, Role::B, Action::Fill).unwrap();
    validate_pair(&packet, &a, &b).unwrap();
    assert_eq!(OwnerJournal::decode(&a.encode().unwrap()).unwrap(), a);
    assert!(validate_pair(&packet, &b, &a).is_err());
    assert!(validate_pair(&packet, &a, &a).is_err());
    let mut attacks = Vec::new();
    let mut j = a; j.deployment_digest = [2; 32]; attacks.push(j);
    let mut j = a; j.terms_commitment = [3; 32]; attacks.push(j);
    let mut j = a; j.packet_digest = [4; 32]; attacks.push(j);
    let mut j = a; j.input_nullifier = [5; 32]; attacks.push(j);
    let mut j = a; j.input_commitment = [6; 32]; attacks.push(j);
    let mut j = a; j.root = [7; 32]; attacks.push(j);
    let mut j = a; j.tree_id += 1; attacks.push(j);
    let mut j = a; j.index += 1; attacks.push(j);
    let mut j = a; j.order_id = [8; 32]; attacks.push(j);
    let mut j = a; j.generation += 1; attacks.push(j);
    let mut j = a; j.action = Action::Cancel; attacks.push(j);
    let mut j = a; j.relation_version = 2; attacks.push(j);
    for attack in attacks { assert!(validate_pair(&packet, &attack, &b).is_err()); }
    let mut replay = packet.clone(); replay.expiry += 1;
    assert!(validate_pair(&replay, &a, &b).is_err());
    let mut replay = packet.clone(); replay.outputs.swap(0, 1);
    assert!(validate_pair(&replay, &a, &b).is_err());
    let mut replay = packet; replay.deployment.verifier_code = [22; 32];
    assert!(validate_pair(&replay, &a, &b).is_err());
    let mut trailing = a.encode().unwrap(); trailing.push(0);
    assert!(OwnerJournal::decode(&trailing).is_err());
}

#[test]
fn single_owner_packet_has_one_real_input_and_a_separate_action_domain() {
    let pair = terms().public_packet(&[201; 32]).unwrap();
    let mut single = SingleOwnerPacket {
        deployment: pair.deployment,
        input: pair.inputs[0],
        outputs: vec![pair.outputs[0].clone()],
        expiry: pair.expiry,
        terms_commitment: pair.terms_commitment,
    };
    single.validate_for(Role::A).unwrap();
    assert_eq!(SingleOwnerPacket::decode(&single.encode().unwrap()).unwrap(), single);
    assert!(PublicPacket::decode(&single.encode().unwrap()).is_err());
    assert!(SingleOwnerPacket::decode(&pair.encode().unwrap()).is_err());
    assert!(OwnerJournal::from_single_packet(&single, Role::A, Action::Fill).is_err());
    assert!(OwnerJournal::from_packet(&pair, Role::A, Action::Cancel).is_err());
    let cancel = OwnerJournal::from_single_packet(&single, Role::A, Action::Cancel).unwrap();
    let exit = OwnerJournal::from_single_packet(&single, Role::A, Action::Exit).unwrap();
    assert_eq!(cancel.input_nullifier, exit.input_nullifier);
    assert_ne!(cancel.encode().unwrap(), exit.encode().unwrap());
    validate_single(&single, &cancel, Role::A, Action::Cancel).unwrap();
    assert!(validate_single(&single, &cancel, Role::A, Action::Exit).is_err());
    assert!(validate_single(&single, &cancel, Role::B, Action::Cancel).is_err());
    single.outputs.push(note(Role::B, 90));
    assert!(single.validate_for(Role::A).is_err());
    single.outputs.clear();
    assert!(single.validate_for(Role::A).is_err());
}

#[test]
fn single_journal_cannot_replay_a_changed_recipient_or_generation() {
    let mut packet = SingleOwnerPacket {
        deployment: deployment(),
        input: input(30, 0),
        outputs: vec![OutputDescriptor::Exit {
            role: Role::A,
            asset: Asset::Native,
            recipient: [21; 20],
            amount: U256::from(10),
        }],
        expiry: 100,
        terms_commitment: [201; 32],
    };
    let journal = OwnerJournal::from_single_packet(&packet, Role::A, Action::Exit).unwrap();
    validate_single(&packet, &journal, Role::A, Action::Exit).unwrap();
    if let OutputDescriptor::Exit { recipient, .. } = &mut packet.outputs[0] { *recipient = [22; 20]; }
    assert!(validate_single(&packet, &journal, Role::A, Action::Exit).is_err());
    packet.input.generation += 1;
    assert!(validate_single(&packet, &journal, Role::A, Action::Exit).is_err());
}

#[test]
fn deployment_codec_matches_independent_big_endian_frame() {
    let descriptor = deployment();
    let mut expected = b"Z2Z_SAMECHAIN_DEPLOYMENT\0\0\x01".to_vec();
    expected.extend_from_slice(&[0, 0, 0, 0, 0, 0, 0x7a, 0x69]);
    expected.extend_from_slice(&[1; 20]);
    expected.extend_from_slice(&[2; 32]);
    expected.extend_from_slice(&[3; 20]);
    expected.extend_from_slice(&[4; 32]);
    expected.extend_from_slice(&[5; 32]);
    expected.extend_from_slice(&[0, 1]);
    assert_eq!(descriptor.encode().unwrap(), expected);
    assert_eq!(Deployment::decode(&expected).unwrap(), descriptor);
    assert_eq!(descriptor.digest().unwrap(), <[u8; 32]>::from(Sha256::digest(&expected)));
    let mut wrong_identity = descriptor;
    wrong_identity.owner_program = [0; 32];
    assert!(wrong_identity.encode().is_err());
    let mut trailing = expected;
    trailing.push(0);
    assert!(Deployment::decode(&trailing).is_err());
}

#[test]
fn opened_policy_and_rule_codecs_reject_hash_only_or_trailing_inputs() {
    let policy = terms().policies[0].clone();
    let wire = policy.encode().unwrap();
    assert_eq!(OrderPolicy::decode(&wire).unwrap(), policy);
    let rule = policy.fee_policy.entries[0];
    let wire = rule.encode().unwrap();
    assert_eq!(FeeRule::decode(&wire).unwrap(), rule);
    let mut trailing = wire;
    trailing.push(0);
    assert!(FeeRule::decode(&trailing).is_err());
    let digest = policy.fee_policy.commitment().unwrap();
    assert!(FeePolicy::decode(&digest).is_err());
    let wire = policy.fee_policy.encode().unwrap();
    for len in 0..wire.len() { assert!(FeePolicy::decode(&wire[..len]).is_err()); }
}

#[test]
fn owner_private_terms_and_fee_caps_have_explicit_erasure() {
    use zeroize::Zeroize;
    let mut private = terms();
    private.zeroize();
    assert_eq!(private.sell_a, U256::zero());
    assert_eq!(private.sell_b, U256::zero());
    for policy in &private.policies {
        assert_eq!(policy.min_buy_num, U256::zero());
        assert_eq!(policy.min_sell_den, U256::zero());
        for fee in &policy.fee_policy.entries {
            assert_eq!(fee.max_atoms, U256::zero());
            assert_eq!(fee.beneficiary, [0; 20]);
        }
    }
}

#[test]
fn journal_canonical_decode_rejects_unknown_action_and_public_input_count() {
    let packet = terms().public_packet(&[201; 32]).unwrap();
    let journal = OwnerJournal::from_packet(&packet, Role::A, Action::Fill).unwrap();
    let mut wire = journal.encode().unwrap();
    let action_offset = b"Z2Z_SAMECHAIN_OWNER_JOURNAL\0".len() + 2 + 2;
    wire[action_offset] = 3;
    assert_eq!(OwnerJournal::decode(&wire), Err(SamechainError::InvalidAction));
    let mut wire = packet.encode().unwrap();
    let count_offset = b"Z2Z_SAMECHAIN_PUBLIC_PACKET\0".len() + 2 + 146;
    wire[count_offset..count_offset + 4].copy_from_slice(&1_u32.to_be_bytes());
    assert!(PublicPacket::decode(&wire).is_err());
}

#[test]
fn external_payments_are_canonically_sorted_without_reordering_notes() {
    let mut t = terms();
    for recipient in [21, 22] {
        t.outputs.push(OutputDescriptor::Exit {
            role: Role::A,
            asset: Asset::Native,
            recipient: [recipient; 20],
            amount: U256::from(1),
        });
    }
    t.validate().unwrap();
    t.outputs.swap(0, 1);
    t.validate().unwrap();
    t.outputs.swap(2, 3);
    assert_eq!(t.validate(), Err(SamechainError::NonCanonical));
}

#[test]
fn single_terms_opening_commits_all_real_fields_without_hashing_itself() {
    let pair = terms().public_packet(&[201; 32]).unwrap();
    let mut packet = SingleOwnerPacket {
        deployment: pair.deployment,
        input: pair.inputs[0],
        outputs: vec![pair.outputs[0].clone()],
        expiry: pair.expiry,
        terms_commitment: [0; 32],
    };
    packet.terms_commitment = single_terms_commitment(&packet.deployment, &packet.input,
        &packet.outputs, packet.expiry, &[202; 32]).unwrap();
    packet.validate_commitment(&[202; 32]).unwrap();
    assert!(packet.validate_commitment(&[203; 32]).is_err());
    assert!(single_terms_commitment(&packet.deployment, &packet.input, &packet.outputs,
        packet.expiry, &[0; 32]).is_err());
    let wire = packet.encode().unwrap();
    let body_start = b"Z2Z_SAMECHAIN_SINGLE_PACKET\0".len() + 2;
    let mut expected = Sha256::new();
    expected.update(b"Z2Z_SAMECHAIN_SINGLE_TERMS_COMMITMENT\0");
    expected.update(1_u16.to_be_bytes());
    expected.update([202; 32]);
    expected.update(&wire[body_start..wire.len() - 32]);
    assert_eq!(packet.terms_commitment, <[u8; 32]>::from(expected.finalize()));
    packet.input.generation += 1;
    assert!(packet.validate_commitment(&[202; 32]).is_err());
}
