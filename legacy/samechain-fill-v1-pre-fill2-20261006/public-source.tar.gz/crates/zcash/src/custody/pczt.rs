use orchard::{
    Note,
    bundle::BundleVersion,
    note::{ExtractedNoteCommitment, NoteVersion, Rho},
    note_encryption::IronwoodDomain,
};
use pczt::{
    Pczt,
    roles::verifier::{OrchardError, Verifier},
};
use sha2::{Digest, Sha256};
use zcash_note_encryption::{Domain as _, try_output_recovery_with_pkd_esk};
use zcash_primitives::transaction::{
    TxVersion,
    sighash::SignableInput,
    sighash_v6::v6_signature_hash,
    txid::{TxIdDigester, to_txid},
};
use zcash_protocol::{
    constants::{V6_TX_VERSION, V6_VERSION_GROUP_ID},
    value::Zatoshis,
};

use super::{
    CheckedNativeOutput, CustodyError, ExpectedNativeEffects, NativeOutputKind,
    UnsignedNativeInspection, projection::GlobalMarkers,
};

/// Inspects real native effects, not a fully authorized or proved transaction.
/// Inventory/source occurrence and genesis are independently enrolled caller
/// facts; neither a branch identifier nor this PCZT establishes source history.
pub fn inspect_pczt<'a>(
    bytes: &[u8],
    expected: &ExpectedNativeEffects<'a>,
) -> Result<UnsignedNativeInspection<'a>, CustodyError> {
    validate_expected(expected)?;
    let pczt = Pczt::parse(bytes).map_err(|_| CustodyError::InvalidPczt)?;
    let global = pczt.global();
    if *global.tx_version() != V6_TX_VERSION
        || *global.version_group_id() != V6_VERSION_GROUP_ID
        || *global.consensus_branch_id() != expected.domain.source_branch
        || *global.tx_version() != expected.domain.source_tx_version
    {
        return Err(CustodyError::UnsupportedProfile);
    }
    if *global.expiry_height() != expected.expiry_height {
        return Err(CustodyError::GlobalMetadata);
    }
    let markers = GlobalMarkers::read(global)?;
    // The pinned profile is testnet. Regtest uses this same public SLIP44 marker;
    // explicit source_genesis must therefore remain an independent domain fact.
    if markers.coin_type != Some(1) {
        return Err(CustodyError::NetworkMarkerMismatch);
    }
    if markers.tx_modifiable != Some(0) {
        return Err(CustodyError::ModifiableTransaction);
    }
    if !pczt.transparent().inputs().is_empty()
        || !pczt.transparent().outputs().is_empty()
        || !pczt.sapling().spends().is_empty()
        || !pczt.sapling().outputs().is_empty()
        || *pczt.sapling().value_sum() != 0
        || !pczt.orchard().actions().is_empty()
        || *pczt.orchard().value_sum() != (0, false)
    {
        return Err(CustodyError::UnsupportedPool);
    }
    let mut outputs = Vec::with_capacity(expected.outputs.len());
    let verified = Verifier::new(pczt)
        .with_ironwood(|bundle| {
            verify_bundle(bundle, expected, &mut outputs).map_err(OrchardError::Custom)
        })
        .map_err(|error| match error {
            OrchardError::Custom(error) => error,
            OrchardError::Verify(_) => CustodyError::NativeVerification,
            OrchardError::Parse(_) => CustodyError::NativeParse,
            OrchardError::UnsupportedConsensusBranchId => CustodyError::UnsupportedProfile,
        })?
        .finish();
    let effects = verified
        .into_effects()
        .map_err(|_| CustodyError::EffectExtraction)?;
    if effects.version() != TxVersion::V6
        || effects.lock_time() != expected.lock_time
        || u32::from(effects.expiry_height()) != expected.expiry_height
    {
        return Err(CustodyError::GlobalMetadata);
    }
    let actual_fee = effects
        .fee_paid::<zcash_protocol::value::BalanceError, _>(|_| Ok(None))
        .map_err(|_| CustodyError::AmountOutOfRange)?
        .ok_or(CustodyError::MissingMetadata)?;
    if u64::from(actual_fee) != expected.fee {
        return Err(CustodyError::FeeMismatch);
    }
    let digests = effects.digest(TxIdDigester);
    let txid = to_txid(effects.version(), effects.consensus_branch_id(), &digests).into();
    // Hash.as_array() is the 64-byte backing store, not the configured digest.
    // This exact checked conversion matches PCZT's maintained sighash wrapper.
    let hash = v6_signature_hash(&effects, &SignableInput::Shielded, &digests);
    let shielded_sighash = hash
        .as_ref()
        .try_into()
        .map_err(|_| CustodyError::SighashEncoding)?;
    Ok(UnsignedNativeInspection {
        domain: *expected.domain,
        lock_time: expected.lock_time,
        expiry_height: expected.expiry_height,
        fee: expected.fee,
        exact_pczt_digest: Sha256::digest(bytes).into(),
        txid,
        shielded_sighash,
        inputs: expected.inputs,
        outputs,
        expected_outputs: expected.outputs,
    })
}

fn validate_expected(expected: &ExpectedNativeEffects<'_>) -> Result<(), CustodyError> {
    expected.domain.validate().map_err(CustodyError::Protocol)?;
    if expected.inputs.is_empty() || expected.outputs.is_empty() {
        return Err(CustodyError::InvalidExpectedEffects);
    }
    Zatoshis::from_u64(expected.fee).map_err(|_| CustodyError::AmountOutOfRange)?;
    for (index, input) in expected.inputs.iter().enumerate() {
        if input.value == 0
            || input.inventory_note == [0; 32]
            || input.source_occurrence.network != expected.domain.source_network
            || input.source_occurrence.pool != expected.domain.source_pool
            || input.source_occurrence.txid == [0; 32]
            || input.note_commitment == [0; 32]
            || input.nullifier == [0; 32]
            || expected.inputs[..index].iter().any(|prior| {
                prior.nullifier == input.nullifier
                    || prior.inventory_note == input.inventory_note
                    || prior.source_occurrence == input.source_occurrence
                    || prior.note_commitment == input.note_commitment
            })
        {
            return Err(CustodyError::InvalidExpectedEffects);
        }
        Zatoshis::from_u64(input.value).map_err(|_| CustodyError::AmountOutOfRange)?;
    }
    for output in expected.outputs {
        if output.value == 0 {
            return Err(CustodyError::InvalidExpectedEffects);
        }
        Zatoshis::from_u64(output.value).map_err(|_| CustodyError::AmountOutOfRange)?;
        if output.kind == NativeOutputKind::Change
            && !expected.inputs.iter().any(|input| {
                input
                    .trusted_fvk
                    .scope_for_address(&output.recipient)
                    .is_some()
            })
        {
            return Err(CustodyError::ChangeOwnership);
        }
    }
    Ok(())
}

fn verify_bundle(
    bundle: &orchard::pczt::Bundle,
    expected: &ExpectedNativeEffects<'_>,
    outputs: &mut Vec<CheckedNativeOutput>,
) -> Result<(), CustodyError> {
    if *bundle.bundle_version() != BundleVersion::ironwood_v3() {
        return Err(CustodyError::UnsupportedProfile);
    }
    bundle
        .verify_cross_address_restriction()
        .map_err(|_| CustodyError::NativeVerification)?;
    let mut input_total = 0u128;
    let mut output_total = 0u128;
    let mut input_count = 0usize;
    for (index, action) in bundle.actions().iter().enumerate() {
        action
            .verify_cv_net()
            .map_err(|_| CustodyError::NativeVerification)?;
        let spend = action.spend();
        if spend.dummy_sk().is_some() {
            return Err(CustodyError::DummySpendKey);
        }
        if *spend.note_version() != NoteVersion::V3
            || *action.output().note_version() != NoteVersion::V3
        {
            return Err(CustodyError::UnsupportedProfile);
        }
        let value = spend.value().ok_or(CustodyError::MissingMetadata)?;
        if value.inner() != 0 && !bundle.flags().spends_enabled() {
            return Err(CustodyError::NativeVerification);
        }
        let native_nullifier = spend.nullifier().to_bytes();
        let reserved = if value.inner() == 0 {
            // Only explicit zero-value note metadata is padding. Missing values
            // are never inferred as zero, and native consistency is still checked.
            None
        } else {
            if bundle.actions()[..index]
                .iter()
                .any(|prior| prior.spend().nullifier() == spend.nullifier())
            {
                return Err(CustodyError::InputMismatch);
            }
            Some(
                expected
                    .inputs
                    .iter()
                    .find(|input| input.nullifier == native_nullifier)
                    .ok_or(CustodyError::InputMismatch)?,
            )
        };
        let trusted_fvk = reserved.map(|input| &input.trusted_fvk);
        spend
            .verify_nullifier(trusted_fvk)
            .map_err(|_| CustodyError::NativeVerification)?;
        spend
            .verify_rk(trusted_fvk)
            .map_err(|_| CustodyError::NativeVerification)?;
        let input_note = Note::from_parts(
            spend.recipient().ok_or(CustodyError::MissingMetadata)?,
            value,
            spend.rho().ok_or(CustodyError::MissingMetadata)?,
            spend.rseed().ok_or(CustodyError::MissingMetadata)?,
            *spend.note_version(),
        )
        .into_option()
        .ok_or(CustodyError::NativeVerification)?;
        if let Some(reserved) = reserved {
            if reserved.value != input_note.value().inner()
                || reserved.note_commitment
                    != ExtractedNoteCommitment::from(input_note.commitment()).to_bytes()
            {
                return Err(CustodyError::InputMismatch);
            }
            input_count += 1;
        }
        input_total = input_total
            .checked_add(u128::from(input_note.value().inner()))
            .ok_or(CustodyError::AmountOutOfRange)?;
        action
            .output()
            .verify_note_commitment(spend)
            .map_err(|_| CustodyError::NativeVerification)?;
        let output = action.output();
        let output_value = output.value().ok_or(CustodyError::MissingMetadata)?;
        if output_value.inner() != 0 && !bundle.flags().outputs_enabled() {
            return Err(CustodyError::NativeVerification);
        }
        let recipient = output.recipient().ok_or(CustodyError::MissingMetadata)?;
        if output_value.inner() != 0 {
            let rho = Rho::from_bytes(&native_nullifier)
                .into_option()
                .ok_or(CustodyError::NativeVerification)?;
            let note = Note::from_parts(
                recipient,
                output_value,
                rho,
                output.rseed().ok_or(CustodyError::MissingMetadata)?,
                *output.note_version(),
            )
            .into_option()
            .ok_or(CustodyError::NativeVerification)?;
            let domain = IronwoodDomain::for_pczt_action(action);
            let (recovered, receiver, _) = try_output_recovery_with_pkd_esk(
                &domain,
                IronwoodDomain::get_pk_d(&note),
                IronwoodDomain::derive_esk(&note).ok_or(CustodyError::MissingMetadata)?,
                action,
            )
            .ok_or(CustodyError::CiphertextMismatch)?;
            if recovered != note || receiver != recipient {
                return Err(CustodyError::CiphertextMismatch);
            }
            // Match receiver/value multiplicity without assigning a policy role
            // to indistinguishable outputs. NativePlan binds concrete indexes.
            let expected_count = expected
                .outputs
                .iter()
                .filter(|expected| {
                    expected.recipient == recipient && expected.value == output_value.inner()
                })
                .count();
            let actual_count = outputs
                .iter()
                .filter(|prior| prior.recipient == recipient && prior.value == output_value.inner())
                .count();
            if actual_count >= expected_count {
                return Err(CustodyError::OutputMismatch);
            }
            let mut nullifier = None;
            for (index, input) in expected.inputs.iter().enumerate() {
                if expected.inputs[..index]
                    .iter()
                    .any(|prior| prior.trusted_fvk == input.trusted_fvk)
                {
                    continue;
                }
                if input.trusted_fvk.scope_for_address(&recipient).is_some() {
                    let candidate = note.nullifier(&input.trusted_fvk).to_bytes();
                    if nullifier.is_some_and(|prior| prior != candidate) {
                        return Err(CustodyError::ChangeOwnership);
                    }
                    nullifier = Some(candidate);
                }
            }
            outputs.push(CheckedNativeOutput {
                recipient,
                value: output_value.inner(),
                action_index: index
                    .try_into()
                    .map_err(|_| CustodyError::AmountOutOfRange)?,
                note_commitment: output.cmx().to_bytes(),
                nullifier,
            });
        }
        output_total = output_total
            .checked_add(u128::from(output_value.inner()))
            .ok_or(CustodyError::AmountOutOfRange)?;
    }
    if input_count != expected.inputs.len() || outputs.len() != expected.outputs.len() {
        return Err(CustodyError::InputMismatch);
    }
    let balance = input_total
        .checked_sub(output_total)
        .ok_or(CustodyError::ValueBalanceMismatch)?;
    let (magnitude, sign) = bundle.value_sum().magnitude_sign();
    if matches!(sign, orchard::value::Sign::Negative) || balance != u128::from(magnitude) {
        return Err(CustodyError::ValueBalanceMismatch);
    }
    if balance != u128::from(expected.fee) {
        return Err(CustodyError::FeeMismatch);
    }
    Ok(())
}
