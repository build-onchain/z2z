use std::fmt;

use orchard::{
    Anchor, Note,
    bundle::BundleVersion,
    keys::FullViewingKey,
    note::{NoteVersion, Nullifier, Rho},
    note_encryption::IronwoodDomain,
    tree::MerklePath,
};
use pczt::{
    Pczt,
    roles::{creator::Creator, verifier::{OrchardError, Verifier}},
};
use zcash_note_encryption::{Domain, try_output_recovery_with_pkd_esk};
use zcash_primitives::transaction::{
    Authorization, TransactionData,
    txid::{TxIdDigester, to_txid},
    components::orchard::{ACTION_SIZE, SPEND_AUTH_SIG_SIZE},
};
use zcash_protocol::{
    consensus::BranchId,
    constants::{MAX_BLOCK_BYTES, V6_TX_VERSION, V6_VERSION_GROUP_ID},
    value::Zatoshis,
};

use crate::{AuthoringError, IronwoodTransaction};

/// Caller-owned positive-value note, FVK and anchored witness. This validates the
/// local relation, not the origin of the note or anchor admissibility on a chain.
#[derive(Clone)]
pub struct OwnedInput {
    note: Note,
    fvk: FullViewingKey,
    merkle_path: MerklePath,
    anchor: Anchor,
}

impl fmt::Debug for OwnedInput {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("OwnedInput([redacted])")
    }
}

impl OwnedInput {
    pub fn new(
        note: Note,
        fvk: FullViewingKey,
        merkle_path: MerklePath,
        anchor: Anchor,
    ) -> Result<Self, AuthoringError> {
        if note.version() != NoteVersion::V3 {
            return Err(AuthoringError::WrongNoteVersion);
        }
        if note.value().inner() == 0 || Zatoshis::from_u64(note.value().inner()).is_err() {
            return Err(AuthoringError::InvalidInputValue);
        }
        if fvk.scope_for_address(&note.recipient()).is_none() {
            return Err(AuthoringError::InputNotOwned);
        }
        if merkle_path.root(note.commitment().into()) != anchor {
            return Err(AuthoringError::AnchorMismatch);
        }
        Ok(Self {
            note,
            fvk,
            merkle_path,
            anchor,
        })
    }

    pub fn note(&self) -> &Note {
        &self.note
    }
    pub fn full_viewing_key(&self) -> &FullViewingKey {
        &self.fvk
    }
    pub fn merkle_path(&self) -> &MerklePath {
        &self.merkle_path
    }
    pub fn anchor(&self) -> Anchor {
        self.anchor
    }
    pub fn nullifier(&self) -> Nullifier {
        self.note.nullifier(&self.fvk)
    }
}

/// Wallet-local sender opening. No receiver IVK, master OVK or spending key is required.
/// Its bytes, locator, plaintext and random seed must never be sent to a public log.
pub struct SenderOutputWitness {
    pub(crate) action_index: usize,
    pub(crate) note: Note,
    pub(crate) memo: [u8; 512],
}

impl fmt::Debug for SenderOutputWitness {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("SenderOutputWitness([redacted])")
    }
}

/// Private U custody artifact captured before any PCZT redaction. The complete
/// private PCZT retains every input/dummy opening, randomizer and output opening
/// for the application prover; it is NOT a preparation certificate for S.
pub struct PayoutWitness {
    pub(crate) input: OwnedInput,
    pub(crate) private_pczt_bytes: Vec<u8>,
    pub(crate) effect_id: [u8; 32],
    pub(crate) outputs: Vec<SenderOutputWitness>,
    pub(crate) requested_output_actions: Vec<usize>,
}

impl fmt::Debug for PayoutWitness {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("PayoutWitness([redacted])")
    }
}

/// Full sender-recovered plaintext, locally authenticated to an exact ciphertext.
pub struct RecoveredOutput {
    note: Note,
    memo: [u8; 512],
}

impl fmt::Debug for RecoveredOutput {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("RecoveredOutput([redacted])")
    }
}

impl RecoveredOutput {
    pub fn note(&self) -> &Note {
        &self.note
    }
    pub fn recipient(&self) -> orchard::Address {
        self.note.recipient()
    }
    pub fn value(&self) -> u64 {
        self.note.value().inner()
    }
    pub fn memo(&self) -> &[u8; 512] {
        &self.memo
    }
}

impl PayoutWitness {
    /// Restore caller-local custody, never a source/preparation certificate.
    /// Every private action opening and exact output ciphertext is validated.
    /// The authenticated caller mapping preserves requested order, including zero outputs.
    pub fn restore(
        input: OwnedInput,
        private_pczt_bytes: Vec<u8>,
        requested_output_actions: Vec<usize>,
    ) -> Result<Self, AuthoringError> {
        const MAX_PCZT_BYTES: usize = 16 * 1024 * 1024;
        const MAX_ACTIONS: usize = MAX_BLOCK_BYTES / (ACTION_SIZE + SPEND_AUTH_SIG_SIZE);
        if private_pczt_bytes.is_empty() || private_pczt_bytes.len() > MAX_PCZT_BYTES {
            return Err(AuthoringError::InvalidPczt);
        }
        let pczt = Pczt::parse(&private_pczt_bytes).map_err(|_| AuthoringError::InvalidPczt)?;
        if pczt.clone().serialize().map_err(|_| AuthoringError::InvalidPczt)?
            != private_pczt_bytes
        {
            return Err(AuthoringError::InvalidPczt);
        }
        let empty = Creator::new(BranchId::Nu6_2.into(), 0, 133, None, None)
            .map_err(|_| AuthoringError::InvalidPczt)?
            .build()
            .map_err(|_| AuthoringError::InvalidPczt)?;
        if pczt.transparent() != empty.transparent()
            || pczt.sapling() != empty.sapling()
            || pczt.orchard() != empty.orchard()
            || *pczt.global().tx_version() != V6_TX_VERSION
            || *pczt.global().version_group_id() != V6_VERSION_GROUP_ID
            || *pczt.global().consensus_branch_id() != u32::from(BranchId::Nu6_3)
            || pczt.ironwood().anchor().as_ref() != Some(&input.anchor().to_bytes())
            || pczt.ironwood().actions().is_empty()
            || pczt.ironwood().actions().len() > MAX_ACTIONS
        {
            return Err(AuthoringError::InvalidPczt);
        }
        let count = pczt.ironwood().actions().len();
        if requested_output_actions.is_empty() || requested_output_actions.len() > count {
            return Err(AuthoringError::InvalidOutputIndex);
        }
        let mut requested = vec![false; count];
        for &index in &requested_output_actions {
            let seen = requested.get_mut(index).ok_or(AuthoringError::InvalidOutputIndex)?;
            if *seen {
                return Err(AuthoringError::InvalidOutputIndex);
            }
            *seen = true;
        }
        let effects = pczt.clone().into_effects().map_err(|_| AuthoringError::InvalidPczt)?;
        let mut outputs = Vec::new();
        Verifier::new(pczt)
            .with_ironwood::<AuthoringError, _>(|bundle| {
                let check = || -> Result<Vec<SenderOutputWitness>, AuthoringError> {
                    if *bundle.bundle_version() != BundleVersion::ironwood_v3()
                        || bundle.flag_byte() & 3 != 3
                        || bundle.anchor() != &input.anchor()
                        || bundle.zkproof().is_some()
                        || bundle.bsk().is_some()
                    {
                        return Err(AuthoringError::InvalidPczt);
                    }
                    bundle.verify_cross_address_restriction()
                        .map_err(|_| AuthoringError::InvalidInputRelation)?;
                    let mut positive_spends = 0;
                    let mut nullifiers = Vec::with_capacity(count);
                    let mut restored = Vec::with_capacity(count);
                    let actual_actions = effects.ironwood_bundle()
                        .ok_or(AuthoringError::InvalidPczt)?.actions();
                    for (index, action) in bundle.actions().iter().enumerate() {
                        let spend = action.spend();
                        if *spend.note_version() != NoteVersion::V3
                            || spend.fvk().is_none()
                            || spend.spend_auth_sig().is_some()
                            || spend.rk().is_identity()
                        {
                            return Err(AuthoringError::InvalidInputRelation);
                        }
                        action.verify_cv_net().map_err(|_| AuthoringError::InvalidInputRelation)?;
                        spend.verify_nullifier(Some(input.full_viewing_key()))
                            .map_err(|_| AuthoringError::InvalidInputRelation)?;
                        spend.verify_rk(Some(input.full_viewing_key()))
                            .map_err(|_| AuthoringError::InvalidInputRelation)?;
                        let value = spend.value().as_ref()
                            .ok_or(AuthoringError::InvalidInputRelation)?.inner();
                        Zatoshis::from_u64(value).map_err(|_| AuthoringError::InvalidInputRelation)?;
                        nullifiers.push(spend.nullifier().to_bytes());
                        if value != 0 {
                            positive_spends += 1;
                            let path = spend.witness().as_ref()
                                .ok_or(AuthoringError::InvalidInputRelation)?;
                            if positive_spends != 1
                                || value != input.note().value().inner()
                                || spend.recipient().as_ref() != Some(&input.note().recipient())
                                || spend.rho().as_ref() != Some(&input.note().rho())
                                || spend.rseed().as_ref().map(|seed| seed.as_bytes()) != Some(input.note().rseed().as_bytes())
                                || spend.nullifier() != &input.nullifier()
                                || path.position() != input.merkle_path().position()
                                || path.auth_path() != input.merkle_path().auth_path()
                                || path.root(input.note().commitment().into()) != input.anchor()
                            {
                                return Err(AuthoringError::InvalidInputRelation);
                            }
                        }
                        let output = action.output();
                        if *output.note_version() != NoteVersion::V3 {
                            return Err(AuthoringError::InvalidOutputCiphertext);
                        }
                        output.verify_note_commitment(spend)
                            .map_err(|_| AuthoringError::InvalidOutputCiphertext)?;
                        let rho = Option::<Rho>::from(Rho::from_bytes(&spend.nullifier().to_bytes()))
                            .ok_or(AuthoringError::InvalidOutputCiphertext)?;
                        let note = Option::<Note>::from(Note::from_parts(
                            *output.recipient().as_ref().ok_or(AuthoringError::InvalidOutputCiphertext)?,
                            *output.value().as_ref().ok_or(AuthoringError::InvalidOutputCiphertext)?,
                            rho,
                            *output.rseed().as_ref().ok_or(AuthoringError::InvalidOutputCiphertext)?,
                            NoteVersion::V3,
                        )).ok_or(AuthoringError::InvalidOutputCiphertext)?;
                        Zatoshis::from_u64(note.value().inner())
                            .map_err(|_| AuthoringError::InvalidOutputCiphertext)?;
                        if !requested[index] && note.value().inner() != 0 {
                            return Err(AuthoringError::InvalidOutputIndex);
                        }
                        let domain = IronwoodDomain::for_pczt_action(action);
                        let (recovered, recipient, memo) = try_output_recovery_with_pkd_esk(
                            &domain,
                            IronwoodDomain::get_pk_d(&note),
                            IronwoodDomain::derive_esk(&note).ok_or(AuthoringError::InvalidOutputCiphertext)?,
                            action,
                        ).ok_or(AuthoringError::InvalidOutputCiphertext)?;
                        if recovered != note || recipient != note.recipient() {
                            return Err(AuthoringError::InvalidOutputCiphertext);
                        }
                        let witness = SenderOutputWitness { action_index: index, note, memo };
                        witness.recover(actual_actions.get(index).ok_or(AuthoringError::InvalidPczt)?)?;
                        restored.push(witness);
                    }
                    if positive_spends != 1 {
                        return Err(AuthoringError::InvalidInputRelation);
                    }
                    nullifiers.sort_unstable();
                    if nullifiers.windows(2).any(|pair| pair[0] == pair[1]) {
                        return Err(AuthoringError::InvalidInputRelation);
                    }
                    Ok(restored)
                };
                outputs = check().map_err(OrchardError::Custom)?;
                Ok(())
            })
            .map_err(|error| match error {
                OrchardError::Custom(error) => error,
                _ => AuthoringError::InvalidPczt,
            })?;
        Ok(Self {
            input,
            private_pczt_bytes,
            effect_id: effect_id(&effects),
            outputs,
            requested_output_actions,
        })
    }

    /// Exact builder metadata, not inferred from action zero or positive values.
    pub fn requested_output_actions(&self) -> &[usize] {
        &self.requested_output_actions
    }

    /// Explicit private persistence/prover boundary. Caller owns encryption,
    /// access control and retention; this is never part of the S packet.
    pub fn private_pczt_bytes(&self) -> &[u8] {
        &self.private_pczt_bytes
    }
    pub fn owned_input(&self) -> &OwnedInput {
        &self.input
    }
    pub fn effect_id(&self) -> [u8; 32] {
        self.effect_id
    }

    /// Recover the nth caller-requested output from the redacted exact P PCZT.
    pub fn recover_pczt_output(
        &self,
        pczt_bytes: &[u8],
        requested_index: usize,
    ) -> Result<RecoveredOutput, AuthoringError> {
        let effects = Pczt::parse(pczt_bytes)
            .map_err(|_| AuthoringError::InvalidPczt)?
            .into_effects()
            .map_err(|_| AuthoringError::InvalidPczt)?;
        self.recover_from_effects(&effects, requested_index)
    }

    /// Independent sender route over full transaction bytes after authorization.
    /// Local ciphertext recovery alone does not prove inclusion or consideration.
    pub fn recover_transaction_output(
        &self,
        transaction: &IronwoodTransaction,
        requested_index: usize,
    ) -> Result<RecoveredOutput, AuthoringError> {
        self.recover_from_effects(transaction.transaction(), requested_index)
    }

    fn recover_from_effects<A: Authorization>(
        &self,
        effects: &TransactionData<A>,
        requested_index: usize,
    ) -> Result<RecoveredOutput, AuthoringError> {
        if effect_id(effects) != self.effect_id {
            return Err(AuthoringError::EffectsMismatch);
        }
        let index = *self
            .requested_output_actions
            .get(requested_index)
            .ok_or(AuthoringError::InvalidOutputIndex)?;
        let witness = self
            .outputs
            .get(index)
            .ok_or(AuthoringError::InvalidOutputIndex)?;
        if witness.action_index != index {
            return Err(AuthoringError::InvalidOutputIndex);
        }
        let bundle = effects
            .ironwood_bundle()
            .ok_or(AuthoringError::InvalidPczt)?;
        let action = bundle
            .actions()
            .get(index)
            .ok_or(AuthoringError::InvalidOutputIndex)?;
        witness.recover(action)
    }
}

impl SenderOutputWitness {
    pub(crate) fn recover<A>(
        &self,
        action: &orchard::Action<A>,
    ) -> Result<RecoveredOutput, AuthoringError> {
        let domain = IronwoodDomain::for_action(action);
        let esk = IronwoodDomain::derive_esk(&self.note)
            .ok_or(AuthoringError::InvalidOutputCiphertext)?;
        let (note, recipient, memo) = try_output_recovery_with_pkd_esk(
            &domain,
            IronwoodDomain::get_pk_d(&self.note),
            esk,
            action,
        )
        .ok_or(AuthoringError::InvalidOutputCiphertext)?;
        if note != self.note || recipient != self.note.recipient() || memo != self.memo {
            return Err(AuthoringError::InvalidOutputCiphertext);
        }
        Ok(RecoveredOutput { note, memo })
    }
}

pub(crate) fn effect_id<A: Authorization>(effects: &TransactionData<A>) -> [u8; 32] {
    to_txid(
        effects.version(),
        effects.consensus_branch_id(),
        &effects.digest(TxIdDigester),
    )
    .into()
}
