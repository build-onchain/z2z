//! Wallet-local Ironwood/v6 authoring with the published upstream cohort.
//!
//! Caller-owned notes, view keys, spend authorization and witnesses stay local.
//! Preparation exports exact unsigned P effects and, after local proof/signing,
//! final Q consensus bytes; sender recovery material is retained before redaction.
//! Owner consent checks semantic input/payment openings and the complete linked
//! P/Q, derives their private binding and independently blinded solver capsule,
//! then borrows the actual Q owner signer for a distinct private signature.
//! The caller reviews all context terms and retains the returned signature privately;
//! neither S's destination quote nor its funding authorization is inferred.
//! Parsing/cryptographic checks do not prove source history, admissible anchors,
//! independent no-FVK ownership, or a DEX financial fact. Task3's application
//! preparation certificate and authorized real-chain runtime evidence remain required.
//!
//! The separate custody module checks caller-enrolled market PCZT effects without
//! signing, generating proofs, or establishing source history or payment.

mod authoring;
pub mod custody;
pub mod source;
mod validation;
mod witness;

pub use authoring::{
    AuthoringError, ExecutableSelfSpend, OutputPlan, PreparationIntent, PreparedPair,
    SourceParameters, UnsignedPayment, prepare,
};
pub use validation::{IronwoodTransaction, ValidationError};
pub use witness::{OwnedInput, PayoutWitness, RecoveredOutput, SenderOutputWitness};
